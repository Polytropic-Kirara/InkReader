package com.modu.reader;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.view.WindowManager;
import android.view.animation.DecelerateInterpolator;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.CompoundButton;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import com.modu.reader.core.Book;
import com.modu.reader.core.BookFactory;
import com.modu.reader.core.TxtBook;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;

public class ReaderActivity extends Activity implements PageView.Host, SharedPreferences.OnSharedPreferenceChangeListener {
    private static final float[] GAPS = {0f, 0.4f, 0.8f};
    private static final String[] GAP_NAMES = {"无", "小", "大"};
    private static final int[] MARGINS = {10, 20, 32};
    private static final String[] MARGIN_NAMES = {"窄", "中", "宽"};
    private static final String[] ANIM_CAPTIONS = {"仿真翻页", "覆盖翻页", "平移翻页", "无动画"};
    private static final List<String> THEME_KEYS = Arrays.asList("mode", "accent", "dayBg", "dayBgCustom", "nightBg", "nightBgCustom");
    private static final List<String> STYLE_KEYS = Arrays.asList("size", "line", "gap", "margin", "serif", "anim", "volume");

    private Library.Entry entry;
    private Book book;
    private PageView pv;
    private FrameLayout root, chrome, tocLayer;
    private LinearLayout topBar;
    private ScrollView bottom;
    private TextView titleSub, chapterLabel;
    private SeekBar seek;
    private SharedPreferences sp;
    private Theme th;
    private final Handler ui = new Handler();
    private boolean loading, menuShown, settingsOpen, seekDragging;

    @Override protected void onCreate(Bundle saved) {
        super.onCreate(saved);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN | WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        sp = Theme.prefs(this);
        entry = Library.get(this, getIntent().getStringExtra("id"));
        if (entry == null) {
            Toast.makeText(this, "书籍不存在", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }
        root = new FrameLayout(this);
        pv = new PageView(this);
        pv.setHost(this);
        root.addView(pv, new FrameLayout.LayoutParams(-1, -1));
        setContentView(root);
        applyStyle();
        applyTheme();
        sp.registerOnSharedPreferenceChangeListener(this);
        loadBook(entry.encoding, entry.chapter, entry.offset);
    }

    @Override public void onSharedPreferenceChanged(SharedPreferences p, String key) {
        if (key == null) return;
        if (THEME_KEYS.contains(key)) applyTheme();
        else if (STYLE_KEYS.contains(key)) { applyStyle(); rebuildChrome(); }
    }

    @Override public void onConfigurationChanged(Configuration c) {
        super.onConfigurationChanged(c);
        if (sp.getInt("mode", 0) == 2) applyTheme(); // follow system dark mode
    }

    @Override public void finish() {
        super.finish();
        overridePendingTransition(R.anim.hold, R.anim.zoom_out);
    }

    // ---- loading -----------------------------------------------------------------------

    private void loadBook(final String charset, final int chapter, final int offset) {
        loading = true;
        pv.setMessage("正在打开…");
        new Thread() {
            @Override public void run() {
                try {
                    final Book b = BookFactory.open(new File(entry.path), entry.format, charset, entry.title);
                    ui.post(new Runnable() {
                        @Override public void run() {
                            if (isFinishing()) { b.close(); return; }
                            if (book != null) book.close();
                            book = b;
                            loading = false;
                            pv.setBook(b, chapter, offset);
                            rebuildChrome();
                            if (afterLoad != null) { Runnable r = afterLoad; afterLoad = null; r.run(); }
                        }
                    });
                } catch (final Throwable t) {
                    ui.post(new Runnable() {
                        @Override public void run() {
                            if (isFinishing()) return;
                            AlertDialog d = Ui.show(Ui.dialog(ReaderActivity.this, th).setTitle("无法打开")
                                    .setMessage(String.valueOf(t.getMessage())).setPositiveButton("确定", null), th);
                            d.setOnDismissListener(new DialogInterface.OnDismissListener() {
                                @Override public void onDismiss(DialogInterface di) { finish(); }
                            });
                        }
                    });
                }
            }
        }.start();
    }

    @Override protected void onPause() {
        super.onPause();
        saveProgress();
    }

    private void saveProgress() {
        if (book == null || entry == null || loading) return;
        final int ch = pv.getChapter(), off = pv.currentOffset();
        final float prog = pv.progress();
        final String ct = book.displayTitle(ch), enc = entry.encoding;
        Library.update(this, entry.id, new Library.Change() {
            @Override public void apply(Library.Entry e) {
                e.chapter = ch;
                e.offset = off;
                e.progress = prog;
                e.chapterTitle = ct;
                e.lastRead = System.currentTimeMillis();
                e.encoding = enc;
            }
        });
    }

    @Override protected void onDestroy() {
        super.onDestroy();
        if (sp != null) sp.unregisterOnSharedPreferenceChangeListener(this);
        if (book != null) book.close();
    }

    // ---- theme & style -----------------------------------------------------------------

    private void applyTheme() {
        th = Theme.get(this);
        pv.setColors(th.readBg, th.readFg);
        getWindow().getDecorView().setBackgroundColor(th.readBg);
        Ui.bars(this, th.readBg, th.readBg);
        rebuildChrome();
        if (tocLayer != null) { root.removeView(tocLayer); tocLayer = null; }
    }

    private void applyStyle() {
        float size = sp.getFloat("size", 19f), line = sp.getFloat("line", 1.6f);
        int gap = sp.getInt("gap", 1) % GAPS.length;
        boolean serif = sp.getBoolean("serif", false);
        pv.setStyle(size, line, GAPS[gap], sp.getInt("margin", 20), serif ? Typeface.SERIF : Typeface.DEFAULT);
        pv.setAnimMode(sp.getInt("anim", PageView.ANIM_CURL));
    }

    // ---- PageView.Host -----------------------------------------------------------------

    @Override public void onCenterTap() { showMenu(!menuShown); }

    @Override public void onPageShown() {
        if (book == null || chapterLabel == null) return;
        int ch = pv.getChapter();
        if (!seekDragging) {
            seek.setProgress(ch);
            chapterLabel.setText(book.displayTitle(ch) + String.format(Locale.US, "  ·  %.1f%%", pv.progress() * 100f));
        }
        if (titleSub != null) titleSub.setText(book.displayTitle(ch));
    }

    @Override public void onBoundary(boolean atEnd) {
        if (atEnd && book instanceof com.modu.reader.web.WebBook && !loading) {
            final int count = book.chapterCount(), ch = pv.getChapter(), off = pv.currentOffset();
            afterLoad = new Runnable() {
                @Override public void run() {
                    if (book.chapterCount() > count) {
                        pv.gotoChapter(ch + 1);
                        Toast.makeText(ReaderActivity.this, "已载入新下载的章节", Toast.LENGTH_SHORT).show();
                    } else {
                        Library.Entry e = Library.get(ReaderActivity.this, entry.id);
                        boolean dl = e != null && "downloading".equals(e.dlState);
                        Toast.makeText(ReaderActivity.this, dl ? "后面的章节还在下载，稍等一会儿" : "已经是最后一章了", Toast.LENGTH_SHORT).show();
                    }
                }
            };
            loadBook(entry.encoding, ch, off);
            return;
        }
        Toast.makeText(this, atEnd ? "已经是最后一页了" : "已经是第一页了", Toast.LENGTH_SHORT).show();
    }

    private Runnable afterLoad;

    // ---- keys --------------------------------------------------------------------------

    @Override public boolean onKeyDown(int code, KeyEvent e) {
        if (book != null && !menuShown && tocLayer == null) {
            boolean vol = sp.getBoolean("volume", true);
            if ((vol && code == KeyEvent.KEYCODE_VOLUME_DOWN) || code == KeyEvent.KEYCODE_PAGE_DOWN
                    || code == KeyEvent.KEYCODE_DPAD_RIGHT || code == KeyEvent.KEYCODE_SPACE) { pv.next(); return true; }
            if ((vol && code == KeyEvent.KEYCODE_VOLUME_UP) || code == KeyEvent.KEYCODE_PAGE_UP
                    || code == KeyEvent.KEYCODE_DPAD_LEFT) { pv.prev(); return true; }
        }
        return super.onKeyDown(code, e);
    }

    @Override public boolean onKeyUp(int code, KeyEvent e) {
        if (book != null && !menuShown && tocLayer == null && sp.getBoolean("volume", true)
                && (code == KeyEvent.KEYCODE_VOLUME_DOWN || code == KeyEvent.KEYCODE_VOLUME_UP)) return true;
        return super.onKeyUp(code, e);
    }

    @Override public void onBackPressed() {
        if (tocLayer != null) closeToc();
        else if (menuShown && settingsOpen) { settingsOpen = false; rebuildChrome(); }
        else if (menuShown) showMenu(false);
        else super.onBackPressed();
    }

    // ---- menu chrome -------------------------------------------------------------------

    private void showMenu(final boolean show) {
        if (chrome == null) return;
        menuShown = show;
        if (!show) settingsOpen = false;
        final DecelerateInterpolator di = new DecelerateInterpolator(2f);
        if (show) {
            if (settingsOpen) rebuildChrome();
            chrome.setVisibility(View.VISIBLE);
            onPageShown();
            chrome.getViewTreeObserver().addOnPreDrawListener(new ViewTreeObserver.OnPreDrawListener() {
                @Override public boolean onPreDraw() {
                    chrome.getViewTreeObserver().removeOnPreDrawListener(this);
                    topBar.setTranslationY(-topBar.getHeight());
                    bottom.setTranslationY(bottom.getHeight());
                    topBar.animate().translationY(0).setDuration(240).setInterpolator(di).start();
                    bottom.animate().translationY(0).setDuration(260).setInterpolator(di).start();
                    return true;
                }
            });
        } else {
            topBar.animate().translationY(-topBar.getHeight()).setDuration(180).start();
            bottom.animate().translationY(bottom.getHeight()).setDuration(200).withEndAction(new Runnable() {
                @Override public void run() {
                    if (!menuShown) { chrome.setVisibility(View.GONE); if (settingsOpen) settingsOpen = false; }
                }
            }).start();
            if (settingsOpen) settingsOpen = false;
        }
    }

    private void rebuildChrome() {
        if (th == null) return;
        int scroll = bottom != null ? bottom.getScrollY() : 0;
        if (chrome != null) root.removeView(chrome);
        chrome = new FrameLayout(this);
        chrome.setVisibility(menuShown ? View.VISIBLE : View.GONE);
        View scrim = new View(this);
        scrim.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { showMenu(false); }
        });
        chrome.addView(scrim, new FrameLayout.LayoutParams(-1, -1));

        topBar = new LinearLayout(this);
        topBar.setOrientation(LinearLayout.HORIZONTAL);
        topBar.setGravity(Gravity.CENTER_VERTICAL);
        topBar.setBackgroundColor(th.surface);
        topBar.setElevation(Ui.dp(this, 4));
        topBar.setPadding(Ui.dp(this, 4), Ui.dp(this, 6), Ui.dp(this, 4), Ui.dp(this, 6));
        topBar.setClickable(true);
        topBar.addView(Ui.icon(this, Icons.BACK, th.text, new View.OnClickListener() {
            @Override public void onClick(View v) { finish(); }
        }));
        LinearLayout titles = new LinearLayout(this);
        titles.setOrientation(LinearLayout.VERTICAL);
        TextView title = Ui.text(this, entry.title, 16, th.text);
        title.setSingleLine(true);
        title.setEllipsize(TextUtils.TruncateAt.END);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        titles.addView(title);
        titleSub = Ui.text(this, book != null ? book.displayTitle(pv.getChapter()) : "", 12, th.sub);
        titleSub.setSingleLine(true);
        titleSub.setEllipsize(TextUtils.TruncateAt.END);
        titles.addView(titleSub);
        topBar.addView(titles, new LinearLayout.LayoutParams(0, -2, 1f));
        topBar.addView(Ui.icon(this, Icons.LIST, th.text, new View.OnClickListener() {
            @Override public void onClick(View v) { openToc(); }
        }));
        chrome.addView(topBar, new FrameLayout.LayoutParams(-1, -2, Gravity.TOP));

        LinearLayout panel = settingsOpen ? settingsPanel() : mainPanel();
        GradientDrawable pbg = new GradientDrawable();
        pbg.setColor(th.surface);
        float r = Ui.dp(this, 20);
        pbg.setCornerRadii(new float[]{r, r, r, r, 0, 0, 0, 0});
        bottom = new ScrollView(this);
        bottom.setBackground(pbg);
        bottom.setElevation(Ui.dp(this, 10));
        bottom.setClickable(true);
        bottom.setVerticalScrollBarEnabled(false);
        bottom.addView(panel);
        chrome.addView(bottom, new FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM));
        topBar.addOnLayoutChangeListener(new View.OnLayoutChangeListener() {
            @Override public void onLayoutChange(View v, int l, int t, int rr, int b, int ol, int ot, int or, int ob) {
                FrameLayout.LayoutParams p = (FrameLayout.LayoutParams) bottom.getLayoutParams();
                int want = b + Ui.dp(ReaderActivity.this, 8);
                if (p.topMargin != want) { p.topMargin = want; bottom.setLayoutParams(p); }
            }
        });
        root.addView(chrome, tocLayer != null ? root.indexOfChild(tocLayer) : -1, new FrameLayout.LayoutParams(-1, -1));
        final int keep = scroll;
        if (settingsOpen && keep > 0) bottom.post(new Runnable() { @Override public void run() { bottom.scrollTo(0, keep); } });
        onPageShown();
    }

    private LinearLayout mainPanel() {
        LinearLayout panel = column();
        chapterLabel = Ui.text(this, "", 13, th.sub);
        chapterLabel.setGravity(Gravity.CENTER);
        chapterLabel.setSingleLine(true);
        chapterLabel.setEllipsize(TextUtils.TruncateAt.MIDDLE);
        chapterLabel.setPadding(0, Ui.dp(this, 2), 0, Ui.dp(this, 6));
        panel.addView(chapterLabel, new LinearLayout.LayoutParams(-1, -2));

        LinearLayout r1 = row();
        r1.setBaselineAligned(false);
        TextView prevBtn = Ui.text(this, "上一章", 14, th.text);
        prevBtn.setSingleLine(true);
        prevBtn.setPadding(Ui.dp(this, 8), Ui.dp(this, 8), Ui.dp(this, 8), Ui.dp(this, 8));
        prevBtn.setBackground(Ui.ripple(th.text, null, false));
        prevBtn.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { if (book != null) pv.gotoChapter(pv.getChapter() - 1); }
        });
        r1.addView(prevBtn);
        seek = new SeekBar(this);
        Ui.tint(seek, th);
        seek.setMax(book != null ? Math.max(0, book.chapterCount() - 1) : 0);
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int p, boolean user) {
                if (user && book != null) chapterLabel.setText(book.displayTitle(p));
            }
            @Override public void onStartTrackingTouch(SeekBar s) { seekDragging = true; }
            @Override public void onStopTrackingTouch(SeekBar s) {
                seekDragging = false;
                if (book != null && s.getProgress() != pv.getChapter()) pv.gotoChapter(s.getProgress());
                else onPageShown();
            }
        });
        r1.addView(seek, new LinearLayout.LayoutParams(0, -2, 1f));
        TextView nextBtn = Ui.text(this, "下一章", 14, th.text);
        nextBtn.setSingleLine(true);
        nextBtn.setPadding(Ui.dp(this, 8), Ui.dp(this, 8), Ui.dp(this, 8), Ui.dp(this, 8));
        nextBtn.setBackground(Ui.ripple(th.text, null, false));
        nextBtn.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { if (book != null) pv.gotoChapter(pv.getChapter() + 1); }
        });
        r1.addView(nextBtn);
        panel.addView(r1);

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        actions.setGravity(Gravity.TOP); // equal cells, icons and captions on one line even with large system fonts
        actions.setBaselineAligned(false);
        actions.setPadding(0, Ui.dp(this, 10), 0, 0);
        addAction(actions, Icons.LIST, "目录", new View.OnClickListener() {
            @Override public void onClick(View v) { openToc(); }
        });
        addAction(actions, th.night ? Icons.SUN : Icons.MOON, th.night ? "日间" : "夜间", new View.OnClickListener() {
            @Override public void onClick(View v) { sp.edit().putInt("mode", th.night ? 0 : 1).apply(); }
        });
        int anim = sp.getInt("anim", PageView.ANIM_CURL);
        addAction(actions, Icons.PAGE, ANIM_CAPTIONS[anim], new View.OnClickListener() {
            @Override public void onClick(View v) {
                int a = (sp.getInt("anim", PageView.ANIM_CURL) + 1) % Theme.ANIM_NAMES.length;
                sp.edit().putInt("anim", a).apply();
            }
        });
        addAction(actions, Icons.SETTINGS, "设置", new View.OnClickListener() {
            @Override public void onClick(View v) { settingsOpen = true; rebuildChrome(); slideIn(); }
        });
        panel.addView(actions);
        return panel;
    }

    private void slideIn() {
        bottom.setAlpha(0f);
        bottom.setTranslationY(Ui.dp(this, 24));
        bottom.animate().alpha(1f).translationY(0).setDuration(220).setInterpolator(new DecelerateInterpolator()).start();
    }

    private void addAction(LinearLayout row, int icon, String caption, View.OnClickListener l) {
        row.addView(Ui.action(this, th, icon, caption, l), new LinearLayout.LayoutParams(0, -2, 1f));
    }

    private LinearLayout settingsPanel() {
        LinearLayout panel = column();
        LinearLayout head = row();
        head.addView(Ui.icon(this, Icons.BACK, th.text, new View.OnClickListener() {
            @Override public void onClick(View v) { settingsOpen = false; rebuildChrome(); slideIn(); }
        }));
        TextView ht = Ui.text(this, "阅读设置", 16, th.text);
        ht.setTypeface(Typeface.DEFAULT_BOLD);
        head.addView(ht);
        panel.addView(head);

        float size = sp.getFloat("size", 19f), line = sp.getFloat("line", 1.6f);
        panel.addView(stepper("字号", String.valueOf((int) size), "A−", "A+", "size", 19f, 1f, 12f, 40f));
        panel.addView(stepper("行距", String.format(Locale.US, "%.1f", line), "−", "+", "line", 1.6f, 0.1f, 1.0f, 2.6f));

        int gap = sp.getInt("gap", 1) % GAPS.length;
        panel.addView(choice("段距", GAP_NAMES, gap, new Pick() { @Override public void on(int i) { sp.edit().putInt("gap", i).apply(); } }));
        int margin = sp.getInt("margin", 20), mi = 1;
        for (int i = 0; i < MARGINS.length; i++) if (MARGINS[i] == margin) mi = i;
        panel.addView(choice("边距", MARGIN_NAMES, mi, new Pick() { @Override public void on(int i) { sp.edit().putInt("margin", MARGINS[i]).apply(); } }));
        panel.addView(choice("字体", new String[]{"默认", "衬线（宋体）"}, sp.getBoolean("serif", false) ? 1 : 0,
                new Pick() { @Override public void on(int i) { sp.edit().putBoolean("serif", i == 1).apply(); } }));
        panel.addView(choice("翻页", Theme.ANIM_NAMES, sp.getInt("anim", PageView.ANIM_CURL),
                new Pick() { @Override public void on(int i) { sp.edit().putInt("anim", i).apply(); } }));

        TextView bl = label(th.night ? "背景（夜间）" : "背景（日间）");
        panel.addView(bl);
        LinearLayout sw = row();
        final boolean night = th.night;
        final String key = night ? "nightBg" : "dayBg";
        int[] colors = night ? Theme.NIGHT_BG : Theme.DAY_BG;
        String[] names = night ? Theme.NIGHT_NAMES : Theme.DAY_NAMES;
        int sel = sp.getInt(key, 0);
        for (int i = 0; i < colors.length; i++) {
            final int idx = i;
            sw.addView(Ui.swatch(this, th, colors[i], names[i], sel == i, night, new View.OnClickListener() {
                @Override public void onClick(View v) { sp.edit().putInt(key, idx).apply(); }
            }));
        }
        sw.addView(Ui.customSwatch(this, th, sel < 0, th.readBg, night, new View.OnClickListener() {
            @Override public void onClick(View v) {
                ColorPicker.show(ReaderActivity.this, th, th.readBg, night, new ColorPicker.Listener() {
                    @Override public void onPick(int color) { sp.edit().putInt(key + "Custom", color).putInt(key, -1).apply(); }
                });
            }
        }));
        panel.addView(hscroll(sw));

        LinearLayout vr = row();
        vr.setPadding(0, Ui.dp(this, 10), 0, 0);
        TextView vl = Ui.text(this, "音量键翻页", 14, th.text);
        vr.addView(vl, new LinearLayout.LayoutParams(0, -2, 1f));
        vr.addView(Ui.toggle(this, th, sp.getBoolean("volume", true), new CompoundButton.OnCheckedChangeListener() {
            @Override public void onCheckedChanged(CompoundButton b, boolean on) { sp.edit().putBoolean("volume", on).apply(); }
        }));
        panel.addView(vr);

        if (book instanceof TxtBook) {
            LinearLayout er = row();
            er.setPadding(0, Ui.dp(this, 10), 0, 0);
            er.addView(Ui.text(this, "文本编码", 14, th.text), new LinearLayout.LayoutParams(0, -2, 1f));
            er.addView(Ui.pill(this, th, ((TxtBook) book).charset + "  ›", false, new View.OnClickListener() {
                @Override public void onClick(View v) { chooseEncoding(); }
            }));
            panel.addView(er);
        }
        return panel;
    }

    private interface Pick { void on(int i); }

    private View choice(String name, String[] options, int selected, final Pick pick) {
        LinearLayout r = row();
        r.setPadding(0, Ui.dp(this, 6), 0, Ui.dp(this, 6));
        TextView l = Ui.text(this, name, 14, th.text);
        l.setMinWidth(Ui.dp(this, 52));
        r.addView(l);
        for (int i = 0; i < options.length; i++) {
            final int idx = i;
            TextView c = Ui.chip(this, th, options[i], i == selected, new View.OnClickListener() {
                @Override public void onClick(View v) { pick.on(idx); }
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
            lp.rightMargin = Ui.dp(this, 8);
            r.addView(c, lp);
        }
        return hscroll(r);
    }

    private View stepper(String name, String value, String minus, String plus, final String key,
                         final float def, final float step, final float min, final float max) {
        LinearLayout r = row();
        r.setPadding(0, Ui.dp(this, 6), 0, Ui.dp(this, 6));
        TextView l = Ui.text(this, name, 14, th.text);
        l.setMinWidth(Ui.dp(this, 52));
        r.addView(l);
        r.addView(Ui.pill(this, th, minus, false, new View.OnClickListener() {
            @Override public void onClick(View v) { change(key, def, -step, min, max); }
        }), new LinearLayout.LayoutParams(Ui.dp(this, 64), -2));
        TextView val = Ui.text(this, value, 15, th.text);
        val.setGravity(Gravity.CENTER);
        r.addView(val, new LinearLayout.LayoutParams(Ui.dp(this, 56), -2));
        r.addView(Ui.pill(this, th, plus, false, new View.OnClickListener() {
            @Override public void onClick(View v) { change(key, def, step, min, max); }
        }), new LinearLayout.LayoutParams(Ui.dp(this, 64), -2));
        return r;
    }

    private void change(String key, float def, float delta, float min, float max) {
        float v = sp.getFloat(key, def) + delta;
        v = Math.round(Math.max(min, Math.min(max, v)) * 10f) / 10f;
        sp.edit().putFloat(key, v).apply();
    }

    private TextView label(String s) {
        TextView t = Ui.text(this, s, 14, th.text);
        t.setPadding(0, Ui.dp(this, 10), 0, Ui.dp(this, 8));
        return t;
    }

    private LinearLayout column() {
        LinearLayout p = new LinearLayout(this);
        p.setOrientation(LinearLayout.VERTICAL);
        int pad = Ui.dp(this, 16);
        p.setPadding(pad, Ui.dp(this, 12), pad, Ui.dp(this, 16));
        return p;
    }

    private LinearLayout row() {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER_VERTICAL);
        return r;
    }

    private View hscroll(View v) {
        HorizontalScrollView h = new HorizontalScrollView(this);
        h.setHorizontalScrollBarEnabled(false);
        h.addView(v);
        return h;
    }

    // ---- table of contents drawer ------------------------------------------------------

    private void openToc() {
        if (book == null || tocLayer != null) return;
        if (menuShown) { menuShown = false; settingsOpen = false; chrome.setVisibility(View.GONE); }
        final List<Integer> idx = new ArrayList<Integer>();
        final List<String> names = new ArrayList<String>();
        for (int i = 0; i < book.chapterCount(); i++) {
            String t = book.chapterTitles.get(i);
            if (t != null && t.length() > 0) { idx.add(i); names.add(t); }
        }
        if (idx.isEmpty()) for (int i = 0; i < book.chapterCount(); i++) { idx.add(i); names.add("第 " + (i + 1) + " 节"); }
        int cur = 0;
        for (int k = 0; k < idx.size(); k++) if (idx.get(k) <= pv.getChapter()) cur = k;
        final int current = cur;

        tocLayer = new FrameLayout(this);
        final View scrim = new View(this);
        scrim.setBackgroundColor(th.scrim);
        scrim.setAlpha(0f);
        scrim.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { closeToc(); } });
        tocLayer.addView(scrim, new FrameLayout.LayoutParams(-1, -1));

        final LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setBackgroundColor(th.surface);
        panel.setElevation(Ui.dp(this, 16));
        panel.setClickable(true);
        int pad = Ui.dp(this, 20);
        TextView t = Ui.text(this, entry.title, 18, th.text);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setSingleLine(true);
        t.setEllipsize(TextUtils.TruncateAt.END);
        t.setPadding(pad, pad, pad, Ui.dp(this, 4));
        panel.addView(t);
        TextView s = Ui.text(this, "共 " + names.size() + " 章  ·  已读 " + String.format(Locale.US, "%.1f%%", pv.progress() * 100), 12.5f, th.sub);
        s.setPadding(pad, 0, pad, Ui.dp(this, 14));
        panel.addView(s);
        panel.addView(Ui.divider(this, th));
        ListView lv = new ListView(this);
        lv.setDivider(null);
        lv.setSelector(Ui.ripple(th.accent, null, true));
        lv.setVerticalScrollBarEnabled(false);
        lv.setFastScrollEnabled(names.size() > 80);
        lv.setAdapter(new BaseAdapter() {
            @Override public int getCount() { return names.size(); }
            @Override public Object getItem(int p) { return names.get(p); }
            @Override public long getItemId(int p) { return p; }
            @Override public View getView(int p, View v, ViewGroup parent) {
                TextView tv = v instanceof TextView ? (TextView) v : new TextView(ReaderActivity.this);
                tv.setText(names.get(p));
                tv.setTextSize(15);
                tv.setSingleLine(true);
                tv.setEllipsize(TextUtils.TruncateAt.END);
                int hp = Ui.dp(ReaderActivity.this, 20), vp = Ui.dp(ReaderActivity.this, 13);
                tv.setPadding(hp, vp, hp, vp);
                boolean on = p == current;
                tv.setTextColor(on ? th.accent : th.text);
                tv.setTypeface(on ? Typeface.DEFAULT_BOLD : Typeface.DEFAULT);
                tv.setBackgroundColor(on ? Theme.alpha(th.accent, 0.10f) : 0);
                return tv;
            }
        });
        lv.setSelection(Math.max(0, cur - 4));
        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override public void onItemClick(AdapterView<?> p, View v, int pos, long id) {
                pv.gotoChapter(idx.get(pos));
                closeToc();
            }
        });
        panel.addView(lv, new LinearLayout.LayoutParams(-1, 0, 1f));
        final int width = Math.min((int) (root.getWidth() * 0.84f), Ui.dp(this, 360));
        tocLayer.addView(panel, new FrameLayout.LayoutParams(width, -1, Gravity.START));
        root.addView(tocLayer, new FrameLayout.LayoutParams(-1, -1));
        panel.setTranslationX(-width);
        panel.animate().translationX(0).setDuration(260).setInterpolator(new DecelerateInterpolator(2f)).start();
        scrim.animate().alpha(1f).setDuration(260).start();
    }

    private void closeToc() {
        if (tocLayer == null) return;
        final FrameLayout layer = tocLayer;
        tocLayer = null;
        View scrim = layer.getChildAt(0), panel = layer.getChildAt(1);
        scrim.animate().alpha(0f).setDuration(200).start();
        panel.animate().translationX(-panel.getWidth()).setDuration(200).withEndAction(new Runnable() {
            @Override public void run() { root.removeView(layer); }
        }).start();
    }

    // ---- dialogs -----------------------------------------------------------------------

    private void chooseEncoding() {
        final String[] labels = {"自动识别", "UTF-8", "GBK / GB18030（简体）", "Big5（繁体）", "UTF-16LE", "UTF-16BE"};
        final String[] values = {null, "UTF-8", "GB18030", "Big5", "UTF-16LE", "UTF-16BE"};
        Ui.show(Ui.dialog(this, th).setTitle("文本编码（出现乱码时切换）")
                .setItems(labels, new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int which) {
                        entry.encoding = values[which];
                        int ch = pv.getChapter();
                        saveProgress();
                        showMenu(false);
                        loadBook(entry.encoding, ch, 0);
                    }
                }), th);
    }
}

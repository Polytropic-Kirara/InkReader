package com.modu.reader;

import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;

/** Small line icons drawn with paths, so they look the same on every phone and tint with the theme. */
public final class Icons extends Drawable {
    public static final int BACK = 0, SEARCH = 1, PLUS = 2, SCAN = 3, SETTINGS = 4, CLOSE = 5, LIST = 6,
            MOON = 7, SUN = 8, NEXT = 9, CHECK = 10, BOOK = 11, PAGE = 12, FOLDER = 13, FONT = 14, WINDOW = 15, GLOBE = 16, REFRESH = 17;

    private final int type;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();
    private final RectF r = new RectF();

    public Icons(int type, int color) {
        this.type = type;
        p.setColor(color);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeCap(Paint.Cap.ROUND);
        p.setStrokeJoin(Paint.Join.ROUND);
    }

    @Override public void draw(Canvas c) {
        Rect b = getBounds();
        float s = Math.min(b.width(), b.height());
        float x0 = b.left + (b.width() - s) / 2f, y0 = b.top + (b.height() - s) / 2f, u = s / 24f;
        p.setStrokeWidth(1.9f * u);
        p.setStyle(Paint.Style.STROKE);
        path.reset();
        switch (type) {
            case BACK:
                path.moveTo(x0 + 15 * u, y0 + 5 * u); path.lineTo(x0 + 8 * u, y0 + 12 * u); path.lineTo(x0 + 15 * u, y0 + 19 * u);
                c.drawPath(path, p); break;
            case NEXT:
                path.moveTo(x0 + 9 * u, y0 + 5 * u); path.lineTo(x0 + 16 * u, y0 + 12 * u); path.lineTo(x0 + 9 * u, y0 + 19 * u);
                c.drawPath(path, p); break;
            case SEARCH:
                c.drawCircle(x0 + 10.5f * u, y0 + 10.5f * u, 6 * u, p);
                c.drawLine(x0 + 15 * u, y0 + 15 * u, x0 + 20 * u, y0 + 20 * u, p); break;
            case PLUS:
                c.drawLine(x0 + 12 * u, y0 + 5 * u, x0 + 12 * u, y0 + 19 * u, p);
                c.drawLine(x0 + 5 * u, y0 + 12 * u, x0 + 19 * u, y0 + 12 * u, p); break;
            case CLOSE:
                c.drawLine(x0 + 6 * u, y0 + 6 * u, x0 + 18 * u, y0 + 18 * u, p);
                c.drawLine(x0 + 18 * u, y0 + 6 * u, x0 + 6 * u, y0 + 18 * u, p); break;
            case SCAN:
                path.moveTo(x0 + 4 * u, y0 + 9 * u); path.lineTo(x0 + 4 * u, y0 + 4 * u); path.lineTo(x0 + 9 * u, y0 + 4 * u);
                path.moveTo(x0 + 15 * u, y0 + 4 * u); path.lineTo(x0 + 20 * u, y0 + 4 * u); path.lineTo(x0 + 20 * u, y0 + 9 * u);
                path.moveTo(x0 + 20 * u, y0 + 15 * u); path.lineTo(x0 + 20 * u, y0 + 20 * u); path.lineTo(x0 + 15 * u, y0 + 20 * u);
                path.moveTo(x0 + 9 * u, y0 + 20 * u); path.lineTo(x0 + 4 * u, y0 + 20 * u); path.lineTo(x0 + 4 * u, y0 + 15 * u);
                path.moveTo(x0 + 7 * u, y0 + 12 * u); path.lineTo(x0 + 17 * u, y0 + 12 * u);
                c.drawPath(path, p); break;
            case SETTINGS:
                c.drawLine(x0 + 4 * u, y0 + 7 * u, x0 + 20 * u, y0 + 7 * u, p);
                c.drawLine(x0 + 4 * u, y0 + 12 * u, x0 + 20 * u, y0 + 12 * u, p);
                c.drawLine(x0 + 4 * u, y0 + 17 * u, x0 + 20 * u, y0 + 17 * u, p);
                knob(c, x0 + 15 * u, y0 + 7 * u, u); knob(c, x0 + 8 * u, y0 + 12 * u, u); knob(c, x0 + 13 * u, y0 + 17 * u, u); break;
            case LIST:
                for (int i = 0; i < 3; i++) {
                    float y = y0 + (7 + 5 * i) * u;
                    c.drawLine(x0 + 9 * u, y, x0 + 20 * u, y, p);
                    c.drawPoint(x0 + 4.5f * u, y, p);
                }
                break;
            case MOON:
                p.setStyle(Paint.Style.FILL);
                Path a = new Path(), m = new Path();
                a.addCircle(x0 + 12 * u, y0 + 12 * u, 8 * u, Path.Direction.CW);
                m.addCircle(x0 + 16.5f * u, y0 + 8.5f * u, 7 * u, Path.Direction.CW);
                a.op(m, Path.Op.DIFFERENCE);
                c.drawPath(a, p); break;
            case SUN:
                c.drawCircle(x0 + 12 * u, y0 + 12 * u, 4.2f * u, p);
                for (int i = 0; i < 8; i++) {
                    double ang = Math.PI * i / 4;
                    float cx = x0 + 12 * u, cy = y0 + 12 * u;
                    c.drawLine(cx + (float) Math.cos(ang) * 7.5f * u, cy + (float) Math.sin(ang) * 7.5f * u,
                            cx + (float) Math.cos(ang) * 9.8f * u, cy + (float) Math.sin(ang) * 9.8f * u, p);
                }
                break;
            case CHECK:
                path.moveTo(x0 + 5 * u, y0 + 12.5f * u); path.lineTo(x0 + 10 * u, y0 + 17 * u); path.lineTo(x0 + 19 * u, y0 + 7 * u);
                c.drawPath(path, p); break;
            case BOOK:
                path.moveTo(x0 + 12 * u, y0 + 7 * u);
                path.cubicTo(x0 + 9 * u, y0 + 5 * u, x0 + 6 * u, y0 + 5 * u, x0 + 3 * u, y0 + 6 * u);
                path.lineTo(x0 + 3 * u, y0 + 19 * u);
                path.cubicTo(x0 + 6 * u, y0 + 18 * u, x0 + 9 * u, y0 + 18 * u, x0 + 12 * u, y0 + 20 * u);
                path.cubicTo(x0 + 15 * u, y0 + 18 * u, x0 + 18 * u, y0 + 18 * u, x0 + 21 * u, y0 + 19 * u);
                path.lineTo(x0 + 21 * u, y0 + 6 * u);
                path.cubicTo(x0 + 18 * u, y0 + 5 * u, x0 + 15 * u, y0 + 5 * u, x0 + 12 * u, y0 + 7 * u);
                path.lineTo(x0 + 12 * u, y0 + 20 * u);
                c.drawPath(path, p); break;
            case PAGE:
                r.set(x0 + 5 * u, y0 + 3 * u, x0 + 17 * u, y0 + 19 * u);
                c.drawRoundRect(r, 2 * u, 2 * u, p);
                path.moveTo(x0 + 17 * u, y0 + 7 * u); path.lineTo(x0 + 20 * u, y0 + 8 * u); path.lineTo(x0 + 17 * u, y0 + 21 * u);
                path.lineTo(x0 + 8 * u, y0 + 21 * u);
                c.drawPath(path, p); break;
            case FOLDER:
                path.moveTo(x0 + 3 * u, y0 + 7 * u); path.lineTo(x0 + 9 * u, y0 + 7 * u); path.lineTo(x0 + 11 * u, y0 + 9 * u);
                path.lineTo(x0 + 21 * u, y0 + 9 * u); path.lineTo(x0 + 21 * u, y0 + 19 * u); path.lineTo(x0 + 3 * u, y0 + 19 * u); path.close();
                c.drawPath(path, p); break;
            case FONT:
                path.moveTo(x0 + 3 * u, y0 + 19 * u); path.lineTo(x0 + 9 * u, y0 + 5 * u); path.lineTo(x0 + 15 * u, y0 + 19 * u);
                path.moveTo(x0 + 5.5f * u, y0 + 14 * u); path.lineTo(x0 + 12.5f * u, y0 + 14 * u);
                c.drawPath(path, p);
                c.drawCircle(x0 + 18.5f * u, y0 + 16 * u, 2.8f * u, p);
                c.drawLine(x0 + 21.3f * u, y0 + 12.5f * u, x0 + 21.3f * u, y0 + 19 * u, p); break;
            case GLOBE:
                c.drawCircle(x0 + 12 * u, y0 + 12 * u, 8.5f * u, p);
                r.set(x0 + 8 * u, y0 + 3.5f * u, x0 + 16 * u, y0 + 20.5f * u);
                c.drawOval(r, p);
                c.drawLine(x0 + 3.5f * u, y0 + 12 * u, x0 + 20.5f * u, y0 + 12 * u, p);
                break;
            case REFRESH:
                r.set(x0 + 5 * u, y0 + 5 * u, x0 + 19 * u, y0 + 19 * u);
                c.drawArc(r, -60, 290, false, p);
                path.moveTo(x0 + 16 * u, y0 + 3.5f * u); path.lineTo(x0 + 18.6f * u, y0 + 6.4f * u); path.lineTo(x0 + 15.2f * u, y0 + 8 * u);
                c.drawPath(path, p); break;
            case WINDOW:
                r.set(x0 + 3 * u, y0 + 5 * u, x0 + 21 * u, y0 + 19 * u);
                c.drawRoundRect(r, 2 * u, 2 * u, p);
                c.drawLine(x0 + 12 * u, y0 + 5 * u, x0 + 12 * u, y0 + 19 * u, p); break;
        }
    }

    private void knob(Canvas c, float x, float y, float u) {
        p.setStyle(Paint.Style.FILL);
        c.drawCircle(x, y, 2.6f * u, p);
        p.setStyle(Paint.Style.STROKE);
    }

    @Override public void setAlpha(int a) { p.setAlpha(a); invalidateSelf(); }
    @Override public void setColorFilter(ColorFilter cf) { p.setColorFilter(cf); invalidateSelf(); }
    @Override public int getOpacity() { return PixelFormat.TRANSLUCENT; }
}

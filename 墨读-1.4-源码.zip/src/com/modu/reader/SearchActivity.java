package com.modu.reader;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Handler;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.modu.reader.web.BookSource;
import com.modu.reader.web.Chapters;
import com.modu.reader.web.Fetcher;
import com.modu.reader.web.SourceEngine;
import com.modu.reader.web.WebStore;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;

/** Searches every enabled book source at once and merges the results by book. Also used to change source. */
public class SearchActivity extends Activity {
    static final class Group {
        String name, author;
        final List<SourceEngine.Result> items = new ArrayList<SourceEngine.Result>();

        SourceEngine.Result best() {
            for (SourceEngine.Result r : items) if (r.cover.length() > 0) return r;
            return items.get(0);
        }
    }

    /** Hand-over to the detail screen. */
    static Group pending;

    private Theme th;
    private final Handler ui = new Handler();
    private final List<Group> groups = new ArrayList<Group>();
    private BaseAdapter adapter;
    private EditText input;
    private TextView status;
    private View empty;
    private ExecutorService pool;
    private int gen;
    private String switchFor;
    private String query = "";

    @Override protected void onCreate(Bundle saved) {
        super.onCreate(saved);
        th = Theme.get(this);
        switchFor = getIntent().getStringExtra("switchFor");
        getWindow().getDecorView().setBackgroundColor(th.bg);
        Ui.bars(this, th.bg, th.bg);
        build();
        String key = getIntent().getStringExtra("key");
        if (key != null) { input.setText(key); search(key); }
    }

    @Override protected void onResume() {
        super.onResume();
        if (groups.isEmpty() && query.length() == 0) showEmptyState();
    }

    @Override protected void onDestroy() {
        super.onDestroy();
        if (pool != null) pool.shutdownNow();
    }

    @Override public void finish() {
        super.finish();
        overridePendingTransition(R.anim.slide_in_left_parallax, R.anim.slide_out_right);
    }

    private void build() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(th.bg);
        root.setFitsSystemWindows(true);

        LinearLayout bar = new LinearLayout(this);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(Ui.dp(this, 4), Ui.dp(this, 6), Ui.dp(this, 8), Ui.dp(this, 6));
        bar.addView(Ui.icon(this, Icons.BACK, th.text, new View.OnClickListener() {
            @Override public void onClick(View v) { finish(); }
        }));
        input = new EditText(this);
        input.setHint(switchFor != null ? "换源：搜索书名" : "在书源里搜索书名或作者");
        input.setHintTextColor(th.sub);
        input.setTextColor(th.text);
        input.setTextSize(15);
        input.setSingleLine(true);
        input.setImeOptions(EditorInfo.IME_ACTION_SEARCH);
        input.setBackground(Ui.round(th.card, th.divider, Ui.dp(this, 20), Ui.dp(this, 1)));
        input.setPadding(Ui.dp(this, 16), 0, Ui.dp(this, 16), 0);
        input.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override public boolean onEditorAction(TextView v, int id, KeyEvent e) { search(input.getText().toString()); return true; }
        });
        bar.addView(input, new LinearLayout.LayoutParams(0, Ui.dp(this, 42), 1f));
        bar.addView(Ui.icon(this, Icons.SEARCH, th.text, new View.OnClickListener() {
            @Override public void onClick(View v) { search(input.getText().toString()); }
        }));
        root.addView(bar, new LinearLayout.LayoutParams(-1, Ui.dp(this, 60)));

        if (switchFor == null) {
            LinearLayout chips = new LinearLayout(this);
            chips.setPadding(Ui.dp(this, 14), 0, Ui.dp(this, 14), Ui.dp(this, 4));
            chips.addView(Ui.chip(this, th, "网页导入", false, new View.OnClickListener() {
                @Override public void onClick(View v) {
                    startActivity(new Intent(SearchActivity.this, WebActivity.class));
                    overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left_parallax);
                }
            }));
            View g = new View(this);
            chips.addView(g, new LinearLayout.LayoutParams(Ui.dp(this, 8), 1));
            chips.addView(Ui.chip(this, th, "书源管理", false, new View.OnClickListener() {
                @Override public void onClick(View v) {
                    startActivity(new Intent(SearchActivity.this, SourcesActivity.class));
                    overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left_parallax);
                }
            }));
            root.addView(chips);
        }

        status = Ui.text(this, "", 12.5f, th.sub);
        status.setPadding(Ui.dp(this, 20), Ui.dp(this, 6), Ui.dp(this, 20), Ui.dp(this, 6));
        root.addView(status);

        FrameLayout content = new FrameLayout(this);
        ListView lv = new ListView(this);
        lv.setDivider(null);
        lv.setSelector(new android.graphics.drawable.ColorDrawable(0));
        lv.setClipToPadding(false);
        lv.setPadding(0, 0, 0, Ui.dp(this, 16));
        adapter = new BaseAdapter() {
            @Override public int getCount() { return groups.size(); }
            @Override public Object getItem(int p) { return groups.get(p); }
            @Override public long getItemId(int p) { return p; }
            @Override public View getView(int p, View v, ViewGroup parent) { return row(groups.get(p), v); }
        };
        lv.setAdapter(adapter);
        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override public void onItemClick(AdapterView<?> a, View v, int pos, long id) { open(groups.get(pos)); }
        });
        content.addView(lv, new FrameLayout.LayoutParams(-1, -1));
        empty = buildEmpty();
        empty.setVisibility(View.GONE);
        content.addView(empty, new FrameLayout.LayoutParams(-1, -1));
        root.addView(content, new LinearLayout.LayoutParams(-1, 0, 1f));
        setContentView(root);
    }

    private View buildEmpty() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER);
        int p = Ui.dp(this, 32);
        box.setPadding(p, 0, p, Ui.dp(this, 80));
        ImageView ic = new ImageView(this);
        ic.setImageDrawable(new Icons(Icons.GLOBE, Theme.alpha(th.sub, 0.7f)));
        box.addView(ic, new LinearLayout.LayoutParams(Ui.dp(this, 64), Ui.dp(this, 64)));
        TextView t = Ui.text(this, "还没有可以搜索的书源", 17, th.text);
        t.setGravity(Gravity.CENTER);
        t.setPadding(0, Ui.dp(this, 14), 0, Ui.dp(this, 6));
        box.addView(t, new LinearLayout.LayoutParams(-1, -2));
        TextView s = Ui.text(this, "书源是告诉墨读「去哪个网站、怎么找书」的规则，兼容「阅读」App 的书源格式。导入后就能在这里搜书。\n也可以先用「网页导入」直接打开网站抓取。", 13, th.sub);
        s.setGravity(Gravity.CENTER);
        s.setLineSpacing(0, 1.35f);
        box.addView(s, new LinearLayout.LayoutParams(-1, -2));
        LinearLayout btns = new LinearLayout(this);
        btns.setGravity(Gravity.CENTER);
        btns.setPadding(0, Ui.dp(this, 20), 0, 0);
        btns.addView(Ui.pill(this, th, "导入书源", true, new View.OnClickListener() {
            @Override public void onClick(View v) { startActivity(new Intent(SearchActivity.this, SourcesActivity.class)); }
        }));
        View g = new View(this);
        btns.addView(g, new LinearLayout.LayoutParams(Ui.dp(this, 12), 1));
        btns.addView(Ui.pill(this, th, "网页导入", false, new View.OnClickListener() {
            @Override public void onClick(View v) { startActivity(new Intent(SearchActivity.this, WebActivity.class)); }
        }));
        box.addView(btns);
        return box;
    }

    private void showEmptyState() {
        int usable = 0;
        for (BookSource s : DownloadCenter.sources(this)) if (s.enabled && s.canSearch()) usable++;
        empty.setVisibility(usable == 0 ? View.VISIBLE : View.GONE);
        if (usable > 0 && query.length() == 0) status.setText("已启用 " + usable + " 个书源");
    }

    // ---- searching ---------------------------------------------------------------------

    private void search(String key) {
        key = key.trim();
        if (key.length() == 0) return;
        InputMethodManager im = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
        if (im != null) im.hideSoftInputFromWindow(input.getWindowToken(), 0);
        final List<BookSource> sources = new ArrayList<BookSource>();
        for (BookSource s : DownloadCenter.sources(this)) if (s.enabled && s.canSearch()) sources.add(s);
        if (sources.isEmpty()) { showEmptyState(); return; }
        empty.setVisibility(View.GONE);
        query = key;
        final int my = ++gen;
        groups.clear();
        adapter.notifyDataSetChanged();
        if (pool != null) pool.shutdownNow();
        pool = Executors.newFixedThreadPool(Math.min(6, sources.size()));
        final AtomicInteger done = new AtomicInteger(), failed = new AtomicInteger();
        final int total = sources.size();
        status.setText("正在搜索 " + total + " 个书源…");
        final Context app = getApplicationContext();
        final String k = key;
        for (final BookSource s : sources) {
            pool.submit(new Runnable() {
                @Override public void run() {
                    List<SourceEngine.Result> rs = null;
                    try {
                        Fetcher f = DownloadCenter.fetcher(app);
                        f.attempts = 1;
                        f.timeoutMs = 12000;
                        rs = new SourceEngine(f).search(s, k, 1);
                    } catch (Throwable t) {
                        failed.incrementAndGet();
                    }
                    final List<SourceEngine.Result> res = rs;
                    final int d = done.incrementAndGet();
                    ui.post(new Runnable() {
                        @Override public void run() {
                            if (my != gen || isFinishing()) return;
                            if (res != null) merge(res, k);
                            status.setText((d < total ? "正在搜索… " + d + "/" + total + " 个书源" : "搜索完成，" + total + " 个书源")
                                    + (failed.get() > 0 ? "（" + failed.get() + " 个没有响应）" : "")
                                    + "　·　找到 " + groups.size() + " 本");
                        }
                    });
                }
            });
        }
    }

    private static String norm(String s) {
        return s.replaceAll("[\\s　\\p{P}]+", "").toLowerCase(Locale.ROOT);
    }

    private void merge(List<SourceEngine.Result> res, final String key) {
        for (SourceEngine.Result r : res) {
            Group g = null;
            for (Group x : groups) {
                if (norm(x.name).equals(norm(r.name)) && (x.author.length() == 0 || r.author.length() == 0 || norm(x.author).equals(norm(r.author)))) { g = x; break; }
            }
            if (g == null) {
                g = new Group();
                g.name = r.name;
                g.author = r.author;
                groups.add(g);
            }
            if (g.author.length() == 0) g.author = r.author;
            g.items.add(r);
        }
        final String nk = norm(key);
        Collections.sort(groups, new Comparator<Group>() {
            @Override public int compare(Group a, Group b) { return rank(b, nk) - rank(a, nk); }
        });
        adapter.notifyDataSetChanged();
    }

    private static int rank(Group g, String key) {
        String n = norm(g.name), au = norm(g.author);
        int r = 0;
        if (n.equals(key)) r += 1000;
        else if (n.startsWith(key)) r += 500;
        else if (n.contains(key)) r += 300;
        if (au.equals(key)) r += 400;
        return r + Math.min(50, g.items.size() * 10);
    }

    // ---- rows --------------------------------------------------------------------------

    private View row(final Group g, View convert) {
        LinearLayout r;
        if (convert instanceof LinearLayout) r = (LinearLayout) convert;
        else {
            r = new LinearLayout(this);
            r.setGravity(Gravity.CENTER_VERTICAL);
            r.setPadding(Ui.dp(this, 18), Ui.dp(this, 10), Ui.dp(this, 16), Ui.dp(this, 10));
            MainActivity.CoverView cv = new MainActivity.CoverView(this);
            r.addView(cv, new LinearLayout.LayoutParams(Ui.dp(this, 54), Ui.dp(this, 72)));
            LinearLayout col = new LinearLayout(this);
            col.setOrientation(LinearLayout.VERTICAL);
            col.setPadding(Ui.dp(this, 14), 0, 0, 0);
            TextView name = Ui.text(this, "", 16, th.text);
            name.setTypeface(Typeface.DEFAULT_BOLD);
            name.setSingleLine(true);
            name.setEllipsize(TextUtils.TruncateAt.END);
            col.addView(name);
            TextView meta = Ui.text(this, "", 12.5f, th.sub);
            meta.setSingleLine(true);
            meta.setEllipsize(TextUtils.TruncateAt.END);
            meta.setPadding(0, Ui.dp(this, 3), 0, 0);
            col.addView(meta);
            TextView last = Ui.text(this, "", 12.5f, th.sub);
            last.setSingleLine(true);
            last.setEllipsize(TextUtils.TruncateAt.END);
            col.addView(last);
            TextView src = Ui.text(this, "", 11, th.accent);
            src.setPadding(0, Ui.dp(this, 4), 0, 0);
            col.addView(src);
            r.addView(col, new LinearLayout.LayoutParams(0, -2, 1f));
            r.setBackground(Ui.ripple(th.accent, null, true));
        }
        final MainActivity.CoverView cv = (MainActivity.CoverView) r.getChildAt(0);
        LinearLayout col = (LinearLayout) r.getChildAt(1);
        SourceEngine.Result b = g.best();
        cv.setTag(b.cover);
        cv.bind(g.name, Images.cached(b.cover));
        if (b.cover.length() > 0 && Images.cached(b.cover) == null) {
            Images.load(b.cover, new Images.Target() {
                @Override public void set(String url, Bitmap bm) { if (url.equals(cv.getTag())) cv.bind(g.name, bm); }
            });
        }
        ((TextView) col.getChildAt(0)).setText(g.name);
        String kind = "";
        for (SourceEngine.Result x : g.items) if (x.kind.length() > 0) { kind = x.kind; break; }
        ((TextView) col.getChildAt(1)).setText((g.author.length() > 0 ? g.author : "佚名") + (kind.length() > 0 ? "　·　" + kind : ""));
        String latest = "";
        for (SourceEngine.Result x : g.items) if (x.lastChapter.length() > 0) { latest = x.lastChapter; break; }
        ((TextView) col.getChildAt(2)).setText(latest.length() > 0 ? "最新：" + latest : (b.intro.length() > 0 ? b.intro.replace('\n', ' ') : ""));
        ((TextView) col.getChildAt(3)).setText(g.items.size() == 1 ? g.items.get(0).source.name : g.items.size() + " 个书源");
        return r;
    }

    private void open(Group g) {
        if (switchFor != null) { pickSwitch(g); return; }
        pending = g;
        startActivity(new Intent(this, DetailActivity.class));
        overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left_parallax);
    }

    // ---- change source -----------------------------------------------------------------

    private void pickSwitch(final Group g) {
        String[] names = new String[g.items.size()];
        for (int i = 0; i < names.length; i++) {
            SourceEngine.Result r = g.items.get(i);
            names[i] = r.source.name + (r.lastChapter.length() > 0 ? "　最新：" + r.lastChapter : "");
        }
        Ui.show(Ui.dialog(this, th).setTitle("换到哪个书源").setItems(names, new DialogInterface.OnClickListener() {
            @Override public void onClick(DialogInterface d, int which) { doSwitch(g.items.get(which), false); }
        }), th);
    }

    private void doSwitch(final SourceEngine.Result r, final boolean restart) {
        final Library.Entry e = Library.get(this, switchFor);
        if (e == null) { finish(); return; }
        final AlertDialog pd = Ui.progress(this, th, "正在读取新书源的目录…");
        final Context app = getApplicationContext();
        new Thread() {
            @Override public void run() {
                String err = null;
                int match = -2;
                try {
                    SourceEngine eng = new SourceEngine(DownloadCenter.fetcher(app));
                    SourceEngine.Info in = eng.info(r.source, r);
                    List<String[]> toc = eng.toc(r.source, in.tocUrl);
                    if (toc.isEmpty()) throw new Exception("新书源没有读到目录");
                    WebStore s = WebStore.load(new File(e.path));
                    if (restart) s.resetChapters();
                    match = Chapters.switchToc(s, toc, in.tocUrl);
                    if (match >= 0 || s.chapters.isEmpty()) {
                        s.set("source", r.source.url);
                        s.saveMeta();
                        Library.update(app, e.id, new Library.Change() {
                            @Override public void apply(Library.Entry x) {
                                x.srcUrl = r.source.url;
                                x.source = r.bookUrl;
                                x.dlState = "downloading";
                                x.dlError = "";
                                x.browserOnly = false;
                                if (restart) { x.dlCount = 0; x.chapter = 0; x.offset = 0; }
                            }
                        });
                        DownloadCenter.start(app);
                    }
                } catch (Throwable t) {
                    err = t.getMessage();
                }
                final String fe = err;
                final int fm = match;
                ui.post(new Runnable() {
                    @Override public void run() {
                        if (isFinishing()) return;
                        try { pd.dismiss(); } catch (Exception ignored) {}
                        if (fe != null) {
                            Ui.show(Ui.dialog(SearchActivity.this, th).setTitle("换源失败").setMessage(fe).setPositiveButton("好", null), th);
                        } else if (fm == -1 && !restart) {
                            Ui.show(Ui.dialog(SearchActivity.this, th).setTitle("没对上章节")
                                    .setMessage("在「" + r.source.name + "」里没找到你下载到的最后一章。要从这个书源的第一章重新下载吗？（阅读进度会回到开头）")
                                    .setPositiveButton("重新下载", new DialogInterface.OnClickListener() {
                                        @Override public void onClick(DialogInterface d, int w) { doSwitch(r, true); }
                                    }).setNegativeButton("取消", null), th);
                        } else {
                            Toast.makeText(SearchActivity.this, "已换到「" + r.source.name + "」，后面的章节会从这里下载", Toast.LENGTH_LONG).show();
                            finish();
                        }
                    }
                });
            }
        }.start();
    }
}

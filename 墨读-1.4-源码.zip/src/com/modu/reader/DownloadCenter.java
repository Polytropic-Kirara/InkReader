package com.modu.reader;

import android.app.job.JobInfo;
import android.app.job.JobScheduler;
import android.content.ComponentName;
import android.content.Context;
import android.content.SharedPreferences;

import com.modu.reader.web.Downloader;
import com.modu.reader.web.Fetcher;
import com.modu.reader.web.WebStore;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/** Runs web-novel downloads. Work happens inside a JobScheduler job so it keeps going in the background. */
public final class DownloadCenter {
    private DownloadCenter() {}

    private static final int JOB_ID = 7001;

    public interface Stop { boolean now(); }

    public static void start(Context c) {
        try {
            JobScheduler js = (JobScheduler) c.getSystemService(Context.JOB_SCHEDULER_SERVICE);
            JobInfo job = new JobInfo.Builder(JOB_ID, new ComponentName(c, DownloadJob.class))
                    .setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY)
                    .setBackoffCriteria(15000, JobInfo.BACKOFF_POLICY_LINEAR)
                    .build();
            js.schedule(job);
        } catch (Throwable ignored) {}
    }

    public static Fetcher fetcher(Context c) {
        Fetcher f = new Fetcher();
        SharedPreferences sp = Theme.prefs(c);
        String ua = sp.getString("ua", null);
        if (ua != null && ua.length() > 0) f.userAgent = ua;
        try {
            final android.webkit.CookieManager cm = android.webkit.CookieManager.getInstance();
            f.cookies = new Fetcher.Cookies() {
                @Override public String get(String url) {
                    try { return cm.getCookie(url); } catch (Throwable t) { return null; }
                }
                @Override public void set(String url, List<String> values) {
                    try { for (String v : values) cm.setCookie(url, v); } catch (Throwable ignored) {}
                }
            };
        } catch (Throwable ignored) {}
        return f;
    }

    public static List<String> rules(Context c) {
        String r = Theme.prefs(c).getString("webRules", "");
        return new ArrayList<String>(Arrays.asList(r.split("\n")));
    }

    public static long delay(Context c) {
        return Theme.prefs(c).getInt("webDelay", 1000);
    }

    /** Downloads every book marked as downloading. Returns true if work is left (stopped early). */
    public static boolean runAll(final Context c, final Stop stop) {
        Fetcher f = fetcher(c);
        List<String> rules = rules(c);
        long delay = delay(c);
        while (!stop.now()) {
            Library.Entry next = null;
            for (Library.Entry e : Library.all(c)) {
                if ("web".equals(e.format) && "downloading".equals(e.dlState) && !e.browserOnly) { next = e; break; }
            }
            if (next == null) return false;
            final String id = next.id;
            WebStore s;
            try {
                s = WebStore.load(new File(next.path));
            } catch (Exception ex) {
                mark(c, id, "error", "书籍文件损坏", -1);
                continue;
            }
            Downloader.ChapterReader reader = reader(c, s, rules);
            int r = Downloader.run(s, f, new Downloader.Listener() {
                @Override public void onChapter(WebStore st, int count, String title) {
                    mark(c, id, null, null, count);
                }
                @Override public boolean stop() {
                    if (stop.now()) return true;
                    Library.Entry e = Library.get(c, id);
                    return e == null || !"downloading".equals(e.dlState); // paused or deleted
                }
            }, delay, rules, reader);
            if (r == Downloader.STOPPED) {
                Library.Entry e = Library.get(c, id);
                if (e != null && "downloading".equals(e.dlState)) return true; // job time is up
                continue;
            }
            mark(c, id, r == Downloader.DONE ? "done" : "error", s.get("error"), s.chapters.size());
        }
        return true;
    }

    public static java.io.File sourcesFile(Context c) {
        return new java.io.File(c.getFilesDir(), "sources.json");
    }

    public static List<com.modu.reader.web.BookSource> sources(Context c) {
        return com.modu.reader.web.SourceStore.load(sourcesFile(c));
    }

    /** Chapter reader for books added from a book source; null means "find the text automatically". */
    public static Downloader.ChapterReader reader(Context c, WebStore s, final List<String> rules) {
        String url = s.get("source");
        if (url.length() == 0) return null;
        final com.modu.reader.web.BookSource src = com.modu.reader.web.SourceStore.find(sources(c), url);
        if (src == null) return null;
        final com.modu.reader.web.SourceEngine e = new com.modu.reader.web.SourceEngine(fetcher(c));
        return new Downloader.ChapterReader() {
            @Override public List<String> read(String u, String next) throws Exception { return e.content(src, u, next, rules); }
        };
    }

    public static Downloader.TocReader tocReader(Context c, WebStore s) {
        String url = s.get("source");
        if (url.length() == 0) return null;
        final com.modu.reader.web.BookSource src = com.modu.reader.web.SourceStore.find(sources(c), url);
        if (src == null) return null;
        final com.modu.reader.web.SourceEngine e = new com.modu.reader.web.SourceEngine(fetcher(c));
        return new Downloader.TocReader() {
            @Override public List<String[]> toc(String u) throws Exception { return e.toc(src, u); }
        };
    }

    static void mark(Context c, String id, final String state, final String error, final int count) {
        Library.update(c, id, new Library.Change() {
            @Override public void apply(Library.Entry e) {
                if (state != null) e.dlState = state;
                if (error != null) e.dlError = error;
                if (count >= 0) e.dlCount = count;
            }
        });
    }

    static boolean anyPending(Context c) {
        for (Library.Entry e : Library.all(c)) if ("web".equals(e.format) && "downloading".equals(e.dlState) && !e.browserOnly) return true;
        return false;
    }
}

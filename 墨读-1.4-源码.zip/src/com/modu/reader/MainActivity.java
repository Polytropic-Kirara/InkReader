package com.modu.reader;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Parcelable;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AnimationUtils;
import android.view.animation.GridLayoutAnimationController;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity implements SharedPreferences.OnSharedPreferenceChangeListener {
    private static final int REQ_IMPORT = 1;

    private final Handler ui = new Handler();
    private final List<Library.Entry> all = new ArrayList<Library.Entry>();
    private final List<Library.Entry> items = new ArrayList<Library.Entry>();
    private final HashMap<String, Bitmap> covers = new HashMap<String, Bitmap>();
    private Theme th;
    private GridView grid;
    private Adapter adapter;
    private LinearLayout bar, continueCard;
    private View emptyView;
    private TextView noResult;
    private EditText search;
    private boolean searching, external, animateGrid = true;
    private String query = "";

    @Override protected void onCreate(Bundle saved) {
        super.onCreate(saved);
        Theme.prefs(this).registerOnSharedPreferenceChangeListener(this);
        getSharedPreferences("library", MODE_PRIVATE).registerOnSharedPreferenceChangeListener(this);
        build();
        if (DownloadCenter.anyPending(this)) DownloadCenter.start(getApplicationContext());
        if (saved == null) handleIntent(getIntent());
    }

    @Override protected void onDestroy() {
        super.onDestroy();
        Theme.prefs(this).unregisterOnSharedPreferenceChangeListener(this);
        getSharedPreferences("library", MODE_PRIVATE).unregisterOnSharedPreferenceChangeListener(this);
    }

    private final Runnable refreshLater = new Runnable() { @Override public void run() { refresh(); } };

    @Override public void onSharedPreferenceChanged(SharedPreferences p, String key) {
        if ("mode".equals(key) || "accent".equals(key)) build();
        else if ("books".equals(key)) { ui.removeCallbacks(refreshLater); ui.postDelayed(refreshLater, 600); }
    }

    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        handleIntent(intent);
    }

    @Override protected void onResume() {
        super.onResume();
        Theme now = Theme.get(this);
        if (th == null || now.night != th.night || now.accent != th.accent) build();
        refresh();
    }

    @Override public void onBackPressed() {
        if (searching) setSearching(false);
        else super.onBackPressed();
    }

    // ---- layout ------------------------------------------------------------------------

    private void build() {
        th = Theme.get(this);
        getWindow().getDecorView().setBackgroundColor(th.bg);
        Ui.bars(this, th.bg, th.bg);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(th.bg);
        root.setFitsSystemWindows(true);

        bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(Ui.dp(this, 16), Ui.dp(this, 6), Ui.dp(this, 6), Ui.dp(this, 6));
        root.addView(bar, new LinearLayout.LayoutParams(-1, Ui.dp(this, 60)));
        fillBar();

        continueCard = new LinearLayout(this);
        root.addView(continueCard, new LinearLayout.LayoutParams(-1, -2));

        FrameLayout content = new FrameLayout(this);
        grid = new GridView(this);
        int pad = Ui.dp(this, 14);
        grid.setPadding(pad, Ui.dp(this, 8), pad, pad);
        grid.setClipToPadding(false);
        grid.setNumColumns(GridView.AUTO_FIT);
        grid.setColumnWidth(Ui.dp(this, 98));
        grid.setStretchMode(GridView.STRETCH_COLUMN_WIDTH);
        grid.setVerticalSpacing(Ui.dp(this, 18));
        grid.setHorizontalSpacing(Ui.dp(this, 14));
        grid.setSelector(new android.graphics.drawable.ColorDrawable(0));
        grid.setVerticalScrollBarEnabled(false);
        adapter = new Adapter();
        grid.setAdapter(adapter);
        if (animateGrid) {
            GridLayoutAnimationController lac = new GridLayoutAnimationController(AnimationUtils.loadAnimation(this, R.anim.item_in), 0.10f, 0.12f);
            grid.setLayoutAnimation(lac);
            animateGrid = false;
        }
        grid.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override public void onItemClick(AdapterView<?> p, View v, int pos, long id) { open(items.get(pos), false); }
        });
        grid.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override public boolean onItemLongClick(AdapterView<?> p, View v, int pos, long id) {
                actions(items.get(pos));
                return true;
            }
        });
        content.addView(grid, new FrameLayout.LayoutParams(-1, -1));
        emptyView = buildEmpty();
        content.addView(emptyView, new FrameLayout.LayoutParams(-1, -1));
        noResult = Ui.text(this, "", 15, th.sub);
        noResult.setGravity(Gravity.CENTER);
        content.addView(noResult, new FrameLayout.LayoutParams(-1, -1));
        root.addView(content, new LinearLayout.LayoutParams(-1, 0, 1f));
        setContentView(root);
        refresh();
    }

    private void fillBar() {
        bar.removeAllViews();
        if (searching) {
            bar.setPadding(Ui.dp(this, 4), Ui.dp(this, 6), Ui.dp(this, 8), Ui.dp(this, 6));
            bar.addView(Ui.icon(this, Icons.BACK, th.text, new View.OnClickListener() {
                @Override public void onClick(View v) { setSearching(false); }
            }));
            search = new EditText(this);
            search.setHint("搜索书名、作者或文件名");
            search.setHintTextColor(th.sub);
            search.setTextColor(th.text);
            search.setTextSize(15);
            search.setSingleLine(true);
            search.setImeOptions(EditorInfo.IME_ACTION_SEARCH);
            search.setBackground(Ui.round(th.card, th.divider, Ui.dp(this, 20), Ui.dp(this, 1)));
            search.setPadding(Ui.dp(this, 16), 0, Ui.dp(this, 16), 0);
            search.setText(query);
            search.addTextChangedListener(new TextWatcher() {
                @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) {}
                @Override public void onTextChanged(CharSequence s, int a, int b, int c) {}
                @Override public void afterTextChanged(Editable s) { query = s.toString().trim(); filter(); }
            });
            bar.addView(search, new LinearLayout.LayoutParams(0, Ui.dp(this, 42), 1f));
            search.requestFocus();
            search.post(new Runnable() {
                @Override public void run() {
                    InputMethodManager im = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
                    if (im != null && search != null) im.showSoftInput(search, 0);
                }
            });
        } else {
            bar.setPadding(Ui.dp(this, 18), Ui.dp(this, 6), Ui.dp(this, 6), Ui.dp(this, 6));
            TextView title = Ui.text(this, "墨读", 22, th.text);
            title.setTypeface(Typeface.create(Typeface.SERIF, Typeface.BOLD));
            bar.addView(title);
            TextView sub = Ui.text(this, "  书架", 14, th.sub);
            bar.addView(sub, new LinearLayout.LayoutParams(0, -2, 1f));
            bar.addView(Ui.icon(this, Icons.SEARCH, th.text, new View.OnClickListener() {
                @Override public void onClick(View v) { setSearching(true); }
            }));
            bar.addView(Ui.icon(this, Icons.GLOBE, th.text, new View.OnClickListener() {
                @Override public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, SearchActivity.class));
                overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left_parallax);
            }
            }));
            bar.addView(Ui.icon(this, Icons.SCAN, th.text, new View.OnClickListener() {
                @Override public void onClick(View v) { openScan(); }
            }));
            bar.addView(Ui.icon(this, Icons.PLUS, th.text, new View.OnClickListener() {
                @Override public void onClick(View v) { pick(); }
            }));
            bar.addView(Ui.icon(this, Icons.SETTINGS, th.text, new View.OnClickListener() {
                @Override public void onClick(View v) {
                    startActivity(new Intent(MainActivity.this, SettingsActivity.class));
                    overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left_parallax);
                }
            }));
        }
    }

    private void setSearching(boolean on) {
        searching = on;
        if (!on) {
            query = "";
            InputMethodManager im = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
            if (im != null && search != null) im.hideSoftInputFromWindow(search.getWindowToken(), 0);
            search = null;
        }
        fillBar();
        bar.setAlpha(0.3f);
        bar.animate().alpha(1f).setDuration(180).start();
        filter();
    }

    private View buildEmpty() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER);
        int p = Ui.dp(this, 32);
        box.setPadding(p, 0, p, Ui.dp(this, 60));
        ImageView icon = new ImageView(this);
        icon.setImageDrawable(new Icons(Icons.BOOK, Theme.alpha(th.sub, 0.7f)));
        box.addView(icon, new LinearLayout.LayoutParams(Ui.dp(this, 72), Ui.dp(this, 72)));
        TextView t = Ui.text(this, "书架还是空的", 18, th.text);
        t.setPadding(0, Ui.dp(this, 14), 0, Ui.dp(this, 6));
        t.setGravity(Gravity.CENTER);
        box.addView(t);
        TextView s = Ui.text(this, "支持 TXT · EPUB · MOBI · AZW3 · FB2 · PDF", 13, th.sub);
        s.setGravity(Gravity.CENTER);
        box.addView(s);
        LinearLayout btns = new LinearLayout(this);
        btns.setGravity(Gravity.CENTER);
        btns.setPadding(0, Ui.dp(this, 22), 0, 0);
        btns.addView(Ui.pill(this, th, "扫描本地书籍", true, new View.OnClickListener() {
            @Override public void onClick(View v) { openScan(); }
        }));
        View g = new View(this);
        btns.addView(g, new LinearLayout.LayoutParams(Ui.dp(this, 12), 1));
        btns.addView(Ui.pill(this, th, "导入文件", false, new View.OnClickListener() {
            @Override public void onClick(View v) { pick(); }
        }));
        box.addView(btns);
        return box;
    }

    private void buildContinue() {
        continueCard.removeAllViews();
        Library.Entry last = null;
        for (Library.Entry e : all) if (e.lastRead > 0 && (last == null || e.lastRead > last.lastRead)) last = e;
        float hdp = getResources().getConfiguration().screenHeightDp;
        if (last == null || searching || hdp < 460) { continueCard.setVisibility(View.GONE); return; }
        continueCard.setVisibility(View.VISIBLE);
        final Library.Entry e = last;
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.HORIZONTAL);
        card.setGravity(Gravity.CENTER_VERTICAL);
        int p = Ui.dp(this, 14);
        card.setPadding(p, p, p, p);
        card.setBackground(Ui.ripple(th.accent, Ui.round(th.card, th.divider, Ui.dp(this, 16), Ui.dp(this, 1)), true));
        card.setElevation(Ui.dp(this, 1.5f));
        card.setClickable(true);
        card.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { open(e, false); } });
        Ui.pressScale(card);
        CoverView cv = new CoverView(this);
        cv.bind(e, coverOf(e), th);
        card.addView(cv, new LinearLayout.LayoutParams(Ui.dp(this, 48), Ui.dp(this, 64)));
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(Ui.dp(this, 14), 0, Ui.dp(this, 10), 0);
        col.addView(Ui.text(this, "继续阅读", 11.5f, th.accent));
        TextView t = Ui.text(this, e.title, 16, th.text);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setSingleLine(true);
        t.setEllipsize(TextUtils.TruncateAt.END);
        col.addView(t);
        String sub = String.format(Locale.US, "已读 %.0f%%", e.progress * 100)
                + (e.chapterTitle != null && e.chapterTitle.length() > 0 ? "  ·  " + e.chapterTitle : "");
        TextView s = Ui.text(this, sub, 12, th.sub);
        s.setSingleLine(true);
        s.setEllipsize(TextUtils.TruncateAt.END);
        col.addView(s);
        ProgressLine pl = new ProgressLine(this, th, e.progress);
        LinearLayout.LayoutParams plp = new LinearLayout.LayoutParams(-1, Ui.dp(this, 3));
        plp.topMargin = Ui.dp(this, 8);
        col.addView(pl, plp);
        card.addView(col, new LinearLayout.LayoutParams(0, -2, 1f));
        card.addView(Ui.icon(this, Icons.NEXT, th.sub, null));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(Ui.dp(this, 14), Ui.dp(this, 2), Ui.dp(this, 14), Ui.dp(this, 6));
        continueCard.addView(card, lp);
    }

    private void refresh() {
        all.clear();
        all.addAll(Library.all(this));
        buildContinue();
        filter();
    }

    private void filter() {
        items.clear();
        String q = query.toLowerCase(Locale.ROOT);
        for (Library.Entry e : all) {
            if (q.length() == 0 || e.title.toLowerCase(Locale.ROOT).contains(q)
                    || e.author.toLowerCase(Locale.ROOT).contains(q) || e.fileName.toLowerCase(Locale.ROOT).contains(q)) items.add(e);
        }
        adapter.notifyDataSetChanged();
        emptyView.setVisibility(all.isEmpty() ? View.VISIBLE : View.GONE);
        boolean none = !all.isEmpty() && items.isEmpty();
        noResult.setVisibility(none ? View.VISIBLE : View.GONE);
        if (none) noResult.setText("书架里没有找到「" + query + "」\n\n可以试试右上角的扫描，找手机里的书");
        if (continueCard != null && searching) continueCard.setVisibility(View.GONE);
    }

    private Bitmap coverOf(Library.Entry e) {
        if (e.cover == null) return null;
        Bitmap bm = covers.get(e.id);
        if (bm == null && !covers.containsKey(e.id)) {
            bm = BitmapFactory.decodeFile(e.cover);
            covers.put(e.id, bm);
        }
        return bm;
    }

    // ---- actions -----------------------------------------------------------------------

    private void openWeb(String url) {
        Intent i = new Intent(this, WebActivity.class);
        if (url != null) i.putExtra("url", url);
        startActivity(i);
        overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left_parallax);
    }

    private void openScan() {
        startActivity(new Intent(this, ScanActivity.class));
        overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left_parallax);
    }

    private void pick() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        try {
            startActivityForResult(i, REQ_IMPORT);
        } catch (Exception e) {
            Toast.makeText(this, "没有可用的文件选择器", Toast.LENGTH_LONG).show();
        }
    }

    @Override protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req != REQ_IMPORT || res != RESULT_OK || data == null) return;
        List<Uri> uris = new ArrayList<Uri>();
        ClipData clip = data.getClipData();
        if (clip != null) for (int i = 0; i < clip.getItemCount(); i++) uris.add(clip.getItemAt(i).getUri());
        else if (data.getData() != null) uris.add(data.getData());
        importAll(uris, false);
    }

    private void handleIntent(Intent in) {
        if (in == null || in.getAction() == null) return;
        List<Uri> uris = new ArrayList<Uri>();
        String a = in.getAction();
        if (Intent.ACTION_VIEW.equals(a) && in.getData() != null) {
            uris.add(in.getData());
        } else if (Intent.ACTION_SEND.equals(a)) {
            Parcelable p = in.getParcelableExtra(Intent.EXTRA_STREAM);
            if (p instanceof Uri) uris.add((Uri) p);
            else {
                String text = in.getStringExtra(Intent.EXTRA_TEXT);
                java.util.regex.Matcher m = text == null ? null : java.util.regex.Pattern.compile("https?://\\S+").matcher(text);
                if (m != null && m.find()) { openWeb(m.group()); if (!isTaskRoot()) finish(); return; }
            }
        } else if (Intent.ACTION_SEND_MULTIPLE.equals(a)) {
            ArrayList<Parcelable> l = in.getParcelableArrayListExtra(Intent.EXTRA_STREAM);
            if (l != null) for (Parcelable p : l) if (p instanceof Uri) uris.add((Uri) p);
        }
        if (uris.isEmpty()) return;
        external = !isTaskRoot();
        importAll(uris, true);
    }

    private void importAll(final List<Uri> uris, final boolean openAfter) {
        if (uris.isEmpty()) return;
        final AlertDialog pd = Ui.progress(this, th, "正在导入…");
        final Context app = getApplicationContext();
        new Thread() {
            @Override public void run() {
                final List<Library.Entry> ok = new ArrayList<Library.Entry>();
                final StringBuilder errors = new StringBuilder();
                for (Uri u : uris) {
                    try {
                        ok.add(Library.importUri(app, u));
                    } catch (Throwable t) {
                        errors.append(t.getMessage()).append('\n');
                    }
                }
                ui.post(new Runnable() {
                    @Override public void run() {
                        if (isFinishing() || isDestroyed()) return;
                        try { pd.dismiss(); } catch (Exception ignored) {}
                        refresh();
                        if (errors.length() > 0) {
                            AlertDialog d = Ui.show(Ui.dialog(MainActivity.this, th).setTitle("部分文件没有导入")
                                    .setMessage(errors.toString().trim()).setPositiveButton("确定", null), th);
                            d.setOnDismissListener(new DialogInterface.OnDismissListener() {
                                @Override public void onDismiss(DialogInterface di) { if (external && ok.isEmpty()) finish(); }
                            });
                        } else if (!openAfter && ok.size() > 0) {
                            Toast.makeText(MainActivity.this, "已导入 " + ok.size() + " 本", Toast.LENGTH_SHORT).show();
                        }
                        if (openAfter && ok.size() == 1) {
                            if (external) {
                                Intent i = readerIntent(ok.get(0));
                                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                                startActivity(i);
                                if (errors.length() == 0) finish();
                            } else {
                                open(ok.get(0), false);
                            }
                        }
                    }
                });
            }
        }.start();
    }

    private Intent readerIntent(Library.Entry e) {
        Intent i = new Intent(this, "pdf".equals(e.format) ? PdfActivity.class : ReaderActivity.class);
        i.putExtra("id", e.id);
        return i;
    }

    private void open(Library.Entry e, boolean newWindow) {
        Intent i = readerIntent(e);
        if (newWindow) i.addFlags(Ui.adjacentFlags());
        try {
            startActivity(i);
            if (!newWindow) overridePendingTransition(R.anim.zoom_in, R.anim.hold);
        } catch (Exception ex) {
            Toast.makeText(this, "打开失败：" + ex.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    static String status(Library.Entry e) {
        String read = e.lastRead == 0 ? "未读" : String.format(Locale.US, "已读 %.0f%%", e.progress * 100);
        if (!"web".equals(e.format)) return read;
        if ("downloading".equals(e.dlState)) return (e.browserOnly ? "待继续 · " : "下载中 · ") + e.dlCount + " 章";
        if ("paused".equals(e.dlState)) return "已暂停 · " + e.dlCount + " 章";
        if ("error".equals(e.dlState)) return "下载出错 · " + e.dlCount + " 章";
        return read;
    }

    private void actions(final Library.Entry e) {
        final List<String> opts = new ArrayList<String>();
        opts.add("打开");
        opts.add("在新窗口打开（分屏时显示在另一侧）");
        if ("web".equals(e.format)) {
            if ("downloading".equals(e.dlState) && !e.browserOnly) opts.add("暂停下载");
            else if (!"done".equals(e.dlState)) opts.add("继续下载");
            opts.add("检查更新");
            if (e.srcUrl != null && e.srcUrl.length() > 0) opts.add("换源");
            opts.add("打开来源网页");
        }
        opts.add("书籍信息");
        opts.add("从书架删除");
        Ui.show(Ui.dialog(this, th).setTitle(e.title).setItems(opts.toArray(new String[0]), new DialogInterface.OnClickListener() {
            @Override public void onClick(DialogInterface d, int which) {
                String o = opts.get(which);
                if (o.equals("打开")) open(e, false);
                else if (o.startsWith("在新窗口")) open(e, true);
                else if (o.equals("暂停下载")) DownloadCenter.mark(getApplicationContext(), e.id, "paused", null, -1);
                else if (o.equals("继续下载")) resume(e);
                else if (o.equals("检查更新")) checkUpdate(e);
                else if (o.equals("换源")) {
                    Intent i = new Intent(MainActivity.this, SearchActivity.class);
                    i.putExtra("switchFor", e.id);
                    i.putExtra("key", e.title);
                    startActivity(i);
                }
                else if (o.equals("打开来源网页")) openWeb(e.source);
                else if (o.equals("书籍信息")) info(e);
                else confirmDelete(e);
            }
        }), th);
    }

    private void resume(Library.Entry e) {
        if (e.browserOnly) {
            Intent i = new Intent(this, WebActivity.class);
            i.putExtra("url", e.source);
            i.putExtra("resume", e.id);
            startActivity(i);
            return;
        }
        DownloadCenter.mark(getApplicationContext(), e.id, "downloading", "", -1);
        DownloadCenter.start(getApplicationContext());
        Toast.makeText(this, "继续下载《" + e.title + "》", Toast.LENGTH_SHORT).show();
    }

    private void checkUpdate(final Library.Entry e) {
        final AlertDialog pd = Ui.progress(this, th, "正在检查更新…");
        final Context app = getApplicationContext();
        new Thread() {
            @Override public void run() {
                String msg;
                try {
                    com.modu.reader.web.WebStore s = com.modu.reader.web.WebStore.load(new java.io.File(e.path));
                    int n = com.modu.reader.web.Downloader.checkUpdate(s, DownloadCenter.fetcher(app), DownloadCenter.rules(app), DownloadCenter.tocReader(app, s));
                    if (n > 0) {
                        DownloadCenter.mark(app, e.id, "downloading", "", -1);
                        if (e.browserOnly) msg = "有新章节。这个网站需要浏览器模式，请在书架长按选择「继续下载」";
                        else { DownloadCenter.start(app); msg = s.tocMode() ? "发现 " + n + " 个新章节，开始下载" : "发现新章节，开始下载"; }
                    } else {
                        msg = "暂时没有新章节";
                    }
                } catch (Throwable t) {
                    msg = "检查失败：" + t.getMessage();
                }
                final String m = msg;
                ui.post(new Runnable() {
                    @Override public void run() {
                        try { pd.dismiss(); } catch (Exception ignored) {}
                        Toast.makeText(MainActivity.this, m, Toast.LENGTH_LONG).show();
                    }
                });
            }
        }.start();
    }

    private void info(Library.Entry e) {
        String msg = "书名：" + e.title
                + (e.author.length() > 0 ? "\n作者：" + e.author : "")
                + "\n格式：" + e.format.toUpperCase(Locale.US)
                + "\n文件：" + e.fileName
                + ("web".equals(e.format) ? "\n来源：" + e.source + "\n已下载：" + e.dlCount + " 章" + (e.dlError != null && e.dlError.length() > 0 && "error".equals(e.dlState) ? "\n出错原因：" + e.dlError : "")
                        : String.format(Locale.US, "\n大小：%.2f MB", e.size / 1048576.0))
                + String.format(Locale.US, "\n进度：%.1f%%", e.progress * 100);
        Ui.show(Ui.dialog(this, th).setTitle("书籍信息").setMessage(msg).setPositiveButton("好", null), th);
    }

    private void confirmDelete(final Library.Entry e) {
        Ui.show(Ui.dialog(this, th).setTitle("删除《" + e.title + "》？")
                .setMessage("web".equals(e.format) ? "会从书架移除并删除已下载的章节。" : "会从书架移除并删除墨读里保存的副本，不影响手机上的原文件。")
                .setPositiveButton("删除", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) {
                        Library.remove(MainActivity.this, e);
                        Bitmap b = covers.remove(e.id);
                        if (b != null) b.recycle();
                        refresh();
                    }
                }).setNegativeButton("取消", null), th);
    }

    // ---- views -------------------------------------------------------------------------

    /** Book cover: the real cover image, or a generated cloth-bound look with the title. */
    static final class CoverView extends View {
        private static final int[][] CLOTH = {
                {0xFF5B7489, 0xFF3E5468}, {0xFF8A5A44, 0xFF6A412F}, {0xFF5E7A5A, 0xFF435C40}, {0xFF7A6390, 0xFF5A466E},
                {0xFF9A7B45, 0xFF7A5E30}, {0xFF4F7C7C, 0xFF365D5D}, {0xFF94505E, 0xFF723A46}};
        private Bitmap bitmap;
        private String title = "", format = "";
        private int[] cloth = CLOTH[0];
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
        private final android.text.TextPaint tp = new android.text.TextPaint(Paint.ANTI_ALIAS_FLAG);
        private final RectF r = new RectF();
        private final android.graphics.Path clip = new android.graphics.Path();

        CoverView(Context c) {
            super(c);
            setElevation(Ui.dp(c, 3));
            setOutlineProvider(new android.view.ViewOutlineProvider() {
                @Override public void getOutline(View v, android.graphics.Outline o) {
                    o.setRoundRect(0, 0, v.getWidth(), v.getHeight(), Ui.dp(v.getContext(), 6));
                }
            });
        }

        void bind(String t, Bitmap bm) {
            bitmap = bm;
            title = t;
            format = "";
            cloth = CLOTH[(t.hashCode() & 0x7FFFFFFF) % CLOTH.length];
            invalidate();
        }

        void bind(Library.Entry e, Bitmap bm, Theme th) {
            bitmap = bm;
            title = e.title;
            format = "web".equals(e.format) ? "网文" : e.format.toUpperCase(Locale.US);
            cloth = CLOTH[(e.title.hashCode() & 0x7FFFFFFF) % CLOTH.length];
            invalidate();
        }

        @Override protected void onDraw(Canvas c) {
            float w = getWidth(), h = getHeight(), d = getResources().getDisplayMetrics().density;
            float rad = 6 * d;
            r.set(0, 0, w, h);
            clip.reset();
            clip.addRoundRect(r, rad, rad, android.graphics.Path.Direction.CW);
            c.save();
            c.clipPath(clip);
            if (bitmap != null && !bitmap.isRecycled()) {
                float s = Math.max(w / bitmap.getWidth(), h / bitmap.getHeight());
                float bw = bitmap.getWidth() * s, bh = bitmap.getHeight() * s;
                android.graphics.RectF dst = new android.graphics.RectF((w - bw) / 2, (h - bh) / 2, (w + bw) / 2, (h + bh) / 2);
                c.drawBitmap(bitmap, null, dst, p);
            } else {
                p.setShader(new android.graphics.LinearGradient(0, 0, w, h, cloth[0], cloth[1], android.graphics.Shader.TileMode.CLAMP));
                c.drawRect(r, p);
                p.setShader(null);
                p.setColor(0x22000000); // spine
                c.drawRect(0, 0, w * 0.07f, h, p);
                p.setColor(0x33FFFFFF);
                c.drawRect(w * 0.07f, 0, w * 0.075f + d, h, p);
                p.setColor(0x55FFFFFF); // title frame
                p.setStyle(Paint.Style.STROKE);
                p.setStrokeWidth(d);
                c.drawRect(w * 0.18f, h * 0.12f, w * 0.88f, h * 0.62f, p);
                p.setStyle(Paint.Style.FILL);
                tp.setColor(0xF2FFFFFF);
                tp.setTextSize(Math.max(10 * d, Math.min(15 * d, w / 7f)));
                tp.setTypeface(Typeface.create(Typeface.SERIF, Typeface.BOLD));
                int tw = (int) (w * 0.62f);
                if (tw > 10) {
                    android.text.StaticLayout sl = android.text.StaticLayout.Builder.obtain(title, 0, title.length(), tp, tw)
                            .setAlignment(android.text.Layout.Alignment.ALIGN_CENTER).setMaxLines(4)
                            .setEllipsize(TextUtils.TruncateAt.END).setLineSpacing(0, 1.1f).build();
                    float boxH = h * 0.5f - 8 * d;
                    c.save();
                    c.translate(w * 0.22f, h * 0.12f + Math.max(4 * d, (boxH - sl.getHeight()) / 2f + 4 * d));
                    sl.draw(c);
                    c.restore();
                }
            }
            // format badge
            if (format.length() == 0) { c.restore(); return; }
            tp.setTextSize(8.5f * d);
            tp.setTypeface(Typeface.DEFAULT_BOLD);
            float bw = tp.measureText(format) + 8 * d;
            p.setColor(0x88000000);
            r.set(w - bw - 4 * d, h - 16 * d, w - 4 * d, h - 4 * d);
            c.drawRoundRect(r, 3 * d, 3 * d, p);
            tp.setColor(0xFFFFFFFF);
            c.drawText(format, r.left + 4 * d, r.bottom - 3.5f * d, tp);
            c.restore();
        }
    }

    static final class ProgressLine extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Theme th;
        private float value;
        private final RectF r = new RectF();

        ProgressLine(Context c, Theme th, float v) {
            super(c);
            this.th = th;
            value = v;
        }

        void set(float v) { value = v; invalidate(); }

        @Override protected void onDraw(Canvas c) {
            float h = getHeight();
            r.set(0, 0, getWidth(), h);
            p.setColor(Theme.alpha(th.text, 0.10f));
            c.drawRoundRect(r, h / 2, h / 2, p);
            if (value > 0) {
                r.set(0, 0, Math.max(h, getWidth() * Math.min(1f, value)), h);
                p.setColor(th.accent);
                c.drawRoundRect(r, h / 2, h / 2, p);
            }
        }
    }

    private static class Holder {
        CoverView cover;
        ProgressLine line;
        TextView title, progress;
    }

    private class Adapter extends BaseAdapter {
        @Override public int getCount() { return items.size(); }
        @Override public Object getItem(int p) { return items.get(p); }
        @Override public long getItemId(int p) { return p; }

        @Override public View getView(int pos, View convert, ViewGroup parent) {
            Holder h;
            if (convert == null) {
                Context c = MainActivity.this;
                LinearLayout cell = new LinearLayout(c) {
                    @Override protected void onMeasure(int ws, int hs) {
                        int width = MeasureSpec.getSize(ws);
                        Holder hh = (Holder) getTag();
                        LinearLayout.LayoutParams lp = (LinearLayout.LayoutParams) hh.cover.getLayoutParams();
                        if (lp.height != width * 4 / 3) lp.height = width * 4 / 3;
                        super.onMeasure(ws, hs);
                    }
                };
                cell.setOrientation(LinearLayout.VERTICAL);
                cell.setClipChildren(false);
                h = new Holder();
                h.cover = new CoverView(c);
                cell.addView(h.cover, new LinearLayout.LayoutParams(-1, Ui.dp(c, 130)));
                h.line = new ProgressLine(c, th, 0);
                LinearLayout.LayoutParams llp = new LinearLayout.LayoutParams(-1, Ui.dp(c, 2.5f));
                llp.topMargin = Ui.dp(c, 7);
                cell.addView(h.line, llp);
                h.title = Ui.text(c, "", 13, th.text);
                h.title.setMaxLines(2);
                h.title.setEllipsize(TextUtils.TruncateAt.END);
                h.title.setPadding(0, Ui.dp(c, 5), 0, 0);
                h.title.setLineSpacing(0, 1.1f);
                cell.addView(h.title);
                h.progress = Ui.text(c, "", 11, th.sub);
                cell.addView(h.progress);
                cell.setTag(h);
                Ui.pressScale(cell);
                convert = cell;
            } else {
                h = (Holder) convert.getTag();
            }
            Library.Entry e = items.get(pos);
            h.cover.bind(e, coverOf(e), th);
            h.line.set(e.lastRead == 0 ? 0 : e.progress);
            h.line.setVisibility(e.lastRead == 0 ? View.INVISIBLE : View.VISIBLE);
            h.title.setText(e.title);
            h.progress.setText(status(e));
            return convert;
        }
    }
}

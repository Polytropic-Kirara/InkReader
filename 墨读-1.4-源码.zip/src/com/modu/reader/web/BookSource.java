package com.modu.reader.web;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** A book source in the 阅读 (Legado) 3.x JSON format. Unknown fields are kept so export round-trips. */
public final class BookSource {
    public String name = "", url = "", group = "", searchUrl = "", header = "", comment = "";
    public boolean enabled = true;
    public Map<String, Object> search, info, toc, content;
    public Map<String, Object> raw;
    public boolean usesJs;

    public static List<BookSource> parseAll(String text) {
        Object o = Json.parse(text.trim());
        List<BookSource> out = new ArrayList<BookSource>();
        if (o instanceof List) { for (Object x : (List<?>) o) { BookSource s = from(x); if (s != null) out.add(s); } }
        else { BookSource s = from(o); if (s != null) out.add(s); }
        return out;
    }

    public static BookSource from(Object o) {
        Map<String, Object> m = Json.map(o);
        BookSource s = new BookSource();
        s.raw = m;
        s.url = Json.str(m, "bookSourceUrl").trim();
        if (s.url.length() == 0) return null;
        s.name = Json.str(m, "bookSourceName").trim();
        if (s.name.length() == 0) s.name = s.url;
        s.group = Json.str(m, "bookSourceGroup");
        s.searchUrl = Json.str(m, "searchUrl");
        s.header = Json.str(m, "header");
        s.comment = Json.str(m, "bookSourceComment");
        Object en = m.get("enabled");
        s.enabled = !(en instanceof Boolean) || (Boolean) en;
        s.search = Json.map(m.get("ruleSearch"));
        s.info = Json.map(m.get("ruleBookInfo"));
        s.toc = Json.map(m.get("ruleToc"));
        s.content = Json.map(m.get("ruleContent"));
        s.usesJs = Rules.usesJs(s.searchUrl) || Rules.usesJs(s.header) || js(s.search) || js(s.info) || js(s.toc) || js(s.content);
        return s;
    }

    private static boolean js(Map<String, Object> rules) {
        for (Object v : rules.values()) if (v instanceof String && Rules.usesJs((String) v)) return true;
        return false;
    }

    public String rule(Map<String, Object> rules, String key) {
        Object v = rules.get(key);
        return v == null ? "" : String.valueOf(v).trim();
    }

    /** Search can run without JavaScript. */
    public boolean canSearch() {
        return searchUrl.length() > 0 && !Rules.usesJs(searchUrl) && rule(search, "bookList").length() > 0;
    }

    public Map<String, Object> toMap() {
        Map<String, Object> m = raw != null ? raw : new LinkedHashMap<String, Object>();
        m.put("enabled", enabled);
        return m;
    }

    public static String writeAll(List<BookSource> list) {
        List<Object> l = new ArrayList<Object>();
        for (BookSource s : list) l.add(s.toMap());
        return Json.write(l);
    }
}

package com.modu.reader;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Handler;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import com.modu.reader.core.Util;
import com.modu.reader.web.BookSource;
import com.modu.reader.web.Fetcher;
import com.modu.reader.web.SourceEngine;
import com.modu.reader.web.SourceStore;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

/** Imports and manages book sources (阅读 / Legado 3.x JSON format). */
public class SourcesActivity extends Activity {
    private static final int REQ_FILE = 21;

    private Theme th;
    private final Handler ui = new Handler();
    private List<BookSource> list = new ArrayList<BookSource>();
    private BaseAdapter adapter;
    private TextView summary;

    @Override protected void onCreate(Bundle saved) {
        super.onCreate(saved);
        th = Theme.get(this);
        getWindow().getDecorView().setBackgroundColor(th.bg);
        Ui.bars(this, th.bg, th.bg);
        list = DownloadCenter.sources(this);
        build();
        refresh();
        if (list.isEmpty()) importMenu();
    }

    @Override public void finish() {
        super.finish();
        overridePendingTransition(R.anim.slide_in_left_parallax, R.anim.slide_out_right);
    }

    private void build() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(th.bg);
        root.setFitsSystemWindows(true);
        LinearLayout bar = new LinearLayout(this);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(Ui.dp(this, 4), 0, Ui.dp(this, 6), 0);
        bar.addView(Ui.icon(this, Icons.BACK, th.text, new View.OnClickListener() {
            @Override public void onClick(View v) { finish(); }
        }));
        TextView t = Ui.text(this, "书源管理", 19, th.text);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        bar.addView(t, new LinearLayout.LayoutParams(0, -2, 1f));
        bar.addView(Ui.icon(this, Icons.SETTINGS, th.text, new View.OnClickListener() {
            @Override public void onClick(View v) { moreMenu(); }
        }));
        bar.addView(Ui.icon(this, Icons.PLUS, th.text, new View.OnClickListener() {
            @Override public void onClick(View v) { importMenu(); }
        }));
        root.addView(bar, new LinearLayout.LayoutParams(-1, Ui.dp(this, 56)));
        summary = Ui.text(this, "", 12.5f, th.sub);
        summary.setPadding(Ui.dp(this, 20), 0, Ui.dp(this, 20), Ui.dp(this, 8));
        summary.setLineSpacing(0, 1.3f);
        root.addView(summary);

        ListView lv = new ListView(this);
        lv.setDivider(null);
        lv.setSelector(new android.graphics.drawable.ColorDrawable(0));
        adapter = new BaseAdapter() {
            @Override public int getCount() { return list.size(); }
            @Override public Object getItem(int p) { return list.get(p); }
            @Override public long getItemId(int p) { return p; }
            @Override public View getView(int p, View v, ViewGroup parent) { return row(list.get(p)); }
        };
        lv.setAdapter(adapter);
        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override public void onItemClick(AdapterView<?> a, View v, int pos, long id) { itemMenu(list.get(pos)); }
        });
        root.addView(lv, new LinearLayout.LayoutParams(-1, 0, 1f));
        setContentView(root);
    }

    private View row(final BookSource s) {
        LinearLayout r = new LinearLayout(this);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.setPadding(Ui.dp(this, 20), Ui.dp(this, 10), Ui.dp(this, 14), Ui.dp(this, 10));
        r.setBackground(Ui.ripple(th.accent, null, true));
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        TextView n = Ui.text(this, s.name + (s.group.length() > 0 ? "　[" + s.group + "]" : ""), 15, s.enabled ? th.text : th.sub);
        n.setSingleLine(true);
        n.setEllipsize(TextUtils.TruncateAt.END);
        col.addView(n);
        TextView u = Ui.text(this, s.url, 11.5f, th.sub);
        u.setSingleLine(true);
        u.setEllipsize(TextUtils.TruncateAt.MIDDLE);
        col.addView(u);
        if (!s.canSearch() || s.usesJs) {
            TextView w = Ui.text(this, !s.canSearch() ? "搜索需要 JavaScript，暂不支持" : "部分规则用了 JavaScript，可能读不全", 11, 0xFFC0603A);
            w.setPadding(0, Ui.dp(this, 2), 0, 0);
            col.addView(w);
        }
        r.addView(col, new LinearLayout.LayoutParams(0, -2, 1f));
        Switch sw = Ui.toggle(this, th, s.enabled, new CompoundButton.OnCheckedChangeListener() {
            @Override public void onCheckedChanged(CompoundButton b, boolean on) {
                s.enabled = on;
                save();
                refreshSummary();
            }
        });
        sw.setFocusable(false);
        r.addView(sw);
        r.setDescendantFocusability(ViewGroup.FOCUS_BLOCK_DESCENDANTS);
        return r;
    }

    private void refresh() {
        adapter.notifyDataSetChanged();
        refreshSummary();
    }

    private void refreshSummary() {
        int on = 0, js = 0;
        for (BookSource s : list) { if (s.enabled) on++; if (!s.canSearch()) js++; }
        summary.setText(list.isEmpty() ? "还没有书源。点右上角 + 导入，支持「阅读」App 导出的书源 JSON（单个或数组）。"
                : "共 " + list.size() + " 个书源，已启用 " + on + " 个" + (js > 0 ? "；" + js + " 个需要 JavaScript，无法用来搜索" : "") + "\n点一下可以测试或删除。");
    }

    private void save() {
        try { SourceStore.save(DownloadCenter.sourcesFile(this), list); } catch (Exception e) {
            Toast.makeText(this, "保存失败：" + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    // ---- import ------------------------------------------------------------------------

    private void importMenu() {
        String[] opts = {"从剪贴板导入", "输入网址导入", "从文件导入", "手动粘贴 JSON"};
        Ui.show(Ui.dialog(this, th).setTitle("导入书源").setItems(opts, new DialogInterface.OnClickListener() {
            @Override public void onClick(DialogInterface d, int which) {
                if (which == 0) fromClipboard();
                else if (which == 1) fromUrl();
                else if (which == 2) fromFile();
                else manual();
            }
        }), th);
    }

    private void fromClipboard() {
        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        ClipData c = cm == null ? null : cm.getPrimaryClip();
        String text = c != null && c.getItemCount() > 0 && c.getItemAt(0).getText() != null ? c.getItemAt(0).getText().toString().trim() : "";
        if (text.length() == 0) { Toast.makeText(this, "剪贴板是空的", Toast.LENGTH_SHORT).show(); return; }
        if (text.startsWith("http")) { download(text); return; }
        importText(text);
    }

    private EditText input(String hint, boolean multi) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setTextColor(th.text);
        e.setHintTextColor(th.sub);
        e.setTextSize(14);
        if (multi) { e.setMinLines(5); e.setMaxLines(10); e.setGravity(Gravity.TOP); } else e.setSingleLine(true);
        e.setBackground(Ui.round(th.card, th.divider, Ui.dp(this, 10), Ui.dp(this, 1)));
        int p = Ui.dp(this, 12);
        e.setPadding(p, p, p, p);
        return e;
    }

    private LinearLayout wrap(View v) {
        LinearLayout l = new LinearLayout(this);
        int p = Ui.dp(this, 22);
        l.setPadding(p, Ui.dp(this, 8), p, 0);
        l.addView(v, new LinearLayout.LayoutParams(-1, -2));
        return l;
    }

    private void fromUrl() {
        final EditText e = input("https://…/sources.json", false);
        Ui.show(Ui.dialog(this, th).setTitle("书源网址").setView(wrap(e))
                .setPositiveButton("导入", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) { download(e.getText().toString().trim()); }
                }).setNegativeButton("取消", null), th);
    }

    private void manual() {
        final EditText e = input("把书源 JSON 粘贴到这里", true);
        Ui.show(Ui.dialog(this, th).setTitle("粘贴书源").setView(wrap(e))
                .setPositiveButton("导入", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) { importText(e.getText().toString()); }
                }).setNegativeButton("取消", null), th);
    }

    private void fromFile() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        try { startActivityForResult(i, REQ_FILE); } catch (Exception e) {
            Toast.makeText(this, "没有可用的文件选择器", Toast.LENGTH_SHORT).show();
        }
    }

    @Override protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req != REQ_FILE || res != RESULT_OK || data == null || data.getData() == null) return;
        try {
            InputStream in = getContentResolver().openInputStream(data.getData());
            importText(new String(Util.readAll(in), "UTF-8"));
        } catch (Exception e) {
            Toast.makeText(this, "读取文件失败：" + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private void download(final String url) {
        if (!url.startsWith("http")) { Toast.makeText(this, "网址要以 http 开头", Toast.LENGTH_SHORT).show(); return; }
        final AlertDialog pd = Ui.progress(this, th, "正在下载书源…");
        final Context app = getApplicationContext();
        new Thread() {
            @Override public void run() {
                String text = null, err = null;
                try { text = DownloadCenter.fetcher(app).get(url, null).html; } catch (Throwable t) { err = t.getMessage(); }
                final String ft = text, fe = err;
                ui.post(new Runnable() {
                    @Override public void run() {
                        try { pd.dismiss(); } catch (Exception ignored) {}
                        if (ft != null) importText(ft);
                        else Toast.makeText(SourcesActivity.this, "下载失败：" + fe, Toast.LENGTH_LONG).show();
                    }
                });
            }
        }.start();
    }

    private void importText(String text) {
        List<BookSource> in;
        try {
            in = BookSource.parseAll(text);
        } catch (Exception e) {
            Ui.show(Ui.dialog(this, th).setTitle("无法识别").setMessage("这不是有效的书源 JSON：" + e.getMessage()
                    + "\n\n墨读支持「阅读」3.x 导出的书源（含 bookSourceUrl、ruleSearch 等字段）。").setPositiveButton("好", null), th);
            return;
        }
        if (in.isEmpty()) { Toast.makeText(this, "没有找到书源", Toast.LENGTH_LONG).show(); return; }
        int js = 0;
        for (BookSource s : in) if (!s.canSearch()) js++;
        int[] r = SourceStore.merge(list, in);
        save();
        refresh();
        Ui.show(Ui.dialog(this, th).setTitle("导入完成")
                .setMessage("新增 " + r[0] + " 个，更新 " + r[1] + " 个。" + (js > 0 ? "\n其中 " + js + " 个的搜索需要 JavaScript，墨读暂不支持，搜索时会跳过它们。" : ""))
                .setPositiveButton("好", null), th);
    }

    // ---- per source & bulk -------------------------------------------------------------

    private void itemMenu(final BookSource s) {
        String[] opts = {"测试搜索", s.enabled ? "停用" : "启用", "删除"};
        Ui.show(Ui.dialog(this, th).setTitle(s.name).setItems(opts, new DialogInterface.OnClickListener() {
            @Override public void onClick(DialogInterface d, int which) {
                if (which == 0) test(s);
                else if (which == 1) { s.enabled = !s.enabled; save(); refresh(); }
                else { list.remove(s); save(); refresh(); }
            }
        }), th);
    }

    private void test(final BookSource s) {
        final EditText e = input("输入一个书名，例如：斗破苍穹", false);
        Ui.show(Ui.dialog(this, th).setTitle("测试「" + s.name + "」").setView(wrap(e))
                .setPositiveButton("搜索", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) { runTest(s, e.getText().toString().trim()); }
                }).setNegativeButton("取消", null), th);
    }

    private void runTest(final BookSource s, final String key) {
        if (key.length() == 0) return;
        final AlertDialog pd = Ui.progress(this, th, "正在测试…");
        final Context app = getApplicationContext();
        new Thread() {
            @Override public void run() {
                StringBuilder sb = new StringBuilder();
                try {
                    Fetcher f = DownloadCenter.fetcher(app);
                    f.attempts = 1;
                    SourceEngine e = new SourceEngine(f);
                    List<SourceEngine.Result> rs = e.search(s, key, 1);
                    sb.append("搜索：找到 ").append(rs.size()).append(" 本\n");
                    if (!rs.isEmpty()) {
                        SourceEngine.Result r = rs.get(0);
                        sb.append("第一本：").append(r.name).append(" / ").append(r.author).append('\n');
                        SourceEngine.Info in = e.info(s, r);
                        List<String[]> toc = e.toc(s, in.tocUrl);
                        sb.append("目录：").append(toc.size()).append(" 章\n");
                        if (!toc.isEmpty()) {
                            List<String> c = e.content(s, toc.get(0)[1], toc.size() > 1 ? toc.get(1)[1] : null, null);
                            int chars = 0;
                            for (String l : c) chars += l.length();
                            sb.append("正文：第一章 ").append(chars).append(" 字");
                            if (!c.isEmpty()) sb.append("\n\n").append(c.get(0).length() > 60 ? c.get(0).substring(0, 60) + "…" : c.get(0));
                        }
                    }
                } catch (Throwable t) {
                    sb.append("\n出错：").append(t.getMessage());
                }
                final String msg = sb.toString();
                ui.post(new Runnable() {
                    @Override public void run() {
                        try { pd.dismiss(); } catch (Exception ignored) {}
                        Ui.show(Ui.dialog(SourcesActivity.this, th).setTitle("测试结果").setMessage(msg).setPositiveButton("好", null), th);
                    }
                });
            }
        }.start();
    }

    private void moreMenu() {
        String[] opts = {"全部启用", "全部停用", "删除不支持的书源", "导出全部到剪贴板", "删除全部"};
        Ui.show(Ui.dialog(this, th).setTitle("书源").setItems(opts, new DialogInterface.OnClickListener() {
            @Override public void onClick(DialogInterface d, int which) {
                if (which == 0 || which == 1) { for (BookSource s : list) s.enabled = which == 0; }
                else if (which == 2) {
                    List<BookSource> keep = new ArrayList<BookSource>();
                    for (BookSource s : list) if (s.canSearch()) keep.add(s);
                    list = keep;
                } else if (which == 3) {
                    ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                    if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("书源", BookSource.writeAll(list)));
                    Toast.makeText(SourcesActivity.this, "已复制 " + list.size() + " 个书源", Toast.LENGTH_SHORT).show();
                    return;
                } else {
                    confirmClear();
                    return;
                }
                save();
                refresh();
            }
        }), th);
    }

    private void confirmClear() {
        Ui.show(Ui.dialog(this, th).setTitle("删除全部书源？").setMessage("书架上已经下载的书不受影响，但换源和继续下载需要对应的书源。")
                .setPositiveButton("删除", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) { list.clear(); save(); refresh(); }
                }).setNegativeButton("取消", null), th);
    }
}

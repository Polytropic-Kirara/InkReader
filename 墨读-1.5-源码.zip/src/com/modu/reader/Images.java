package com.modu.reader;

import android.graphics.Bitmap;
import android.os.Handler;
import android.os.Looper;

import com.modu.reader.web.Fetcher;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Small cover-image loader with an in-memory cache. */
final class Images {
    interface Target { void set(String url, Bitmap b); }

    private static final ExecutorService POOL = Executors.newFixedThreadPool(3);
    private static final Handler UI = new Handler(Looper.getMainLooper());
    private static final Map<String, Bitmap> CACHE = new LinkedHashMap<String, Bitmap>(64, 0.75f, true) {
        @Override protected boolean removeEldestEntry(Map.Entry<String, Bitmap> e) { return size() > 60; }
    };

    static synchronized Bitmap cached(String url) { return CACHE.get(url); }

    private static synchronized void put(String url, Bitmap b) { CACHE.put(url, b); }

    static void load(final String url, final Target t) {
        if (url == null || url.length() == 0) return;
        Bitmap c = cached(url);
        if (c != null) { t.set(url, c); return; }
        POOL.submit(new Runnable() {
            @Override public void run() {
                try {
                    Fetcher f = new Fetcher();
                    f.timeoutMs = 10000;
                    final Bitmap b = Library.decodeScaled(f.bytes(url, null), 240);
                    if (b == null) return;
                    put(url, b);
                    UI.post(new Runnable() { @Override public void run() { t.set(url, b); } });
                } catch (Throwable ignored) {}
            }
        });
    }

    static byte[] bytes(String url) {
        try {
            Fetcher f = new Fetcher();
            f.timeoutMs = 10000;
            return f.bytes(url, null);
        } catch (Throwable t) {
            return null;
        }
    }
}

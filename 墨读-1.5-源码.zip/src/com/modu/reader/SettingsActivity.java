package com.modu.reader;

import android.app.Activity;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

/** Appearance and reading settings. Changes apply live in every open window (split screen too). */
public class SettingsActivity extends Activity implements SharedPreferences.OnSharedPreferenceChangeListener {
    private SharedPreferences sp;
    private Theme th;
    private ScrollView scroll;

    @Override protected void onCreate(Bundle saved) {
        super.onCreate(saved);
        sp = Theme.prefs(this);
        sp.registerOnSharedPreferenceChangeListener(this);
        build();
    }

    @Override protected void onDestroy() {
        super.onDestroy();
        sp.unregisterOnSharedPreferenceChangeListener(this);
    }

    @Override public void onSharedPreferenceChanged(SharedPreferences p, String key) {
        if ("webRules".equals(key) || "ua".equals(key) || "webHistory".equals(key)) return; // typing in the rules box
        build();
    }

    @Override public void finish() {
        super.finish();
        overridePendingTransition(R.anim.slide_in_left_parallax, R.anim.slide_out_right);
    }

    private void build() {
        final int keep = scroll != null ? scroll.getScrollY() : 0;
        th = Theme.get(this);
        getWindow().getDecorView().setBackgroundColor(th.bg);
        Ui.bars(this, th.bg, th.bg);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(th.bg);
        root.setFitsSystemWindows(true);
        LinearLayout bar = new LinearLayout(this);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(Ui.dp(this, 4), 0, Ui.dp(this, 8), 0);
        bar.addView(Ui.icon(this, Icons.BACK, th.text, new View.OnClickListener() {
            @Override public void onClick(View v) { finish(); }
        }));
        TextView title = Ui.text(this, "设置", 19, th.text);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        bar.addView(title);
        root.addView(bar, new LinearLayout.LayoutParams(-1, Ui.dp(this, 56)));

        scroll = new ScrollView(this);
        LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setPadding(Ui.dp(this, 14), Ui.dp(this, 4), Ui.dp(this, 14), Ui.dp(this, 24));
        scroll.addView(list);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1f));

        // appearance
        LinearLayout c1 = card(list, "外观");
        c1.addView(choiceRow("显示模式", Theme.MODE_NAMES, sp.getInt("mode", 0), new Pick() {
            @Override public void on(int i) { sp.edit().putInt("mode", i).apply(); }
        }));
        c1.addView(sub("夜间模式为黑底，适合关灯后阅读；跟随系统会随手机的深色模式切换。"));
        c1.addView(label("主题色"));
        LinearLayout acc = new LinearLayout(this);
        int sel = sp.getInt("accent", 0);
        for (int i = 0; i < Theme.ACCENTS.length; i++) {
            final int idx = i;
            acc.addView(accentDot(Theme.ACCENTS[i], Theme.ACCENT_NAMES[i], i == sel, new View.OnClickListener() {
                @Override public void onClick(View v) { sp.edit().putInt("accent", idx).apply(); }
            }));
        }
        c1.addView(hscroll(acc));

        // reading backgrounds
        LinearLayout c2 = card(list, "阅读背景");
        c2.addView(label("日间"));
        c2.addView(hscroll(swatches(false)));
        c2.addView(label("夜间"));
        c2.addView(hscroll(swatches(true)));

        // page turning
        LinearLayout c3 = card(list, "翻页");
        c3.addView(choiceRow("翻页动画", Theme.ANIM_NAMES, sp.getInt("anim", PageView.ANIM_CURL), new Pick() {
            @Override public void on(int i) { sp.edit().putInt("anim", i).apply(); }
        }));
        c3.addView(sub("仿真：像翻纸书一样卷起页角；覆盖：新页从上面滑过；平移：整页左右推动；滚动：像网页一样上下连续滚动，章节自动衔接。"));
        LinearLayout vr = new LinearLayout(this);
        vr.setGravity(Gravity.CENTER_VERTICAL);
        vr.setPadding(0, Ui.dp(this, 10), 0, Ui.dp(this, 2));
        vr.addView(Ui.text(this, "音量键翻页", 14.5f, th.text), new LinearLayout.LayoutParams(0, -2, 1f));
        vr.addView(Ui.toggle(this, th, sp.getBoolean("volume", true), new CompoundButton.OnCheckedChangeListener() {
            @Override public void onCheckedChanged(CompoundButton b, boolean on) { sp.edit().putBoolean("volume", on).apply(); }
        }));
        c3.addView(vr);

        LinearLayout cw = card(list, "网页导入");
        final int[] delays = {500, 1000, 2000, 3000};
        String[] dn = {"0.5 秒", "1 秒", "2 秒", "3 秒"};
        int cur = sp.getInt("webDelay", 1000), di = 1;
        for (int i = 0; i < delays.length; i++) if (delays[i] == cur) di = i;
        cw.addView(choiceRow("每章抓取间隔", dn, di, new Pick() {
            @Override public void on(int i) { sp.edit().putInt("webDelay", delays[i]).apply(); }
        }));
        cw.addView(sub("间隔长一点更不容易被网站限制。"));
        cw.addView(label("自定义过滤"));
        android.widget.EditText rules = new android.widget.EditText(this);
        rules.setText(sp.getString("webRules", ""));
        rules.setHint("每行一条，出现在正文里就会被删掉\n例如：本书由某某网首发\n也支持正则表达式");
        rules.setHintTextColor(th.sub);
        rules.setTextColor(th.text);
        rules.setTextSize(13.5f);
        rules.setMinLines(3);
        rules.setGravity(Gravity.TOP);
        rules.setBackground(Ui.round(th.bg, th.divider, Ui.dp(this, 10), Ui.dp(this, 1)));
        int rp = Ui.dp(this, 10);
        rules.setPadding(rp, rp, rp, rp);
        rules.addTextChangedListener(new android.text.TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) {}
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) {}
            @Override public void afterTextChanged(android.text.Editable e) { sp.edit().putString("webRules", e.toString()).apply(); }
        });
        cw.addView(rules, new LinearLayout.LayoutParams(-1, -2));
        cw.addView(sub("常见的广告句子（「请收藏本站」「最新章节」「手机版阅读」之类）已经会自动去掉，这里用来补充个别网站特有的。"));

        LinearLayout cf = card(list, "问题反馈");
        java.io.File[] crashes = App.crashes();
        cf.addView(sub(crashes.length == 0 ? "没有崩溃记录。如果遇到闪退，这里会自动保存错误信息。"
                : "记录到 " + crashes.length + " 次崩溃，最近一次在 "
                  + new java.text.SimpleDateFormat("MM-dd HH:mm", java.util.Locale.US).format(new java.util.Date(crashes[0].lastModified()))
                  + "。复制日志发给开发者，就能定位到出问题的代码。"));
        LinearLayout fr = new LinearLayout(this);
        fr.setPadding(0, Ui.dp(this, 12), 0, 0);
        fr.addView(Ui.pill(this, th, "复制日志", true, new View.OnClickListener() {
            @Override public void onClick(View v) { copyLog(); }
        }));
        View fg = new View(this);
        fr.addView(fg, new LinearLayout.LayoutParams(Ui.dp(this, 10), 1));
        fr.addView(Ui.pill(this, th, "查看", false, new View.OnClickListener() {
            @Override public void onClick(View v) { showLog(); }
        }));
        if (crashes.length > 0) {
            View fg2 = new View(this);
            fr.addView(fg2, new LinearLayout.LayoutParams(Ui.dp(this, 10), 1));
            fr.addView(Ui.pill(this, th, "清除", false, new View.OnClickListener() {
                @Override public void onClick(View v) { App.clear(); build(); }
            }));
        }
        cf.addView(fr);

        LinearLayout c4 = card(list, "关于");
        c4.addView(sub("墨读 1.5 · 本地小说阅读器\n格式：TXT（自动识别 UTF-8 / GBK / Big5 / UTF-16）、EPUB、MOBI、AZW3、AZW、FB2、PDF，以及网页导入、书源搜索（兼容「阅读」书源格式，含 JavaScript 规则）\n"
                + "分屏：系统分屏和小窗下自动重新排版并保持阅读位置；长按书籍可在另一侧窗口打开。\n不支持带 DRM 加密的电子书。"));

        setContentView(root);
        if (keep > 0) scroll.post(new Runnable() { @Override public void run() { scroll.scrollTo(0, keep); } });
    }

    private interface Pick { void on(int i); }

    private void copyLog() {
        android.content.ClipboardManager cm = (android.content.ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
        if (cm != null) cm.setPrimaryClip(android.content.ClipData.newPlainText("墨读日志", App.report()));
        android.widget.Toast.makeText(this, "日志已复制，可以直接粘贴发送", android.widget.Toast.LENGTH_SHORT).show();
    }

    private void showLog() {
        TextView t = Ui.text(this, App.report(), 11.5f, th.text);
        t.setTextIsSelectable(true);
        t.setTypeface(Typeface.MONOSPACE);
        int p = Ui.dp(this, 18);
        t.setPadding(p, p, p, p);
        ScrollView sv = new ScrollView(this);
        sv.addView(t);
        Ui.show(Ui.dialog(this, th).setTitle("日志").setView(sv).setPositiveButton("复制", new android.content.DialogInterface.OnClickListener() {
            @Override public void onClick(android.content.DialogInterface d, int w) { copyLog(); }
        }).setNegativeButton("关闭", null), th);
    }

    private LinearLayout card(LinearLayout parent, String name) {
        TextView h = Ui.text(this, name, 13, th.accent);
        h.setTypeface(Typeface.DEFAULT_BOLD);
        h.setPadding(Ui.dp(this, 6), Ui.dp(this, 18), 0, Ui.dp(this, 8));
        parent.addView(h);
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        int p = Ui.dp(this, 16);
        c.setPadding(p, Ui.dp(this, 10), p, Ui.dp(this, 14));
        c.setBackground(Ui.round(th.card, th.divider, Ui.dp(this, 16), Ui.dp(this, 1)));
        parent.addView(c, new LinearLayout.LayoutParams(-1, -2));
        return c;
    }

    private TextView label(String s) {
        TextView t = Ui.text(this, s, 14.5f, th.text);
        t.setPadding(0, Ui.dp(this, 12), 0, Ui.dp(this, 8));
        return t;
    }

    private TextView sub(String s) {
        TextView t = Ui.text(this, s, 12.5f, th.sub);
        t.setLineSpacing(0, 1.3f);
        t.setPadding(0, Ui.dp(this, 6), 0, 0);
        return t;
    }

    private View choiceRow(String name, String[] opts, int selected, final Pick pick) {
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.addView(label(name));
        LinearLayout r = new LinearLayout(this);
        for (int i = 0; i < opts.length; i++) {
            final int idx = i;
            TextView c = Ui.chip(this, th, opts[i], i == selected, new View.OnClickListener() {
                @Override public void onClick(View v) { pick.on(idx); }
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
            lp.rightMargin = Ui.dp(this, 8);
            r.addView(c, lp);
        }
        col.addView(hscroll(r));
        return col;
    }

    private View accentDot(int color, String name, boolean selected, View.OnClickListener l) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER_HORIZONTAL);
        box.setPadding(Ui.dp(this, 6), 0, Ui.dp(this, 6), 0);
        ImageView dot = new ImageView(this);
        dot.setBackground(Ui.round(color, selected ? th.text : 0, Ui.dp(this, 20), selected ? Ui.dp(this, 2) : 0));
        if (selected) {
            dot.setImageDrawable(new Icons(Icons.CHECK, 0xFFFFFFFF));
            int p = Ui.dp(this, 9);
            dot.setPadding(p, p, p, p);
        }
        box.addView(dot, new LinearLayout.LayoutParams(Ui.dp(this, 40), Ui.dp(this, 40)));
        TextView t = Ui.text(this, name, 11, selected ? th.text : th.sub);
        t.setPadding(0, Ui.dp(this, 4), 0, 0);
        t.setGravity(Gravity.CENTER);
        box.addView(t, new LinearLayout.LayoutParams(-1, -2));
        box.setOnClickListener(l);
        Ui.pressScale(box);
        return box;
    }

    private LinearLayout swatches(final boolean night) {
        LinearLayout r = new LinearLayout(this);
        final String key = night ? "nightBg" : "dayBg";
        int[] colors = night ? Theme.NIGHT_BG : Theme.DAY_BG;
        String[] names = night ? Theme.NIGHT_NAMES : Theme.DAY_NAMES;
        int sel = sp.getInt(key, 0);
        for (int i = 0; i < colors.length; i++) {
            final int idx = i;
            r.addView(Ui.swatch(this, th, colors[i], names[i], sel == i, night, new View.OnClickListener() {
                @Override public void onClick(View v) { sp.edit().putInt(key, idx).apply(); }
            }));
        }
        final int custom = sp.getInt(key + "Custom", night ? 0xFF101010 : Theme.DAY_BG[0]);
        r.addView(Ui.customSwatch(this, th, sel < 0, custom, night, new View.OnClickListener() {
            @Override public void onClick(View v) {
                ColorPicker.show(SettingsActivity.this, th, custom, night, new ColorPicker.Listener() {
                    @Override public void onPick(int color) { sp.edit().putInt(key + "Custom", color).putInt(key, -1).apply(); }
                });
            }
        }));
        return r;
    }

    private View hscroll(View v) {
        HorizontalScrollView h = new HorizontalScrollView(this);
        h.setHorizontalScrollBarEnabled(false);
        h.addView(v);
        return h;
    }
}

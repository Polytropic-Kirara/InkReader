package com.modu.reader;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.webkit.CookieManager;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.modu.reader.web.Dom;
import com.modu.reader.web.Downloader;
import com.modu.reader.web.Extractor;
import com.modu.reader.web.Fetcher;
import com.modu.reader.web.Source;
import com.modu.reader.web.WebStore;

import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONTokener;

import java.io.File;
import java.io.IOException;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

/** In-app browser: find a novel, then extract the chapter text or download the whole book. */
public class WebActivity extends Activity {
    private Theme th;
    private SharedPreferences sp;
    private final Handler ui = new Handler();
    private WebView web;
    private EditText address;
    private ProgressBar bar;
    private LinearLayout startPage;
    private FrameLayout root;
    private View grabOverlay;
    private TextView grabText;
    private volatile boolean grabStop;
    private boolean grabbing;

    // browser-mode page source state
    private volatile CountDownLatch pageLatch;
    private volatile String pageHtml, pageUrl;
    private Runnable pendingGrab;

    @Override protected void onCreate(Bundle saved) {
        super.onCreate(saved);
        th = Theme.get(this);
        sp = Theme.prefs(this);
        getWindow().getDecorView().setBackgroundColor(th.bg);
        Ui.bars(this, th.surface, th.surface);
        build();
        Intent in = getIntent();
        String url = in.getStringExtra("url");
        String resume = in.getStringExtra("resume");
        if (url != null && url.length() > 0) load(url);
        if (resume != null) resumeBrowserMode(resume);
    }

    // ---- layout ------------------------------------------------------------------------

    private void build() {
        root = new FrameLayout(this);
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setBackgroundColor(th.bg);
        col.setFitsSystemWindows(true);

        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setBackgroundColor(th.surface);
        top.setPadding(Ui.dp(this, 4), Ui.dp(this, 6), Ui.dp(this, 4), Ui.dp(this, 6));
        top.setElevation(Ui.dp(this, 3));
        top.addView(Ui.icon(this, Icons.CLOSE, th.text, new View.OnClickListener() {
            @Override public void onClick(View v) { finish(); }
        }));
        address = new EditText(this);
        address.setHint("输入网址，或搜索书名");
        address.setHintTextColor(th.sub);
        address.setTextColor(th.text);
        address.setTextSize(14);
        address.setSingleLine(true);
        address.setSelectAllOnFocus(true);
        address.setImeOptions(EditorInfo.IME_ACTION_GO);
        address.setInputType(android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_VARIATION_URI);
        address.setBackground(Ui.round(th.card, th.divider, Ui.dp(this, 20), Ui.dp(this, 1)));
        address.setPadding(Ui.dp(this, 14), 0, Ui.dp(this, 14), 0);
        address.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override public boolean onEditorAction(TextView v, int id, KeyEvent e) {
                go(address.getText().toString());
                return true;
            }
        });
        top.addView(address, new LinearLayout.LayoutParams(0, Ui.dp(this, 40), 1f));
        top.addView(Ui.icon(this, Icons.REFRESH, th.text, new View.OnClickListener() {
            @Override public void onClick(View v) { if (web.getUrl() != null) web.reload(); }
        }));
        col.addView(top, new LinearLayout.LayoutParams(-1, -2));

        bar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        bar.setMax(100);
        bar.setProgressTintList(android.content.res.ColorStateList.valueOf(th.accent));
        bar.setProgressBackgroundTintList(android.content.res.ColorStateList.valueOf(0));
        col.addView(bar, new LinearLayout.LayoutParams(-1, Ui.dp(this, 3)));

        FrameLayout content = new FrameLayout(this);
        web = new WebView(this);
        setupWeb();
        content.addView(web, new FrameLayout.LayoutParams(-1, -1));
        startPage = buildStartPage();
        content.addView(startPage, new FrameLayout.LayoutParams(-1, -1));
        col.addView(content, new LinearLayout.LayoutParams(-1, 0, 1f));

        LinearLayout bottom = new LinearLayout(this);
        bottom.setGravity(Gravity.CENTER_VERTICAL);
        bottom.setBackgroundColor(th.surface);
        bottom.setElevation(Ui.dp(this, 8));
        bottom.setPadding(Ui.dp(this, 6), Ui.dp(this, 6), Ui.dp(this, 12), Ui.dp(this, 6));
        bottom.addView(Ui.icon(this, Icons.BACK, th.text, new View.OnClickListener() {
            @Override public void onClick(View v) { if (web.canGoBack()) web.goBack(); }
        }));
        bottom.addView(Ui.icon(this, Icons.NEXT, th.text, new View.OnClickListener() {
            @Override public void onClick(View v) { if (web.canGoForward()) web.goForward(); }
        }));
        bottom.addView(new View(this), new LinearLayout.LayoutParams(0, 1, 1f));
        bottom.addView(Ui.pill(this, th, "提取正文 / 抓取整本", true, new View.OnClickListener() {
            @Override public void onClick(View v) { extract(); }
        }));
        col.addView(bottom, new LinearLayout.LayoutParams(-1, -2));
        root.addView(col, new FrameLayout.LayoutParams(-1, -1));
        setContentView(root);
    }

    private LinearLayout buildStartPage() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setBackgroundColor(th.bg);
        int p = Ui.dp(this, 22);
        box.setPadding(p, p, p, p);
        box.setClickable(true);
        TextView h = Ui.text(this, "网页导入", 20, th.text);
        h.setTypeface(Typeface.DEFAULT_BOLD);
        box.addView(h);
        TextView d = Ui.text(this, "1. 在上方输入网址，或者直接输入书名搜索\n2. 打开小说的目录页，或者任意一章\n3. 点右下角「提取正文 / 抓取整本」\n\n墨读会去掉广告、自动分章，跨页的章节会自动合并，下载完放进书架，离线也能看。", 14, th.sub);
        d.setLineSpacing(0, 1.45f);
        d.setPadding(0, Ui.dp(this, 10), 0, Ui.dp(this, 20));
        box.addView(d);
        List<String[]> hist = history();
        if (!hist.isEmpty()) {
            TextView r = Ui.text(this, "最近访问", 13, th.accent);
            r.setTypeface(Typeface.DEFAULT_BOLD);
            r.setPadding(0, 0, 0, Ui.dp(this, 8));
            box.addView(r);
            ScrollView sv = new ScrollView(this);
            LinearLayout list = new LinearLayout(this);
            list.setOrientation(LinearLayout.VERTICAL);
            for (final String[] e : hist) {
                LinearLayout row = new LinearLayout(this);
                row.setOrientation(LinearLayout.VERTICAL);
                row.setPadding(Ui.dp(this, 14), Ui.dp(this, 10), Ui.dp(this, 14), Ui.dp(this, 10));
                row.setBackground(Ui.ripple(th.accent, Ui.round(th.card, th.divider, Ui.dp(this, 12), Ui.dp(this, 1)), true));
                TextView t1 = Ui.text(this, e[0].length() > 0 ? e[0] : e[1], 14.5f, th.text);
                t1.setSingleLine(true);
                t1.setEllipsize(TextUtils.TruncateAt.END);
                row.addView(t1);
                TextView t2 = Ui.text(this, e[1], 11.5f, th.sub);
                t2.setSingleLine(true);
                t2.setEllipsize(TextUtils.TruncateAt.MIDDLE);
                row.addView(t2);
                row.setOnClickListener(new View.OnClickListener() {
                    @Override public void onClick(View v) { load(e[1]); }
                });
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
                lp.bottomMargin = Ui.dp(this, 8);
                list.addView(row, lp);
            }
            sv.addView(list);
            box.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1f));
        }
        return box;
    }

    @SuppressWarnings("SetJavaScriptEnabled")
    private void setupWeb() {
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setSupportMultipleWindows(false);
        s.setJavaScriptCanOpenWindowsAutomatically(false);
        s.setMediaPlaybackRequiresUserGesture(true);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        sp.edit().putString("ua", s.getUserAgentString()).apply();
        try { CookieManager.getInstance().setAcceptThirdPartyCookies(web, true); } catch (Throwable ignored) {}
        web.setBackgroundColor(th.bg);
        web.setWebViewClient(new WebViewClient() {
            @SuppressWarnings("deprecation")
            @Override public boolean shouldOverrideUrlLoading(WebView v, String url) {
                return block(Uri.parse(url));
            }
            @Override public void onPageStarted(WebView v, String url, Bitmap fav) {
                if (!address.hasFocus()) address.setText(url);
                bar.setVisibility(View.VISIBLE);
                if (pendingGrab != null) ui.removeCallbacks(pendingGrab);
            }
            @Override public void onPageFinished(WebView v, String url) {
                if (!address.hasFocus()) address.setText(url);
                bar.setVisibility(View.INVISIBLE);
                remember(v.getTitle(), url);
                if (pageLatch != null) {
                    if (pendingGrab != null) ui.removeCallbacks(pendingGrab);
                    pendingGrab = new Runnable() { @Override public void run() { grabHtml(); } };
                    ui.postDelayed(pendingGrab, 1200);
                }
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override public void onProgressChanged(WebView v, int p) { bar.setProgress(p); }
        });
    }

    /** Only http(s) pages open; links that try to launch other apps (a common ad trick) are ignored. */
    private boolean block(Uri u) {
        String s = u == null ? null : u.getScheme();
        return s == null || !(s.equals("http") || s.equals("https"));
    }

    private void go(String text) {
        text = text.trim();
        if (text.length() == 0) return;
        InputMethodManager im = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
        if (im != null) im.hideSoftInputFromWindow(address.getWindowToken(), 0);
        address.clearFocus();
        boolean looksUrl = text.matches("(?i)^(https?://)?[a-z0-9\\-]+(\\.[a-z0-9\\-]+)+(:\\d+)?(/\\S*)?$");
        if (looksUrl) load(text.matches("(?i)^https?://.*") ? text : "https://" + text);
        else {
            try {
                load("https://cn.bing.com/search?q=" + URLEncoder.encode(text + " 小说 目录", "UTF-8"));
            } catch (Exception ignored) {}
        }
    }

    private void load(String url) {
        startPage.setVisibility(View.GONE);
        address.setText(url);
        web.loadUrl(url);
    }

    private List<String[]> history() {
        List<String[]> out = new ArrayList<String[]>();
        try {
            JSONArray a = new JSONArray(sp.getString("webHistory", "[]"));
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.getJSONObject(i);
                out.add(new String[]{o.optString("t"), o.optString("u")});
            }
        } catch (Exception ignored) {}
        return out;
    }

    private void remember(String title, String url) {
        if (url == null || !url.startsWith("http") || url.contains("bing.com/search")) return;
        try {
            List<String[]> h = history();
            JSONArray a = new JSONArray();
            JSONObject first = new JSONObject();
            first.put("t", title == null ? "" : title);
            first.put("u", url);
            a.put(first);
            String host = Uri.parse(url).getHost();
            for (String[] e : h) {
                if (a.length() >= 12) break;
                if (e[1].equals(url) || (host != null && host.equals(Uri.parse(e[1]).getHost()))) continue;
                JSONObject o = new JSONObject();
                o.put("t", e[0]);
                o.put("u", e[1]);
                a.put(o);
            }
            sp.edit().putString("webHistory", a.toString()).apply();
        } catch (Exception ignored) {}
    }

    @Override public void onBackPressed() {
        if (grabbing) { confirmStopGrab(); return; }
        if (web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }

    @Override public void finish() {
        super.finish();
        overridePendingTransition(R.anim.slide_in_left_parallax, R.anim.slide_out_right);
    }

    @Override protected void onDestroy() {
        grabStop = true;
        if (pageLatch != null) pageLatch.countDown();
        try { CookieManager.getInstance().flush(); } catch (Throwable ignored) {}
        web.destroy();
        super.onDestroy();
    }

    // ---- extraction --------------------------------------------------------------------

    private interface Html { void got(String url, String html); }

    private void currentHtml(final Html cb) {
        web.evaluateJavascript("(function(){return document.documentElement.outerHTML;})()", new android.webkit.ValueCallback<String>() {
            @Override public void onReceiveValue(String v) {
                String html = null;
                try {
                    Object o = new JSONTokener(v).nextValue();
                    if (o instanceof String) html = (String) o;
                } catch (Exception ignored) {}
                cb.got(web.getUrl(), html == null ? "" : html);
            }
        });
    }

    private void extract() {
        final String url = web.getUrl();
        if (url == null || !url.startsWith("http")) {
            Toast.makeText(this, "先打开小说的目录页或某一章", Toast.LENGTH_SHORT).show();
            return;
        }
        final AlertDialog pd = Ui.progress(this, th, "正在识别…");
        final Context app = getApplicationContext();
        currentHtml(new Html() {
            @Override public void got(final String pageUrl, final String html) {
                new Thread() {
                    @Override public void run() {
                        final List<String> rules = DownloadCenter.rules(app);
                        final Extractor.Chapter c = Extractor.chapter(Dom.parse(html), pageUrl, rules);
                        final Extractor.Toc t = Extractor.toc(Dom.parse(html), pageUrl);
                        // can a plain download read this page too? (then the book downloads in the background)
                        boolean http;
                        try {
                            Fetcher f = DownloadCenter.fetcher(app);
                            f.attempts = 1;
                            f.timeoutMs = 8000;
                            Source.Page p = f.get(pageUrl, null);
                            if (Extractor.looksLikeToc(t, c)) {
                                http = Extractor.toc(Dom.parse(p.html), p.url).links.size() >= t.links.size() * 0.8;
                            } else {
                                Extractor.Chapter hc = Extractor.chapter(Dom.parse(p.html), p.url, rules);
                                http = hc.chars() >= c.chars() * 0.7 && hc.chars() > 0;
                            }
                        } catch (Throwable e) {
                            http = false;
                        }
                        final boolean httpOk = http;
                        ui.post(new Runnable() {
                            @Override public void run() {
                                if (isFinishing()) return;
                                try { pd.dismiss(); } catch (Exception ignored) {}
                                if (Extractor.looksLikeToc(t, c)) showToc(pageUrl, t, httpOk);
                                else if (c.chars() > 0) showChapter(pageUrl, c, httpOk);
                                else Ui.show(Ui.dialog(WebActivity.this, th).setTitle("没有识别到正文")
                                            .setMessage("这个页面看起来既不是章节也不是目录。请打开小说的目录页或某一章再试。")
                                            .setPositiveButton("好", null), th);
                            }
                        });
                    }
                }.start();
            }
        });
    }

    private EditText field(String value, String hint) {
        EditText e = new EditText(this);
        e.setText(value);
        e.setHint(hint);
        e.setSingleLine(true);
        e.setTextSize(15);
        e.setTextColor(th.text);
        e.setHintTextColor(th.sub);
        e.setBackground(Ui.round(th.card, th.divider, Ui.dp(this, 10), Ui.dp(this, 1)));
        e.setPadding(Ui.dp(this, 12), Ui.dp(this, 8), Ui.dp(this, 12), Ui.dp(this, 8));
        return e;
    }

    private LinearLayout sheet() {
        LinearLayout v = new LinearLayout(this);
        v.setOrientation(LinearLayout.VERTICAL);
        int p = Ui.dp(this, 22);
        v.setPadding(p, Ui.dp(this, 6), p, 0);
        return v;
    }

    private TextView note(String s) {
        TextView t = Ui.text(this, s, 13, th.sub);
        t.setLineSpacing(0, 1.35f);
        t.setPadding(0, Ui.dp(this, 10), 0, 0);
        return t;
    }

    private void showChapter(final String url, final Extractor.Chapter c, final boolean httpOk) {
        LinearLayout v = sheet();
        TextView title = Ui.text(this, c.title.length() > 0 ? c.title : "（未识别到标题）", 16, th.text);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        v.addView(title);
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < Math.min(4, c.paras.size()); i++) sb.append("　　").append(c.paras.get(i)).append('\n');
        TextView prev = Ui.text(this, sb.toString().trim(), 13.5f, th.text);
        prev.setLineSpacing(0, 1.4f);
        prev.setMaxLines(7);
        prev.setEllipsize(TextUtils.TruncateAt.END);
        prev.setPadding(Ui.dp(this, 12), Ui.dp(this, 10), Ui.dp(this, 12), Ui.dp(this, 10));
        prev.setBackground(Ui.round(th.readBg, th.divider, Ui.dp(this, 10), Ui.dp(this, 1)));
        LinearLayout.LayoutParams plp = new LinearLayout.LayoutParams(-1, -2);
        plp.topMargin = Ui.dp(this, 10);
        v.addView(prev, plp);
        v.addView(note("本章约 " + c.chars() + " 字，" + c.paras.size() + " 段　·　" + (c.nextUrl != null ? "已找到下一章" : "没有找到下一章链接")
                + (httpOk ? "" : "\n这个网站需要用浏览器加载，整本抓取时请停留在本页面。")));
        final EditText name = field(c.bookName, "书名");
        LinearLayout.LayoutParams nlp = new LinearLayout.LayoutParams(-1, -2);
        nlp.topMargin = Ui.dp(this, 12);
        v.addView(name, nlp);
        AlertDialog.Builder b = Ui.dialog(this, th).setTitle("识别到章节正文").setView(v)
                .setPositiveButton(c.nextUrl != null ? "从本章往后抓取" : "保存这一章", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) {
                        create(name.getText().toString(), c.author, url, null, httpOk, c.nextUrl == null ? c : null);
                    }
                })
                .setNegativeButton("取消", null);
        if (c.tocUrl != null) b.setNeutralButton("打开目录页", new DialogInterface.OnClickListener() {
            @Override public void onClick(DialogInterface d, int w) { load(c.tocUrl); }
        });
        Ui.show(b, th);
    }

    private void showToc(final String url, final Extractor.Toc t, final boolean httpOk) {
        LinearLayout v = sheet();
        v.addView(note("共 " + t.links.size() + " 章" + (t.nextPage != null ? "（目录有多页，会一起读取）" : "") + "\n"
                + t.links.get(0)[0] + "\n…\n" + t.links.get(t.links.size() - 1)[0]
                + (httpOk ? "" : "\n\n这个网站需要用浏览器加载，抓取时请停留在本页面。")));
        final EditText name = field(t.bookName, "书名");
        LinearLayout.LayoutParams nlp = new LinearLayout.LayoutParams(-1, -2);
        nlp.topMargin = Ui.dp(this, 12);
        v.addView(name, nlp);
        Ui.show(Ui.dialog(this, th).setTitle("识别到目录").setView(v)
                .setPositiveButton("全部抓取", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) { startFromToc(name.getText().toString(), url, t, 0, httpOk); }
                })
                .setNeutralButton("从某一章开始", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) { pickStart(name.getText().toString(), url, t, httpOk); }
                })
                .setNegativeButton("取消", null), th);
    }

    private void pickStart(final String name, final String url, final Extractor.Toc t, final boolean httpOk) {
        String[] titles = new String[t.links.size()];
        for (int i = 0; i < titles.length; i++) titles[i] = t.links.get(i)[0];
        Ui.show(Ui.dialog(this, th).setTitle("从哪一章开始抓取").setItems(titles, new DialogInterface.OnClickListener() {
            @Override public void onClick(DialogInterface d, int which) { startFromToc(name, url, t, which, httpOk); }
        }), th);
    }

    private void startFromToc(final String name, final String url, final Extractor.Toc first, final int from, final boolean httpOk) {
        if (first.nextPage == null || !httpOk) {
            List<String[]> list = new ArrayList<String[]>(first.links.subList(from, first.links.size()));
            create(name, first.author, url, list, httpOk, null);
            return;
        }
        final AlertDialog pd = Ui.progress(this, th, "正在读取完整目录…");
        final Context app = getApplicationContext();
        new Thread() {
            @Override public void run() {
                Extractor.Toc all;
                try { all = Downloader.fetchToc(DownloadCenter.fetcher(app), url); } catch (Throwable e) { all = first; }
                final Extractor.Toc t = all.links.size() >= first.links.size() ? all : first;
                ui.post(new Runnable() {
                    @Override public void run() {
                        try { pd.dismiss(); } catch (Exception ignored) {}
                        int start = Math.min(from, t.links.size() - 1);
                        create(name, first.author, url, new ArrayList<String[]>(t.links.subList(Math.max(0, start), t.links.size())), true, null);
                    }
                });
            }
        }.start();
    }

    /** Puts a new web book on the shelf and starts downloading it. */
    private void create(String name, String author, final String url, List<String[]> toc, boolean httpOk, Extractor.Chapter single) {
        name = name.trim().length() == 0 ? "网页小说" : name.trim();
        String id = UUID.randomUUID().toString().replace("-", "");
        File dir = new File(new File(getFilesDir(), "web"), id);
        try {
            WebStore s = WebStore.create(dir, name, author, url, toc);
            if (toc != null) s.set("toc", url);
            if (single != null) {
                s.appendChapter(single.title.length() > 0 ? single.title : name, url, single.paras);
                s.set("next", "");
                s.set("state", "done");
            }
            s.saveMeta();
            Library.Entry e = new Library.Entry();
            e.id = id;
            e.title = name;
            e.author = author == null ? "" : author;
            e.format = "web";
            e.path = dir.getAbsolutePath();
            String host = Uri.parse(url).getHost();
            e.fileName = "网页：" + (host == null ? url : host);
            e.source = url;
            e.added = System.currentTimeMillis();
            e.dlState = single != null ? "done" : "downloading";
            e.dlCount = single != null ? 1 : 0;
            e.browserOnly = !httpOk && single == null;
            Library.put(this, e);
            if (single != null) {
                Toast.makeText(this, "已保存到书架", Toast.LENGTH_SHORT).show();
            } else if (httpOk) {
                DownloadCenter.start(getApplicationContext());
                Toast.makeText(this, "《" + name + "》已加入书架，正在后台下载", Toast.LENGTH_LONG).show();
            } else {
                startBrowserMode(e.id);
            }
        } catch (IOException ex) {
            Toast.makeText(this, "创建失败：" + ex.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    // ---- browser mode (sites that need JavaScript) ------------------------------------

    private void resumeBrowserMode(final String id) {
        web.post(new Runnable() { @Override public void run() { startBrowserMode(id); } });
    }

    private void startBrowserMode(final String id) {
        final Library.Entry e = Library.get(this, id);
        if (e == null || grabbing) return;
        grabbing = true;
        grabStop = false;
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        startPage.setVisibility(View.GONE);
        showGrabOverlay("正在用浏览器模式抓取《" + e.title + "》…");
        final Context app = getApplicationContext();
        DownloadCenter.mark(app, id, "downloading", "", -1);
        new Thread() {
            @Override public void run() {
                WebStore s;
                int r;
                try {
                    s = WebStore.load(new File(e.path));
                    r = Downloader.run(s, new Source() {
                        @Override public Page get(String url, String referer) throws IOException { return browserGet(url); }
                    }, new Downloader.Listener() {
                        @Override public void onChapter(WebStore st, final int count, final String title) {
                            DownloadCenter.mark(app, id, null, null, count);
                            ui.post(new Runnable() { @Override public void run() { if (grabText != null) grabText.setText("已抓取 " + count + " 章\n" + title); } });
                        }
                        @Override public boolean stop() { return grabStop; }
                    }, Math.max(300, DownloadCenter.delay(app) / 2), DownloadCenter.rules(app));
                    if (grabStop && r != Downloader.DONE) r = Downloader.STOPPED;
                    final String state = r == Downloader.DONE ? "done" : r == Downloader.ERROR ? "error" : "paused";
                    DownloadCenter.mark(app, id, state, s.get("error"), s.chapters.size());
                } catch (Throwable t) {
                    DownloadCenter.mark(app, id, grabStop ? "paused" : "error", String.valueOf(t.getMessage()), -1);
                    r = grabStop ? Downloader.STOPPED : Downloader.ERROR;
                }
                final int result = r;
                ui.post(new Runnable() {
                    @Override public void run() {
                        grabbing = false;
                        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                        hideGrabOverlay();
                        if (isFinishing()) return;
                        Toast.makeText(WebActivity.this, result == Downloader.DONE ? "抓取完成，已放进书架"
                                : result == Downloader.STOPPED ? "已暂停，可以在书架长按这本书继续" : "抓取中断了，可以稍后在书架长按继续", Toast.LENGTH_LONG).show();
                    }
                });
            }
        }.start();
    }

    /** Loads a page in the visible browser and returns its rendered HTML (called from a worker thread). */
    private Source.Page browserGet(final String url) throws IOException {
        if (grabStop) throw new IOException("已停止");
        final CountDownLatch latch = new CountDownLatch(1);
        pageHtml = null;
        pageUrl = url;
        pageLatch = latch;
        ui.post(new Runnable() { @Override public void run() { web.loadUrl(url); } });
        try {
            if (!latch.await(40, TimeUnit.SECONDS)) throw new IOException("网页加载超时");
        } catch (InterruptedException e) {
            throw new IOException("已停止");
        } finally {
            pageLatch = null;
        }
        if (grabStop) throw new IOException("已停止");
        return new Source.Page(pageUrl, pageHtml == null ? "" : pageHtml);
    }

    private void grabHtml() {
        final CountDownLatch latch = pageLatch;
        if (latch == null) return;
        currentHtml(new Html() {
            @Override public void got(String url, String html) {
                pageHtml = html;
                if (url != null) pageUrl = url;
                latch.countDown();
            }
        });
    }

    private void showGrabOverlay(String msg) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER);
        box.setBackgroundColor(Theme.alpha(th.bg, 0.92f));
        box.setClickable(true);
        ProgressBar pb = new ProgressBar(this);
        pb.setIndeterminateTintList(android.content.res.ColorStateList.valueOf(th.accent));
        box.addView(pb, new LinearLayout.LayoutParams(Ui.dp(this, 44), Ui.dp(this, 44)));
        TextView t = Ui.text(this, msg, 15, th.text);
        t.setGravity(Gravity.CENTER);
        t.setPadding(Ui.dp(this, 30), Ui.dp(this, 16), Ui.dp(this, 30), 0);
        box.addView(t);
        grabText = Ui.text(this, "请保持在这个页面，屏幕会保持常亮", 13, th.sub);
        grabText.setGravity(Gravity.CENTER);
        grabText.setPadding(Ui.dp(this, 30), Ui.dp(this, 10), Ui.dp(this, 30), Ui.dp(this, 20));
        box.addView(grabText);
        box.addView(Ui.pill(this, th, "暂停抓取", false, new View.OnClickListener() {
            @Override public void onClick(View v) { stopGrab(); }
        }));
        grabOverlay = box;
        root.addView(box, new FrameLayout.LayoutParams(-1, -1));
        box.setAlpha(0f);
        box.animate().alpha(1f).setDuration(200).start();
    }

    private void hideGrabOverlay() {
        if (grabOverlay != null) root.removeView(grabOverlay);
        grabOverlay = null;
        grabText = null;
    }

    private void stopGrab() {
        grabStop = true;
        CountDownLatch l = pageLatch;
        if (l != null) l.countDown();
        if (grabText != null) grabText.setText("正在停止…");
    }

    private void confirmStopGrab() {
        Ui.show(Ui.dialog(this, th).setTitle("暂停抓取？").setMessage("已经抓到的章节会保留，之后可以在书架长按这本书继续。")
                .setPositiveButton("暂停", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) { stopGrab(); }
                }).setNegativeButton("继续抓取", null), th);
    }
}

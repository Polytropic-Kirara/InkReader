package com.modu.reader;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.provider.DocumentsContract;
import android.provider.Settings;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

/** Finds book files on the phone and imports the selected ones. */
public class ScanActivity extends Activity {
    private static final int REQ_PERM = 11, REQ_TREE = 12;
    private static final String[] EXTS = {"txt", "epub", "mobi", "azw3", "azw", "fb2", "pdf"};

    private static final class Found {
        String name, where, ext;
        File file;
        Uri uri;
        long size, modified;
        boolean onShelf, checked;
    }

    private final Handler ui = new Handler();
    private final List<Found> found = new ArrayList<Found>();
    private final List<Found> shown = new ArrayList<Found>();
    private Theme th;
    private TextView status, importBtn, allBtn;
    private LinearLayout intro, resultBar, bottomBar;
    private EditText filter;
    private BaseAdapter adapter;
    private volatile boolean cancelled;
    private boolean scanning, pendingFullScan;
    private List<Library.Entry> shelf;

    @Override protected void onCreate(Bundle saved) {
        super.onCreate(saved);
        th = Theme.get(this);
        shelf = Library.all(this);
        build();
    }

    @Override protected void onResume() {
        super.onResume();
        if (pendingFullScan && hasAllFiles()) {
            pendingFullScan = false;
            scanStorage();
        }
    }

    @Override protected void onDestroy() {
        super.onDestroy();
        cancelled = true;
    }

    @Override public void finish() {
        super.finish();
        overridePendingTransition(R.anim.slide_in_left_parallax, R.anim.slide_out_right);
    }

    // ---- layout ------------------------------------------------------------------------

    private void build() {
        getWindow().getDecorView().setBackgroundColor(th.bg);
        Ui.bars(this, th.bg, th.surface);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(th.bg);
        root.setFitsSystemWindows(true);

        LinearLayout bar = new LinearLayout(this);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(Ui.dp(this, 4), 0, Ui.dp(this, 8), 0);
        bar.addView(Ui.icon(this, Icons.BACK, th.text, new View.OnClickListener() {
            @Override public void onClick(View v) { finish(); }
        }));
        TextView title = Ui.text(this, "扫描本地书籍", 19, th.text);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        bar.addView(title);
        root.addView(bar, new LinearLayout.LayoutParams(-1, Ui.dp(this, 56)));

        intro = new LinearLayout(this);
        intro.setOrientation(LinearLayout.VERTICAL);
        int p = Ui.dp(this, 18);
        intro.setPadding(p, p, p, p);
        intro.setBackground(Ui.round(th.card, th.divider, Ui.dp(this, 16), Ui.dp(this, 1)));
        LinearLayout head = new LinearLayout(this);
        head.setGravity(Gravity.CENTER_VERTICAL);
        ImageView ic = new ImageView(this);
        ic.setImageDrawable(new Icons(Icons.SCAN, th.accent));
        head.addView(ic, new LinearLayout.LayoutParams(Ui.dp(this, 28), Ui.dp(this, 28)));
        TextView ht = Ui.text(this, "  找出手机里的电子书", 16, th.text);
        ht.setTypeface(Typeface.DEFAULT_BOLD);
        head.addView(ht);
        intro.addView(head);
        TextView desc = Ui.text(this, "查找 TXT、EPUB、MOBI、AZW3、FB2、PDF 文件，勾选后一键加入书架。"
                + (Build.VERSION.SDK_INT >= 30 ? "\n扫描全部存储需要授予「所有文件访问权限」，只用于查找书籍。" : ""), 13, th.sub);
        desc.setLineSpacing(0, 1.3f);
        desc.setPadding(0, Ui.dp(this, 8), 0, Ui.dp(this, 14));
        intro.addView(desc);
        LinearLayout btns = new LinearLayout(this);
        btns.addView(Ui.pill(this, th, "扫描全部存储", true, new View.OnClickListener() {
            @Override public void onClick(View v) { startFullScan(); }
        }));
        View g = new View(this);
        btns.addView(g, new LinearLayout.LayoutParams(Ui.dp(this, 10), 1));
        btns.addView(Ui.pill(this, th, "选择文件夹", false, new View.OnClickListener() {
            @Override public void onClick(View v) { pickFolder(); }
        }));
        intro.addView(btns);
        LinearLayout.LayoutParams ilp = new LinearLayout.LayoutParams(-1, -2);
        ilp.setMargins(Ui.dp(this, 14), Ui.dp(this, 4), Ui.dp(this, 14), Ui.dp(this, 8));
        root.addView(intro, ilp);

        status = Ui.text(this, "", 13, th.sub);
        status.setPadding(Ui.dp(this, 20), Ui.dp(this, 4), Ui.dp(this, 20), Ui.dp(this, 6));
        status.setSingleLine(true);
        status.setEllipsize(TextUtils.TruncateAt.MIDDLE);
        root.addView(status);

        resultBar = new LinearLayout(this);
        resultBar.setGravity(Gravity.CENTER_VERTICAL);
        resultBar.setPadding(Ui.dp(this, 14), 0, Ui.dp(this, 14), Ui.dp(this, 6));
        filter = new EditText(this);
        filter.setHint("筛选文件名");
        filter.setHintTextColor(th.sub);
        filter.setTextColor(th.text);
        filter.setTextSize(14);
        filter.setSingleLine(true);
        filter.setBackground(Ui.round(th.card, th.divider, Ui.dp(this, 18), Ui.dp(this, 1)));
        filter.setPadding(Ui.dp(this, 14), 0, Ui.dp(this, 14), 0);
        filter.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) {}
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) {}
            @Override public void afterTextChanged(Editable s) { applyFilter(); }
        });
        resultBar.addView(filter, new LinearLayout.LayoutParams(0, Ui.dp(this, 38), 1f));
        resultBar.setVisibility(View.GONE);
        root.addView(resultBar);

        ListView lv = new ListView(this);
        lv.setDivider(null);
        lv.setSelector(new android.graphics.drawable.ColorDrawable(0));
        lv.setClipToPadding(false);
        lv.setPadding(0, 0, 0, Ui.dp(this, 8));
        adapter = new BaseAdapter() {
            @Override public int getCount() { return shown.size(); }
            @Override public Object getItem(int p) { return shown.get(p); }
            @Override public long getItemId(int p) { return p; }
            @Override public View getView(int p, View v, ViewGroup parent) { return row(shown.get(p), v); }
        };
        lv.setAdapter(adapter);
        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override public void onItemClick(AdapterView<?> a, View v, int pos, long id) {
                Found f = shown.get(pos);
                if (f.onShelf) return;
                f.checked = !f.checked;
                adapter.notifyDataSetChanged();
                updateBottom();
            }
        });
        root.addView(lv, new LinearLayout.LayoutParams(-1, 0, 1f));

        bottomBar = new LinearLayout(this);
        bottomBar.setGravity(Gravity.CENTER_VERTICAL);
        bottomBar.setBackgroundColor(th.surface);
        bottomBar.setElevation(Ui.dp(this, 8));
        bottomBar.setPadding(Ui.dp(this, 14), Ui.dp(this, 10), Ui.dp(this, 14), Ui.dp(this, 10));
        allBtn = Ui.pill(this, th, "全选", false, new View.OnClickListener() {
            @Override public void onClick(View v) { toggleAll(); }
        });
        bottomBar.addView(allBtn);
        bottomBar.addView(new View(this), new LinearLayout.LayoutParams(0, 1, 1f));
        importBtn = Ui.pill(this, th, "导入", true, new View.OnClickListener() {
            @Override public void onClick(View v) { importChecked(); }
        });
        bottomBar.addView(importBtn);
        bottomBar.setVisibility(View.GONE);
        root.addView(bottomBar);
        setContentView(root);
    }

    private View row(Found f, View convert) {
        LinearLayout r;
        if (convert instanceof LinearLayout) r = (LinearLayout) convert;
        else {
            r = new LinearLayout(this);
            r.setGravity(Gravity.CENTER_VERTICAL);
            r.setPadding(Ui.dp(this, 18), Ui.dp(this, 10), Ui.dp(this, 14), Ui.dp(this, 10));
            TextView badge = Ui.text(this, "", 10, 0xFFFFFFFF);
            badge.setGravity(Gravity.CENTER);
            badge.setTypeface(Typeface.DEFAULT_BOLD);
            r.addView(badge, new LinearLayout.LayoutParams(Ui.dp(this, 40), Ui.dp(this, 40)));
            LinearLayout col = new LinearLayout(this);
            col.setOrientation(LinearLayout.VERTICAL);
            col.setPadding(Ui.dp(this, 12), 0, Ui.dp(this, 8), 0);
            TextView name = Ui.text(this, "", 14.5f, th.text);
            name.setMaxLines(2);
            name.setEllipsize(TextUtils.TruncateAt.END);
            col.addView(name);
            TextView sub = Ui.text(this, "", 11.5f, th.sub);
            sub.setSingleLine(true);
            sub.setEllipsize(TextUtils.TruncateAt.MIDDLE);
            col.addView(sub);
            r.addView(col, new LinearLayout.LayoutParams(0, -2, 1f));
            FrameLayout check = new FrameLayout(this);
            r.addView(check, new LinearLayout.LayoutParams(Ui.dp(this, 24), Ui.dp(this, 24)));
        }
        TextView badge = (TextView) r.getChildAt(0);
        LinearLayout col = (LinearLayout) r.getChildAt(1);
        FrameLayout check = (FrameLayout) r.getChildAt(2);
        badge.setText(f.ext.toUpperCase(Locale.US));
        badge.setBackground(Ui.round(badgeColor(f.ext), 0, Ui.dp(this, 10), 0));
        ((TextView) col.getChildAt(0)).setText(f.name);
        ((TextView) col.getChildAt(1)).setText(size(f.size) + "  ·  " + f.where);
        check.removeAllViews();
        if (f.onShelf) {
            TextView t = Ui.text(this, "已在\n书架", 9, th.sub);
            t.setGravity(Gravity.CENTER);
            check.addView(t, new FrameLayout.LayoutParams(-1, -1));
            check.setBackground(null);
            r.setAlpha(0.55f);
        } else {
            r.setAlpha(1f);
            check.setBackground(Ui.round(f.checked ? th.accent : 0, f.checked ? th.accent : th.sub, Ui.dp(this, 12), Ui.dp(this, 1.5f)));
            if (f.checked) {
                ImageView iv = new ImageView(this);
                iv.setImageDrawable(new Icons(Icons.CHECK, 0xFFFFFFFF));
                int p = Ui.dp(this, 4);
                iv.setPadding(p, p, p, p);
                check.addView(iv, new FrameLayout.LayoutParams(-1, -1));
            }
        }
        return r;
    }

    private int badgeColor(String ext) {
        if (ext.equals("txt")) return 0xFF6F8A9E;
        if (ext.equals("epub")) return 0xFF6E9A6A;
        if (ext.equals("pdf")) return 0xFFB5604E;
        if (ext.equals("fb2")) return 0xFF8E77A8;
        return 0xFFC08A3E; // mobi / azw
    }

    private static String size(long b) {
        if (b >= 1048576) return String.format(Locale.US, "%.1f MB", b / 1048576.0);
        return Math.max(1, b / 1024) + " KB";
    }

    // ---- permissions -------------------------------------------------------------------

    private boolean hasAllFiles() {
        if (Build.VERSION.SDK_INT < 30) return true;
        try {
            return (Boolean) Environment.class.getMethod("isExternalStorageManager").invoke(null);
        } catch (Throwable t) {
            return false;
        }
    }

    private void startFullScan() {
        if (scanning) return;
        if (Build.VERSION.SDK_INT >= 30) {
            if (hasAllFiles()) { scanStorage(); return; }
            Ui.show(Ui.dialog(this, th).setTitle("需要文件访问权限")
                    .setMessage("Android 11 及以上，要在整个手机里查找 TXT / EPUB 等文件，需要在接下来的设置页打开「允许访问所有文件」。\n\n墨读只读取文件名来查找书籍，不会上传任何内容。不想授权的话，也可以用「选择文件夹」。")
                    .setPositiveButton("去开启", new DialogInterface.OnClickListener() {
                        @Override public void onClick(DialogInterface d, int w) {
                            pendingFullScan = true;
                            try {
                                startActivity(new Intent("android.settings.MANAGE_APP_ALL_FILES_ACCESS_PERMISSION",
                                        Uri.parse("package:" + getPackageName())));
                            } catch (Exception e) {
                                try {
                                    startActivity(new Intent("android.settings.MANAGE_ALL_FILES_ACCESS_PERMISSION"));
                                } catch (Exception e2) {
                                    pendingFullScan = false;
                                    Toast.makeText(ScanActivity.this, "无法打开权限设置，请使用「选择文件夹」", Toast.LENGTH_LONG).show();
                                }
                            }
                        }
                    })
                    .setNegativeButton("取消", null), th);
        } else if (Build.VERSION.SDK_INT == 29) {
            Ui.show(Ui.dialog(this, th).setTitle("请选择要扫描的文件夹")
                    .setMessage("Android 10 不允许直接扫描整个存储。请在接下来的界面选择存放小说的文件夹（例如「Download」，或者直接选内部存储根目录）。")
                    .setPositiveButton("选择文件夹", new DialogInterface.OnClickListener() {
                        @Override public void onClick(DialogInterface d, int w) { pickFolder(); }
                    }).setNegativeButton("取消", null), th);
        } else if (checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, REQ_PERM);
        } else {
            scanStorage();
        }
    }

    @Override public void onRequestPermissionsResult(int req, String[] perms, int[] res) {
        if (req != REQ_PERM) return;
        if (res.length > 0 && res[0] == PackageManager.PERMISSION_GRANTED) scanStorage();
        else Toast.makeText(this, "没有存储权限，可以改用「选择文件夹」", Toast.LENGTH_LONG).show();
    }

    private void pickFolder() {
        if (scanning) return;
        try {
            startActivityForResult(new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE), REQ_TREE);
        } catch (Exception e) {
            Toast.makeText(this, "没有可用的文件夹选择器", Toast.LENGTH_LONG).show();
        }
    }

    @Override protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_TREE && res == RESULT_OK && data != null && data.getData() != null) scanTree(data.getData());
    }

    // ---- scanning ----------------------------------------------------------------------

    private void beginScan() {
        scanning = true;
        cancelled = false;
        found.clear();
        shown.clear();
        adapter.notifyDataSetChanged();
        status.setText("正在扫描…");
        resultBar.setVisibility(View.GONE);
        bottomBar.setVisibility(View.GONE);
    }

    private long lastPost;

    private void progress(final String where) {
        long now = System.currentTimeMillis();
        if (now - lastPost < 120) return;
        lastPost = now;
        final int n = found.size();
        ui.post(new Runnable() {
            @Override public void run() { if (scanning) status.setText("正在扫描… 已找到 " + n + " 本  ·  " + where); }
        });
    }

    private static String extOf(String name) {
        int dot = name.lastIndexOf('.');
        if (dot < 0) return null;
        String e = name.substring(dot + 1).toLowerCase(Locale.ROOT);
        for (String x : EXTS) if (x.equals(e)) return e;
        return null;
    }

    private boolean wanted(String ext, long size) {
        if (ext == null) return false;
        if (ext.equals("txt")) return size >= 16 * 1024; // skip logs and tiny notes
        return size >= 1024;
    }

    private void scanStorage() {
        beginScan();
        final File root = Environment.getExternalStorageDirectory();
        new Thread() {
            @Override public void run() {
                walk(root, root.getAbsolutePath(), 0);
                finishScan();
            }
        }.start();
    }

    private void walk(File dir, String rootPath, int depth) {
        if (cancelled || depth > 12) return;
        File[] list = dir.listFiles();
        if (list == null) return;
        String rel = dir.getAbsolutePath().substring(Math.min(rootPath.length(), dir.getAbsolutePath().length()));
        progress(rel.length() == 0 ? "/" : rel);
        for (File f : list) {
            if (cancelled) return;
            String name = f.getName();
            if (name.startsWith(".")) continue;
            if (f.isDirectory()) {
                String path = f.getAbsolutePath();
                if (path.endsWith("/Android/data") || path.endsWith("/Android/obb")) continue;
                walk(f, rootPath, depth + 1);
            } else {
                String ext = extOf(name);
                long size = f.length();
                if (!wanted(ext, size)) continue;
                Found x = new Found();
                x.name = name;
                x.ext = ext;
                x.file = f;
                x.size = size;
                x.modified = f.lastModified();
                String parent = f.getParent() == null ? "" : f.getParent();
                x.where = parent.length() > rootPath.length() ? parent.substring(rootPath.length()) : "/";
                synchronized (found) { found.add(x); }
            }
        }
    }

    private void scanTree(final Uri tree) {
        beginScan();
        new Thread() {
            @Override public void run() {
                try {
                    String rootId = DocumentsContract.getTreeDocumentId(tree);
                    walkTree(tree, rootId, "", 0);
                } catch (Throwable t) {
                    ui.post(new Runnable() { @Override public void run() { Toast.makeText(ScanActivity.this, "读取文件夹失败", Toast.LENGTH_LONG).show(); } });
                }
                finishScan();
            }
        }.start();
    }

    private void walkTree(Uri tree, String docId, String where, int depth) {
        if (cancelled || depth > 12) return;
        progress(where.length() == 0 ? "/" : where);
        Uri children = DocumentsContract.buildChildDocumentsUriUsingTree(tree, docId);
        String[] cols = {DocumentsContract.Document.COLUMN_DOCUMENT_ID, DocumentsContract.Document.COLUMN_DISPLAY_NAME,
                DocumentsContract.Document.COLUMN_MIME_TYPE, DocumentsContract.Document.COLUMN_SIZE,
                DocumentsContract.Document.COLUMN_LAST_MODIFIED};
        List<String[]> dirs = new ArrayList<String[]>();
        Cursor c = null;
        try {
            c = getContentResolver().query(children, cols, null, null, null);
            if (c == null) return;
            while (c.moveToNext() && !cancelled) {
                String id = c.getString(0), name = c.getString(1), mime = c.getString(2);
                if (name == null || name.startsWith(".")) continue;
                if (DocumentsContract.Document.MIME_TYPE_DIR.equals(mime)) {
                    dirs.add(new String[]{id, name});
                    continue;
                }
                String ext = extOf(name);
                long size = c.isNull(3) ? 0 : c.getLong(3);
                if (!wanted(ext, size)) continue;
                Found x = new Found();
                x.name = name;
                x.ext = ext;
                x.uri = DocumentsContract.buildDocumentUriUsingTree(tree, id);
                x.size = size;
                x.modified = c.isNull(4) ? 0 : c.getLong(4);
                x.where = where.length() == 0 ? "/" : where;
                synchronized (found) { found.add(x); }
            }
        } catch (Throwable ignored) {
        } finally {
            if (c != null) c.close();
        }
        for (String[] d : dirs) walkTree(tree, d[0], where + "/" + d[1], depth + 1);
    }

    private void finishScan() {
        ui.post(new Runnable() {
            @Override public void run() {
                if (isFinishing()) return;
                scanning = false;
                shelf = Library.all(ScanActivity.this);
                synchronized (found) {
                    for (Found f : found) f.onShelf = Library.onShelf(shelf, f.name, f.size);
                    Collections.sort(found, new Comparator<Found>() {
                        @Override public int compare(Found a, Found b) {
                            if (a.onShelf != b.onShelf) return a.onShelf ? 1 : -1;
                            return a.modified == b.modified ? a.name.compareTo(b.name) : (a.modified > b.modified ? -1 : 1);
                        }
                    });
                }
                int fresh = 0;
                for (Found f : found) if (!f.onShelf) fresh++;
                status.setText(found.isEmpty() ? "没有找到电子书文件" : "找到 " + found.size() + " 本，其中 " + fresh + " 本还不在书架上");
                resultBar.setVisibility(found.isEmpty() ? View.GONE : View.VISIBLE);
                bottomBar.setVisibility(found.isEmpty() ? View.GONE : View.VISIBLE);
                intro.setVisibility(found.isEmpty() ? View.VISIBLE : View.GONE);
                applyFilter();
            }
        });
    }

    private void applyFilter() {
        String q = filter.getText().toString().trim().toLowerCase(Locale.ROOT);
        shown.clear();
        for (Found f : found) if (q.length() == 0 || f.name.toLowerCase(Locale.ROOT).contains(q) || f.where.toLowerCase(Locale.ROOT).contains(q)) shown.add(f);
        adapter.notifyDataSetChanged();
        updateBottom();
    }

    private void toggleAll() {
        boolean any = false;
        for (Found f : shown) if (!f.onShelf && !f.checked) { any = true; break; }
        for (Found f : shown) if (!f.onShelf) f.checked = any;
        adapter.notifyDataSetChanged();
        updateBottom();
    }

    private void updateBottom() {
        int n = 0;
        boolean allOn = true;
        for (Found f : found) if (f.checked) n++;
        for (Found f : shown) if (!f.onShelf && !f.checked) allOn = false;
        importBtn.setText(n == 0 ? "导入" : "导入 " + n + " 本");
        importBtn.setAlpha(n == 0 ? 0.5f : 1f);
        allBtn.setText(allOn && !shown.isEmpty() ? "取消全选" : "全选");
    }

    private void importChecked() {
        final List<Found> todo = new ArrayList<Found>();
        for (Found f : found) if (f.checked) todo.add(f);
        if (todo.isEmpty()) {
            Toast.makeText(this, "先勾选要导入的书", Toast.LENGTH_SHORT).show();
            return;
        }
        final AlertDialog pd = Ui.progress(this, th, "正在导入 " + todo.size() + " 本…");
        final Context app = getApplicationContext();
        new Thread() {
            @Override public void run() {
                int ok = 0;
                final StringBuilder err = new StringBuilder();
                for (Found f : todo) {
                    try {
                        Uri u = f.uri != null ? f.uri : Uri.fromFile(f.file);
                        Library.importUri(app, u, f.name);
                        f.onShelf = true;
                        f.checked = false;
                        ok++;
                    } catch (Throwable t) {
                        err.append(f.name).append("：").append(t.getMessage()).append('\n');
                    }
                }
                final int done = ok;
                ui.post(new Runnable() {
                    @Override public void run() {
                        if (isFinishing() || isDestroyed()) return;
                        try { pd.dismiss(); } catch (Exception ignored) {}
                        adapter.notifyDataSetChanged();
                        updateBottom();
                        if (err.length() > 0) {
                            Ui.show(Ui.dialog(ScanActivity.this, th).setTitle("导入了 " + done + " 本，部分失败")
                                    .setMessage(err.toString().trim()).setPositiveButton("确定", null), th);
                        } else {
                            Toast.makeText(ScanActivity.this, "已导入 " + done + " 本", Toast.LENGTH_SHORT).show();
                            finish();
                        }
                    }
                });
            }
        }.start();
    }
}

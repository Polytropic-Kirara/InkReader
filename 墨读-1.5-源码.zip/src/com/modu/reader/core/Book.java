package com.modu.reader.core;

import java.util.ArrayList;
import java.util.List;

/** A reflowable book split into chapters. Empty chapter titles mean "untitled part". */
public abstract class Book {
    public String title = "";
    public String author = "";
    public final List<String> chapterTitles = new ArrayList<String>();

    public abstract List<Block> chapter(int index) throws Exception;

    /** Raw bytes of an image referenced from a chapter, or null. */
    public byte[] image(int chapter, String ref) { return null; }

    public byte[] cover() { return null; }

    public int chapterCount() { return chapterTitles.size(); }

    /** Title to show for a chapter: its own, or the nearest titled chapter before it. */
    public String displayTitle(int index) {
        for (int i = Math.min(index, chapterTitles.size() - 1); i >= 0; i--) {
            String t = chapterTitles.get(i);
            if (t != null && t.length() > 0) return t;
        }
        return title;
    }

    public void close() {}
}

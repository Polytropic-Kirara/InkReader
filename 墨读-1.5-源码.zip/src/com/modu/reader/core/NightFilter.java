package com.modu.reader.core;

import java.util.ArrayList;
import java.util.List;

/**
 * "Smart" night mode for rendered PDF pages: text and page background are turned into light
 * text on a dark page, while pictures (photos, illustrations, comics) keep their real colors and
 * are only dimmed. Pictures are found by looking for blocks with many mid-tone or colorful pixels,
 * grouping neighbouring blocks into rectangles and trimming those to the picture's edges.
 */
public final class NightFilter {
    private NightFilter() {}

    private static final int T = 32; // block size in pixels
    public static final int SMART = 0, INVERT = 1, DIM = 2;

    /** Night rendering for a PDF page in one of three styles. */
    public static void apply(int[] px, int w, int h, int mode) {
        if (mode == SMART) { apply(px, w, h, 0xFF111111, 0xFFB4B0A8, 0.82f); return; }
        for (int i = 0; i < px.length; i++) {
            int c = px[i], r = (c >> 16) & 0xFF, g = (c >> 8) & 0xFF, b = c & 0xFF;
            if (mode == INVERT) { r = 215 - r * 4 / 5; g = 215 - g * 4 / 5; b = 215 - b * 4 / 5; }
            else { r = r * 42 / 100; g = g * 40 / 100; b = b * 36 / 100; }
            px[i] = (c & 0xFF000000) | (r << 16) | (g << 8) | b;
        }
    }

    public static void apply(int[] px, int w, int h, int bg, int fg, float imageDim) {
        int tx = (w + T - 1) / T, ty = (h + T - 1) / T;
        boolean[] pic = new boolean[tx * ty];
        float[] mids = new float[tx * ty];
        for (int by = 0; by < ty; by++) {
            for (int bx = 0; bx < tx; bx++) {
                int n = 0, mid = 0, dark = 0, colorful = 0;
                int y1 = Math.min(h, (by + 1) * T), x1 = Math.min(w, (bx + 1) * T);
                for (int y = by * T; y < y1; y += 2) {
                    int row = y * w;
                    for (int x = bx * T; x < x1; x += 2) {
                        int c = px[row + x];
                        int r = (c >> 16) & 0xFF, g = (c >> 8) & 0xFF, b = c & 0xFF;
                        int lum = (r * 299 + g * 587 + b * 114) / 1000;
                        int mx = Math.max(r, Math.max(g, b)), mn = Math.min(r, Math.min(g, b));
                        n++;
                        if (lum < 50) dark++;
                        else if (lum < 205) mid++;
                        if (mx - mn > 45 && lum > 30 && lum < 240) colorful++;
                    }
                }
                if (n == 0) continue;
                mids[by * tx + bx] = (mid + colorful) / (float) n;
                pic[by * tx + bx] = mid > n * 0.42f || dark > n * 0.80f || colorful > n * 0.22f;
            }
        }

        // group picture blocks (4-neighbour) into rectangles
        List<int[]> rects = new ArrayList<int[]>();
        int[] label = new int[tx * ty];
        int[] stack = new int[tx * ty];
        int next = 0;
        for (int i = 0; i < pic.length; i++) {
            if (!pic[i] || label[i] != 0) continue;
            next++;
            int sp = 0, count = 0;
            float strength = 0;
            stack[sp++] = i;
            label[i] = next;
            int minX = tx, minY = ty, maxX = -1, maxY = -1;
            while (sp > 0) {
                int k = stack[--sp];
                int kx = k % tx, ky = k / tx;
                count++;
                strength += mids[k];
                minX = Math.min(minX, kx); maxX = Math.max(maxX, kx);
                minY = Math.min(minY, ky); maxY = Math.max(maxY, ky);
                int[] nb = {k - 1, k + 1, k - tx, k + tx};
                for (int q = 0; q < 4; q++) {
                    int m = nb[q];
                    if (m < 0 || m >= pic.length) continue;
                    if ((q == 0 && kx == 0) || (q == 1 && kx == tx - 1)) continue;
                    if (pic[m] && label[m] == 0) { label[m] = next; stack[sp++] = m; }
                }
            }
            // a lone block is usually bold text or a rule line, not a picture
            if (count < 2 && strength < 0.7f) continue;
            int[] r = {minX * T, minY * T, Math.min(w, (maxX + 1) * T), Math.min(h, (maxY + 1) * T)};
            trim(px, w, r);
            if (r[2] - r[0] >= 8 && r[3] - r[1] >= 8) rects.add(r);
        }

        // lookup table: page luminance -> night color (white paper -> bg, black ink -> fg)
        int[] lr = new int[256], lg = new int[256], lb = new int[256];
        int bgR = (bg >> 16) & 0xFF, bgG = (bg >> 8) & 0xFF, bgB = bg & 0xFF;
        int fgR = (fg >> 16) & 0xFF, fgG = (fg >> 8) & 0xFF, fgB = fg & 0xFF;
        for (int l = 0; l < 256; l++) {
            float t = 1f - l / 255f;
            lr[l] = (int) (bgR + (fgR - bgR) * t);
            lg[l] = (int) (bgG + (fgG - bgG) * t);
            lb[l] = (int) (bgB + (fgB - bgB) * t);
        }
        int dim = (int) (imageDim * 256);
        for (int y = 0; y < h; y++) {
            int row = y * w;
            for (int x = 0; x < w; x++) {
                int i = row + x, c = px[i];
                int r = (c >> 16) & 0xFF, g = (c >> 8) & 0xFF, b = c & 0xFF;
                if (inside(rects, x, y)) {
                    px[i] = (c & 0xFF000000) | ((r * dim >> 8) << 16) | ((g * dim >> 8) << 8) | (b * dim >> 8);
                } else {
                    int lum = (r * 299 + g * 587 + b * 114) / 1000;
                    // keep the hue of colored text (links, highlights) while flipping its lightness
                    int nr = clamp(lr[lum] + (r - lum) * 3 / 4), ng = clamp(lg[lum] + (g - lum) * 3 / 4), nb = clamp(lb[lum] + (b - lum) * 3 / 4);
                    px[i] = (c & 0xFF000000) | (nr << 16) | (ng << 8) | nb;
                }
            }
        }
    }

    private static int clamp(int v) { return v < 0 ? 0 : (v > 255 ? 255 : v); }

    private static boolean inside(List<int[]> rects, int x, int y) {
        for (int i = 0; i < rects.size(); i++) {
            int[] r = rects.get(i);
            if (x >= r[0] && x < r[2] && y >= r[1] && y < r[3]) return true;
        }
        return false;
    }

    /** Shrinks a block-aligned rectangle to where the picture really starts (at most one block per side). */
    private static void trim(int[] px, int w, int[] r) {
        int lim;
        lim = Math.min(r[1] + T, r[3]);
        while (r[1] < lim && blankRow(px, w, r[1], r[0], r[2])) r[1]++;
        lim = Math.max(r[3] - T, r[1]);
        while (r[3] > lim && blankRow(px, w, r[3] - 1, r[0], r[2])) r[3]--;
        lim = Math.min(r[0] + T, r[2]);
        while (r[0] < lim && blankCol(px, w, r[0], r[1], r[3])) r[0]++;
        lim = Math.max(r[2] - T, r[0]);
        while (r[2] > lim && blankCol(px, w, r[2] - 1, r[1], r[3])) r[2]--;
    }

    private static boolean content(int c) {
        int r = (c >> 16) & 0xFF, g = (c >> 8) & 0xFF, b = c & 0xFF;
        int lum = (r * 299 + g * 587 + b * 114) / 1000;
        return lum < 232 || Math.max(r, Math.max(g, b)) - Math.min(r, Math.min(g, b)) > 30;
    }

    private static boolean blankRow(int[] px, int w, int y, int x0, int x1) {
        int n = 0, hit = 0;
        for (int x = x0; x < x1; x++) { n++; if (content(px[y * w + x])) hit++; }
        return hit < Math.max(1, n * 0.03f);
    }

    private static boolean blankCol(int[] px, int w, int x, int y0, int y1) {
        int n = 0, hit = 0;
        for (int y = y0; y < y1; y++) { n++; if (content(px[y * w + x])) hit++; }
        return hit < Math.max(1, n * 0.03f);
    }
}

package com.modu.reader.core;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;

public final class Util {
    private Util() {}

    public static byte[] readAll(InputStream in) throws IOException {
        try {
            ByteArrayOutputStream out = new ByteArrayOutputStream(64 * 1024);
            byte[] buf = new byte[64 * 1024];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            return out.toByteArray();
        } finally {
            in.close();
        }
    }

    public static byte[] readFile(File f) throws IOException {
        return readAll(new FileInputStream(f));
    }

    public static byte[] readHead(File f, int max) throws IOException {
        FileInputStream in = new FileInputStream(f);
        try {
            byte[] buf = new byte[max];
            int total = 0, n;
            while (total < max && (n = in.read(buf, total, max - total)) > 0) total += n;
            byte[] r = new byte[total];
            System.arraycopy(buf, 0, r, 0, total);
            return r;
        } finally {
            in.close();
        }
    }

    /** Base64 decoder that skips whitespace and unknown characters (java.util.Base64 needs API 26). */
    public static byte[] base64(String s) {
        ByteArrayOutputStream out = new ByteArrayOutputStream(s.length() * 3 / 4);
        int acc = 0, bits = 0;
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            int v;
            if (c >= 'A' && c <= 'Z') v = c - 'A';
            else if (c >= 'a' && c <= 'z') v = c - 'a' + 26;
            else if (c >= '0' && c <= '9') v = c - '0' + 52;
            else if (c == '+' || c == '-') v = 62;
            else if (c == '/' || c == '_') v = 63;
            else if (c == '=') break;
            else continue;
            acc = (acc << 6) | v;
            bits += 6;
            if (bits >= 8) {
                bits -= 8;
                out.write((acc >> bits) & 0xFF);
            }
        }
        return out.toByteArray();
    }

    /** Strict UTF-8 check (a sequence cut off at the very end is allowed). */
    public static boolean isUtf8(byte[] d, int n) {
        int i = 0;
        while (i < n) {
            int b = d[i] & 0xFF;
            if (b < 0x80) { i++; continue; }
            int need;
            if (b >= 0xC2 && b <= 0xDF) need = 1;
            else if (b >= 0xE0 && b <= 0xEF) need = 2;
            else if (b >= 0xF0 && b <= 0xF4) need = 3;
            else return false;
            if (i + need >= n) return true;
            for (int k = 1; k <= need; k++) if ((d[i + k] & 0xC0) != 0x80) return false;
            i += need + 1;
        }
        return true;
    }

    public static String stripExt(String name) {
        if (name == null) return "";
        int slash = Math.max(name.lastIndexOf('/'), name.lastIndexOf('\\'));
        if (slash >= 0) name = name.substring(slash + 1);
        int dot = name.lastIndexOf('.');
        return dot > 0 ? name.substring(0, dot) : name;
    }

    public static boolean isBlank(char c) {
        return c == ' ' || c == '\t' || c == '\n' || c == '\r' || c == '\f' || c == '　'
                || c == ' ' || c == '﻿' || c == '​';
    }

    public static String trim(String s) {
        int a = 0, b = s.length();
        while (a < b && isBlank(s.charAt(a))) a++;
        while (b > a && isBlank(s.charAt(b - 1))) b--;
        return s.substring(a, b);
    }
}

package com.modu.reader.core;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.RandomAccessFile;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

/** MOBI / AZW / AZW3 (KF8) / PalmDOC, without DRM. Supports PalmDOC and HUFF/CDIC compression. */
public class MobiBook extends Book {
    private final RandomAccessFile raf;
    private final long[] offsets;
    private int base;             // first record of the section we read
    private int firstImage = -1;  // absolute record index of the first image
    private int coverRecord = -1;
    private final List<List<Block>> chapters = new ArrayList<List<Block>>();

    private static class Header {
        int compression, textRecords, encryption, mobiLen, encoding = 1252, version, firstImage = -1,
                huffOffset, huffCount, extraFlags, fdst = -1;
        String fullName = "";
        Map<Integer, List<byte[]>> exth = new HashMap<Integer, List<byte[]>>();

        String exthString(int type, String cs) {
            List<byte[]> l = exth.get(type);
            return l == null ? null : new String(l.get(0), Charset.forName(cs));
        }

        int exthInt(int type) {
            List<byte[]> l = exth.get(type);
            if (l == null || l.get(0).length < 4) return -1;
            return (int) u32(l.get(0), 0);
        }
    }

    public MobiBook(File file) throws Exception {
        raf = new RandomAccessFile(file, "r");
        byte[] pdb = new byte[78];
        raf.readFully(pdb);
        int num = u16(pdb, 76);
        byte[] table = new byte[num * 8];
        raf.readFully(table);
        offsets = new long[num + 1];
        for (int i = 0; i < num; i++) offsets[i] = u32(table, i * 8);
        offsets[num] = raf.length();

        Header h = parse(record(0));
        String cs = h.encoding == 65001 ? "UTF-8" : "windows-1252";
        boolean kf8 = h.version >= 8 && h.mobiLen > 0;
        // For combination files (MOBI6 + KF8) we read the simpler MOBI6 part at record 0.
        base = 0;
        if (h.encryption != 0) throw new Exception("该书有 DRM 加密保护，无法打开");
        if (h.compression != 1 && h.compression != 2 && h.compression != 17480)
            throw new Exception("不支持的 MOBI 压缩方式：" + h.compression);

        String t = h.exthString(503, cs);
        title = t != null ? t : h.fullName.length() > 0 ? h.fullName : new String(pdb, 0, 32, Charset.forName("ISO-8859-1")).trim();
        title = Util.trim(title.replace('\0', ' '));
        String a = h.exthString(100, cs);
        if (a != null) author = Util.trim(a);
        if (h.firstImage > 0) firstImage = base + h.firstImage;
        int coverOff = h.exthInt(201);
        if (coverOff < 0) coverOff = h.exthInt(202);
        if (firstImage > 0 && coverOff >= 0) coverRecord = firstImage + coverOff;

        byte[] raw = text(h);
        if (kf8 && h.fdst > 0 && h.fdst < offsets.length - 1) {
            byte[] f = record(base + h.fdst);
            if (f.length >= 12 && f[0] == 'F' && f[1] == 'D' && f[2] == 'S' && f[3] == 'T') {
                int secOff = (int) u32(f, 4);
                long start = u32(f, secOff), end = u32(f, secOff + 4);
                if (end > start && end <= raw.length) {
                    byte[] flow = new byte[(int) (end - start)];
                    System.arraycopy(raw, (int) start, flow, 0, flow.length);
                    raw = flow;
                }
            }
        }
        String html = new String(raw, Charset.forName(cs));
        raw = null;
        buildChapters(html, kf8);
    }

    private void buildChapters(String html, boolean kf8) {
        String[] parts = kf8
                ? Pattern.compile("(?i)(?=<html[\\s>])").split(html)
                : Pattern.compile("(?i)<mbp:pagebreak[^>]*>").split(html);
        for (String p : parts) {
            List<Block> b = HtmlText.toBlocks(p);
            if (!b.isEmpty()) chapters.add(b);
        }
        if (chapters.size() <= 1) {
            List<Block> all = new ArrayList<Block>();
            for (List<Block> c : chapters) all.addAll(c);
            chapters.clear();
            chapters.addAll(HtmlText.splitByHeadings(all));
        }
        List<List<Block>> fixed = new ArrayList<List<Block>>();
        for (List<Block> c : chapters) fixed.addAll(HtmlText.splitLong(c, 40000));
        chapters.clear();
        chapters.addAll(fixed);
        if (chapters.isEmpty()) chapters.add(new ArrayList<Block>());
        for (int i = 0; i < chapters.size(); i++) chapterTitles.add(HtmlText.titleOf(chapters.get(i)));
    }

    private byte[] text(Header h) throws Exception {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        Huff huff = null;
        if (h.compression == 17480) {
            List<byte[]> recs = new ArrayList<byte[]>();
            for (int i = 0; i < h.huffCount; i++) recs.add(record(base + h.huffOffset + i));
            huff = new Huff(recs);
        }
        for (int i = 1; i <= h.textRecords && base + i < offsets.length - 1; i++) {
            byte[] r = record(base + i);
            int size = r.length - trailing(r, h.extraFlags);
            if (size < 0) size = 0;
            if (h.compression == 2) palmdoc(r, size, out);
            else if (h.compression == 17480) huff.unpack(r, size, out);
            else out.write(r, 0, size);
        }
        return out.toByteArray();
    }

    private Header parse(byte[] r) {
        Header h = new Header();
        h.compression = u16(r, 0);
        h.textRecords = u16(r, 8);
        h.encryption = u16(r, 12);
        if (r.length >= 24 && r[16] == 'M' && r[17] == 'O' && r[18] == 'B' && r[19] == 'I') {
            h.mobiLen = (int) u32(r, 20);
            h.encoding = (int) u32(r, 28);
            h.version = (int) u32(r, 36);
            if (r.length >= 0x58 + 4) {
                int nameOff = (int) u32(r, 0x54), nameLen = (int) u32(r, 0x58);
                if (nameOff > 0 && nameOff + nameLen <= r.length)
                    h.fullName = new String(r, nameOff, nameLen, Charset.forName(h.encoding == 65001 ? "UTF-8" : "windows-1252"));
            }
            if (r.length >= 0x78) {
                h.firstImage = (int) u32(r, 0x6C);
                h.huffOffset = (int) u32(r, 0x70);
                h.huffCount = (int) u32(r, 0x74);
            }
            if (h.mobiLen >= 0xE4 && r.length >= 0xF4) h.extraFlags = u16(r, 0xF2);
            if (h.version >= 8 && r.length >= 0xC4) h.fdst = (int) u32(r, 0xC0);
            int exthFlags = r.length >= 0x84 ? (int) u32(r, 0x80) : 0;
            int ex = 16 + h.mobiLen;
            if ((exthFlags & 0x40) != 0 && ex + 12 <= r.length && r[ex] == 'E' && r[ex + 1] == 'X' && r[ex + 2] == 'T' && r[ex + 3] == 'H') {
                int count = (int) u32(r, ex + 8), p = ex + 12;
                for (int i = 0; i < count && p + 8 <= r.length; i++) {
                    int type = (int) u32(r, p), len = (int) u32(r, p + 4);
                    if (len < 8 || p + len > r.length) break;
                    byte[] d = new byte[len - 8];
                    System.arraycopy(r, p + 8, d, 0, d.length);
                    List<byte[]> l = h.exth.get(type);
                    if (l == null) { l = new ArrayList<byte[]>(); h.exth.put(type, l); }
                    l.add(d);
                    p += len;
                }
            }
        }
        return h;
    }

    private static int trailing(byte[] d, int flags) {
        int num = 0, size = d.length;
        int f = flags >> 1;
        while (f != 0) {
            if ((f & 1) != 0) num += trailingEntry(d, size - num);
            f >>= 1;
        }
        if ((flags & 1) != 0 && size - num - 1 >= 0) num += (d[size - num - 1] & 0x3) + 1;
        return num;
    }

    private static int trailingEntry(byte[] d, int size) {
        int bitpos = 0, result = 0;
        while (size > 0) {
            int v = d[size - 1] & 0xFF;
            result |= (v & 0x7F) << bitpos;
            bitpos += 7;
            size--;
            if ((v & 0x80) != 0 || bitpos >= 28) break;
        }
        return result;
    }

    private static void palmdoc(byte[] in, int len, ByteArrayOutputStream out) {
        byte[] buf = new byte[Math.max(len * 8, 4096)];
        int o = 0, i = 0;
        while (i < len) {
            if (o + 16 >= buf.length) { byte[] nb = new byte[buf.length * 2]; System.arraycopy(buf, 0, nb, 0, o); buf = nb; }
            int c = in[i++] & 0xFF;
            if (c >= 1 && c <= 8) {
                for (int k = 0; k < c && i < len; k++) {
                    if (o >= buf.length) { byte[] nb = new byte[buf.length * 2]; System.arraycopy(buf, 0, nb, 0, o); buf = nb; }
                    buf[o++] = in[i++];
                }
            } else if (c < 0x80) {
                buf[o++] = (byte) c;
            } else if (c >= 0xC0) {
                buf[o++] = ' ';
                buf[o++] = (byte) (c ^ 0x80);
            } else if (i < len) {
                int m = (c << 8) | (in[i++] & 0xFF);
                int dist = (m >> 3) & 0x7FF, n = (m & 7) + 3;
                if (dist == 0 || dist > o) continue;
                for (int k = 0; k < n; k++) {
                    if (o >= buf.length) { byte[] nb = new byte[buf.length * 2]; System.arraycopy(buf, 0, nb, 0, o); buf = nb; }
                    buf[o] = buf[o - dist];
                    o++;
                }
            }
        }
        out.write(buf, 0, o);
    }

    /** HUFF/CDIC decompressor (used by some Kindle-generated files). */
    private static final class Huff {
        final int[] d1Len = new int[256];
        final boolean[] d1Term = new boolean[256];
        final long[] d1Max = new long[256];
        final long[] minCode = new long[33], maxCode = new long[33];
        final List<byte[]> slices = new ArrayList<byte[]>();
        final List<Boolean> done = new ArrayList<Boolean>();

        Huff(List<byte[]> recs) throws Exception {
            byte[] h = recs.get(0);
            if (!(h[0] == 'H' && h[1] == 'U' && h[2] == 'F' && h[3] == 'F')) throw new Exception("HUFF 数据损坏");
            int off1 = (int) u32(h, 8), off2 = (int) u32(h, 12);
            for (int i = 0; i < 256; i++) {
                long v = u32(h, off1 + i * 4);
                int len = (int) (v & 0x1F);
                d1Len[i] = len;
                d1Term[i] = (v & 0x80) != 0;
                d1Max[i] = (((v >>> 8) + 1) << (32 - len)) - 1;
            }
            minCode[0] = 0;
            maxCode[0] = (1L << 32) - 1; // unused
            for (int len = 1; len <= 32; len++) {
                long mn = u32(h, off2 + (len - 1) * 8), mx = u32(h, off2 + (len - 1) * 8 + 4);
                minCode[len] = mn << (32 - len);
                maxCode[len] = ((mx + 1) << (32 - len)) - 1;
            }
            for (int r = 1; r < recs.size(); r++) {
                byte[] c = recs.get(r);
                if (!(c[0] == 'C' && c[1] == 'D' && c[2] == 'I' && c[3] == 'C')) continue;
                long phrases = u32(c, 8);
                int bits = (int) u32(c, 12);
                long n = Math.min(1L << bits, phrases - slices.size());
                for (int i = 0; i < n; i++) {
                    int off = u16(c, 16 + i * 2);
                    int blen = u16(c, 16 + off);
                    byte[] s = new byte[blen & 0x7FFF];
                    System.arraycopy(c, 18 + off, s, 0, s.length);
                    slices.add(s);
                    done.add((blen & 0x8000) != 0);
                }
            }
        }

        void unpack(byte[] data, int len, ByteArrayOutputStream out) {
            byte[] d = new byte[len + 8];
            System.arraycopy(data, 0, d, 0, len);
            long bitsLeft = (long) len * 8;
            int pos = 0, n = 32;
            long x = u64(d, 0);
            while (true) {
                if (n <= 0) {
                    pos += 4;
                    x = pos + 8 <= d.length ? u64(d, pos) : 0;
                    n += 32;
                }
                long code = (x >>> n) & 0xFFFFFFFFL;
                int idx = (int) (code >>> 24);
                int codeLen = d1Len[idx];
                long max = d1Max[idx];
                if (!d1Term[idx]) {
                    while (codeLen < 32 && code < minCode[codeLen]) codeLen++;
                    max = maxCode[codeLen];
                }
                n -= codeLen;
                bitsLeft -= codeLen;
                if (bitsLeft < 0 || codeLen == 0) break;
                int r = (int) ((max - code) >>> (32 - codeLen));
                if (r < 0 || r >= slices.size()) break;
                byte[] s = slices.get(r);
                if (!done.get(r)) {
                    ByteArrayOutputStream sub = new ByteArrayOutputStream();
                    done.set(r, true);
                    unpack(s, s.length, sub);
                    s = sub.toByteArray();
                    slices.set(r, s);
                }
                out.write(s, 0, s.length);
            }
        }
    }

    private byte[] record(int i) throws Exception {
        long a = offsets[i], b = offsets[i + 1];
        if (b < a) b = a;
        byte[] r = new byte[(int) (b - a)];
        synchronized (raf) {
            raf.seek(a);
            raf.readFully(r);
        }
        return r;
    }

    static int u16(byte[] b, int o) {
        if (o + 2 > b.length) return 0;
        return ((b[o] & 0xFF) << 8) | (b[o + 1] & 0xFF);
    }

    static long u32(byte[] b, int o) {
        if (o + 4 > b.length || o < 0) return 0;
        return ((long) (b[o] & 0xFF) << 24) | ((b[o + 1] & 0xFF) << 16) | ((b[o + 2] & 0xFF) << 8) | (b[o + 3] & 0xFF);
    }

    static long u64(byte[] b, int o) {
        return (u32(b, o) << 32) | u32(b, o + 4);
    }

    @Override public List<Block> chapter(int index) {
        return chapters.get(index);
    }

    @Override public byte[] image(int chapter, String ref) {
        int idx = -1;
        try {
            if (ref.startsWith("kindle:embed:")) {
                String s = ref.substring(13);
                int q = s.indexOf('?');
                if (q >= 0) s = s.substring(0, q);
                idx = Integer.parseInt(s, 32);
            } else if (ref.matches("\\d+")) {
                idx = Integer.parseInt(ref);
            }
        } catch (Exception ignored) {}
        if (idx <= 0 || firstImage < 0) return null;
        int rec = firstImage + idx - 1;
        if (rec >= offsets.length - 1) return null;
        try { return record(rec); } catch (Exception e) { return null; }
    }

    @Override public byte[] cover() {
        if (coverRecord < 0 || coverRecord >= offsets.length - 1) return null;
        try { return record(coverRecord); } catch (Exception e) { return null; }
    }

    @Override public void close() {
        try { raf.close(); } catch (Exception ignored) {}
    }
}

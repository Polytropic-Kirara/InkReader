package com.modu.reader.core;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Turns (X)HTML into plain reading blocks; also holds shared chapter-detection helpers. */
public final class HtmlText {
    private HtmlText() {}

    /** ASCII-only lower-casing; keeps string length identical so indexes line up. */
    public static String asciiLower(String s) {
        char[] c = s.toCharArray();
        for (int i = 0; i < c.length; i++) if (c[i] >= 'A' && c[i] <= 'Z') c[i] = (char) (c[i] + 32);
        return new String(c);
    }

    /**
     * Removes elements whose content must not be shown. Done with indexOf instead of regex:
     * lazy ".*?" over megabytes of text can overflow the regex backtracking stack on Android.
     */
    public static String stripElements(String html, String[] names) {
        String lower = asciiLower(html);
        StringBuilder out = new StringBuilder(html.length());
        int pos = 0, n = html.length();
        while (pos < n) {
            int best = -1, bestEnd = -1;
            for (String name : names) {
                String open = name.equals("!--") ? "<!--" : "<" + name;
                int from = pos;
                while (true) {
                    int i = lower.indexOf(open, from);
                    if (i < 0) break;
                    int after = i + open.length();
                    char c = after < n ? lower.charAt(after) : '>';
                    if (!name.equals("!--") && !(c == '>' || c == ' ' || c == '\t' || c == '\n' || c == '\r' || c == '/')) { from = after; continue; }
                    if (best < 0 || i < best) {
                        String close = name.equals("!--") ? "-->" : "</" + name;
                        int e = lower.indexOf(close, after);
                        if (e < 0) e = n; else { int gt = lower.indexOf('>', e); e = gt < 0 ? n : gt + 1; }
                        if (!name.equals("!--")) {
                            int gt = lower.indexOf('>', i);
                            if (gt > 0 && gt < n && lower.charAt(gt - 1) == '/') e = gt + 1; // self-closing
                        }
                        best = i;
                        bestEnd = e;
                    }
                    break;
                }
            }
            if (best < 0) { out.append(html, pos, n); break; }
            out.append(html, pos, best).append(' ');
            pos = bestEnd;
        }
        return out.toString();
    }

    private static final String[] HIDDEN = {"!--", "head", "style", "script", "title", "rt", "rp"};

    private static final Set<String> BLOCK = new HashSet<String>();
    static {
        String[] b = {"p", "div", "br", "li", "blockquote", "section", "article", "tr", "hr", "dt", "dd",
                "table", "ul", "ol", "center", "pre", "body", "html", "header", "footer", "aside", "nav",
                "figure", "figcaption", "main", "mbp:pagebreak", "empty-line", "v", "stanza", "poem",
                "epigraph", "text-author", "cite", "subtitle", "address", "dl", "caption"};
        for (String s : b) BLOCK.add(s);
    }

    private static final Map<String, String> ENT = new HashMap<String, String>();
    static {
        String[] e = {"amp", "&", "lt", "<", "gt", ">", "quot", "\"", "apos", "'", "nbsp", " ",
                "mdash", "\u2014", "ndash", "\u2013", "hellip", "\u2026", "ldquo", "\u201C", "rdquo", "\u201D",
                "lsquo", "\u2018", "rsquo", "\u2019", "middot", "\u00B7", "copy", "\u00A9", "reg", "\u00AE",
                "trade", "\u2122", "bull", "\u2022", "laquo", "\u00AB", "raquo", "\u00BB", "times", "\u00D7",
                "divide", "\u00F7", "deg", "\u00B0", "emsp", " ", "ensp", " ", "thinsp", " ", "zwnj", "",
                "zwj", "", "shy", "", "lrm", "", "rlm", "", "iexcl", "\u00A1", "iquest", "\u00BF",
                "sect", "\u00A7", "para", "\u00B6", "plusmn", "\u00B1", "frac12", "\u00BD", "frac14", "\u00BC",
                "eacute", "\u00E9", "egrave", "\u00E8", "agrave", "\u00E0", "aacute", "\u00E1", "ouml", "\u00F6",
                "uuml", "\u00FC", "auml", "\u00E4", "ccedil", "\u00E7", "szlig", "\u00DF", "prime", "\u2032",
                "Prime", "\u2033", "larr", "\u2190", "rarr", "\u2192", "hearts", "\u2665", "star", "\u2606"};
        for (int i = 0; i < e.length; i += 2) ENT.put(e[i], e[i + 1]);
    }

    public static String attr(String tag, String name) {
        Matcher m = Pattern.compile("(?i)(?:^|\\s)" + Pattern.quote(name)
                + "\\s*=\\s*(?:\"([^\"]*)\"|'([^']*)'|([^\\s>]+))").matcher(tag);
        if (!m.find()) return null;
        String v = m.group(1) != null ? m.group(1) : m.group(2) != null ? m.group(2) : m.group(3);
        return decodeEntities(v);
    }

    public static String decodeEntities(String s) {
        if (s.indexOf('&') < 0) return s;
        StringBuilder sb = new StringBuilder(s.length());
        int i = 0, n = s.length();
        while (i < n) {
            char c = s.charAt(i);
            if (c == '&') {
                int semi = s.indexOf(';', i);
                if (semi > i && semi - i <= 12) {
                    String r = entity(s.substring(i + 1, semi));
                    if (r != null) {
                        sb.append(r);
                        i = semi + 1;
                        continue;
                    }
                }
            }
            sb.append(c);
            i++;
        }
        return sb.toString();
    }

    private static String entity(String name) {
        if (name.length() > 1 && name.charAt(0) == '#') {
            try {
                int cp = (name.charAt(1) == 'x' || name.charAt(1) == 'X')
                        ? Integer.parseInt(name.substring(2), 16) : Integer.parseInt(name.substring(1));
                if (cp == 0xA0) return " ";
                return new String(Character.toChars(cp));
            } catch (Exception e) {
                return null;
            }
        }
        return ENT.get(name);
    }

    /** Converts HTML to blocks. Inline formatting is dropped; only text, headings and images remain. */
    public static List<Block> toBlocks(String html) {
        html = stripElements(html, HIDDEN);
        List<Block> out = new ArrayList<Block>();
        StringBuilder cur = new StringBuilder();
        int heading = 0;
        int i = 0, n = html.length();
        while (i < n) {
            char c = html.charAt(i);
            if (c == '<') {
                int end = html.indexOf('>', i);
                if (end < 0) break;
                String tag = html.substring(i + 1, end);
                i = end + 1;
                if (tag.length() == 0 || tag.charAt(0) == '!' || tag.charAt(0) == '?') continue;
                boolean close = tag.charAt(0) == '/';
                String name = tagName(tag);
                if (name.length() == 2 && name.charAt(0) == 'h' && name.charAt(1) >= '1' && name.charAt(1) <= '6') {
                    flush(out, cur, heading > 0);
                    if (close) { if (heading > 0) heading--; } else if (!tag.endsWith("/")) heading++;
                } else if (name.equals("img") || name.equals("image")) {
                    flush(out, cur, heading > 0);
                    String src = attr(tag, "src");
                    if (src == null) src = attr(tag, "xlink:href");
                    if (src == null) src = attr(tag, "l:href");
                    if (src == null) src = attr(tag, "href");
                    if (src == null) src = attr(tag, "recindex");
                    if (src != null && src.length() > 0) out.add(new Block(Block.IMAGE, src));
                } else if (BLOCK.contains(name)) {
                    flush(out, cur, heading > 0);
                } else if (name.equals("td") || name.equals("th")) {
                    appendSpace(cur);
                }
            } else {
                int next = html.indexOf('<', i);
                if (next < 0) next = n;
                appendText(cur, html, i, next);
                i = next;
            }
        }
        flush(out, cur, heading > 0);
        return out;
    }

    private static String tagName(String tag) {
        int a = tag.charAt(0) == '/' ? 1 : 0, b = a;
        while (b < tag.length()) {
            char c = tag.charAt(b);
            if (c == ' ' || c == '\t' || c == '\n' || c == '\r' || c == '/' || c == '>') break;
            b++;
        }
        String name = tag.substring(a, b).toLowerCase();
        // drop XML namespace prefixes such as "xhtml:p" but keep "mbp:pagebreak"
        int colon = name.indexOf(':');
        if (colon > 0 && !name.startsWith("mbp:")) name = name.substring(colon + 1);
        return name;
    }

    private static void appendSpace(StringBuilder cur) {
        if (cur.length() > 0 && cur.charAt(cur.length() - 1) != ' ') cur.append(' ');
    }

    private static void appendText(StringBuilder cur, String s, int from, int to) {
        String t = s.substring(from, to);
        if (t.indexOf('&') >= 0) t = decodeEntities(t);
        for (int k = 0; k < t.length(); k++) {
            char c = t.charAt(k);
            if (c == ' ' || c == '\t' || c == '\n' || c == '\r' || c == '\f' || c == '\u00A0') {
                appendSpace(cur);
            } else if (c != '\u200B' && c != '\uFEFF' && c != '\u00AD') {
                cur.append(c);
            }
        }
    }

    private static void flush(List<Block> out, StringBuilder cur, boolean heading) {
        if (cur.length() == 0) return;
        String t = Util.trim(cur.toString());
        cur.setLength(0);
        if (t.length() == 0) return;
        out.add(new Block(heading && t.length() <= 60 ? Block.HEADING : Block.PARA, t));
    }

    // ---- chapter helpers -------------------------------------------------------------

    public static final Pattern CHAPTER = Pattern.compile(
            "^(第\\s*[0-9０-９零〇一二两三四五六七八九十百千万壹贰叁肆伍陆柒捌玖拾佰仟]+\\s*[章回节卷集部篇幕话折]"
                    + "|(楔子|序章|序言|序|引子|引言|前言|尾声|后记|番外|终章|结局|完本感言|作品相关)([\\s:：　·.]|$)"
                    + "|[Cc][Hh][Aa][Pp][Tt][Ee][Rr]\\s*[0-9IVXLCivxlc]+"
                    + "|卷\\s*[0-9零一二三四五六七八九十百千]+)");

    public static boolean isChapterLine(String t) {
        int len = t.length();
        if (len == 0 || len > 50) return false;
        if (!CHAPTER.matcher(t).find()) return false;
        if (len > 25) {
            char last = t.charAt(len - 1);
            if (last == '。' || last == '，' || last == '！' || last == '？' || last == '”') return false;
        }
        return true;
    }

    /** Leading heading blocks joined, else a short first paragraph, else "". */
    public static String titleOf(List<Block> blocks) {
        StringBuilder sb = new StringBuilder();
        for (Block b : blocks) {
            if (b.type == Block.HEADING) {
                if (sb.length() > 0) sb.append(' ');
                sb.append(b.text);
                if (sb.length() > 40) break;
            } else if (b.type == Block.IMAGE && sb.length() == 0) {
                continue;
            } else {
                break;
            }
        }
        if (sb.length() > 0) return sb.toString();
        for (Block b : blocks) {
            if (b.type == Block.IMAGE) continue;
            if (b.text.length() <= 30 && (isChapterLine(b.text) || b.text.length() <= 16)) return b.text;
            break;
        }
        return "";
    }

    public static boolean hasText(List<Block> blocks) {
        for (Block b : blocks) if (b.type != Block.IMAGE) return true;
        return false;
    }

    /** Splits a single long block list at headings or chapter-like lines. */
    public static List<List<Block>> splitByHeadings(List<Block> blocks) {
        List<List<Block>> parts = new ArrayList<List<Block>>();
        List<Block> cur = new ArrayList<Block>();
        boolean prevHeading = false;
        for (Block b : blocks) {
            boolean starts = (b.type == Block.HEADING)
                    || (b.type == Block.PARA && isChapterLine(b.text) && b.text.length() <= 30);
            if (starts && !prevHeading && hasText(cur)) {
                parts.add(cur);
                cur = new ArrayList<Block>();
            }
            prevHeading = starts;
            cur.add(starts && b.type == Block.PARA ? new Block(Block.HEADING, b.text) : b);
        }
        if (!cur.isEmpty()) parts.add(cur);
        return parts;
    }

    /** Splits block lists that are far too long for one chapter into roughly even parts. */
    public static List<List<Block>> splitLong(List<Block> blocks, int maxChars) {
        List<List<Block>> parts = new ArrayList<List<Block>>();
        List<Block> cur = new ArrayList<Block>();
        int size = 0;
        for (Block b : blocks) {
            if (size >= maxChars && b.type != Block.IMAGE) {
                parts.add(cur);
                cur = new ArrayList<Block>();
                size = 0;
            }
            cur.add(b);
            size += b.type == Block.IMAGE ? 500 : b.text.length();
        }
        if (!cur.isEmpty()) parts.add(cur);
        return parts;
    }
}

package com.modu.reader.core;

import java.io.File;
import java.net.URLDecoder;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

/** EPUB 2/3: OPF spine for reading order, NCX or nav document for chapter titles. */
public class EpubBook extends Book {
    private final ZipFile zip;
    private final Map<String, String> lowerNames = new HashMap<String, String>();
    private final List<String> spine = new ArrayList<String>();
    private final List<String> chapterPath = new ArrayList<String>();
    private final List<List<Block>> cached = new ArrayList<List<Block>>();
    private String coverPath;

    private static final Pattern TAG_ITEM = Pattern.compile("(?is)<(?:\\w+:)?item\\s[^>]*>");
    private static final Pattern TAG_ITEMREF = Pattern.compile("(?is)<(?:\\w+:)?itemref\\s[^>]*>");
    private static final Pattern TAG_META = Pattern.compile("(?is)<(?:\\w+:)?meta\\s[^>]*>");

    public EpubBook(File file) throws Exception {
        zip = new ZipFile(file);
        Enumeration<? extends ZipEntry> en = zip.entries();
        String anyOpf = null;
        while (en.hasMoreElements()) {
            String name = en.nextElement().getName();
            lowerNames.put(name.toLowerCase(), name);
            if (anyOpf == null && name.toLowerCase().endsWith(".opf")) anyOpf = name;
        }
        String opfPath = null;
        String container = readText("META-INF/container.xml");
        if (container != null) {
            Matcher m = Pattern.compile("(?i)full-path\\s*=\\s*[\"']([^\"']+)[\"']").matcher(container);
            if (m.find()) opfPath = m.group(1);
        }
        if (opfPath == null || entry(opfPath) == null) opfPath = anyOpf;
        if (opfPath == null) throw new Exception("EPUB 文件缺少 OPF 清单");
        String opf = readText(opfPath);
        String base = dirOf(opfPath);

        title = firstTag(opf, "dc:title");
        author = firstTag(opf, "dc:creator");

        Map<String, String> idToHref = new HashMap<String, String>();
        Map<String, String> idToType = new HashMap<String, String>();
        String navHref = null, ncxHref = null, coverId = null;
        Matcher m = TAG_ITEM.matcher(opf);
        while (m.find()) {
            String tag = m.group();
            String id = HtmlText.attr(tag, "id"), href = HtmlText.attr(tag, "href");
            if (id == null || href == null) continue;
            String full = resolve(base, href);
            String type = HtmlText.attr(tag, "media-type");
            String props = HtmlText.attr(tag, "properties");
            idToHref.put(id, full);
            idToType.put(id, type == null ? "" : type);
            if (props != null && props.contains("nav")) navHref = full;
            if (props != null && props.contains("cover-image")) coverPath = full;
            if ("application/x-dtbncx+xml".equals(type)) ncxHref = full;
        }
        m = TAG_META.matcher(opf);
        while (m.find()) {
            if ("cover".equals(HtmlText.attr(m.group(), "name"))) coverId = HtmlText.attr(m.group(), "content");
        }
        if (coverPath == null && coverId != null) coverPath = idToHref.get(coverId);
        if (coverPath == null) {
            for (Map.Entry<String, String> e : idToHref.entrySet()) {
                String t = idToType.get(e.getKey());
                if (t.startsWith("image/") && e.getKey().toLowerCase().contains("cover")) { coverPath = e.getValue(); break; }
            }
        }

        Matcher sp = Pattern.compile("(?is)<(?:\\w+:)?spine[^>]*>").matcher(opf);
        if (sp.find()) {
            String tocId = HtmlText.attr(sp.group(), "toc");
            if (tocId != null && idToHref.containsKey(tocId)) ncxHref = idToHref.get(tocId);
        }
        m = TAG_ITEMREF.matcher(opf);
        while (m.find()) {
            String idref = HtmlText.attr(m.group(), "idref");
            String href = idref == null ? null : idToHref.get(idref);
            if (href == null) continue;
            String type = idToType.get(idref);
            if (type.length() > 0 && !type.contains("html") && !type.contains("xml")) continue;
            spine.add(href);
        }
        if (spine.isEmpty()) throw new Exception("EPUB 中没有可阅读的章节");

        Map<String, String> toc = new HashMap<String, String>();
        if (navHref != null) parseNav(navHref, toc);
        if (toc.isEmpty() && ncxHref != null) parseNcx(ncxHref, toc);
        for (String s : spine) {
            String t = toc.get(s);
            ZipEntry ze = entry(s);
            if (ze != null && ze.getSize() > 48 * 1024) {
                // One huge HTML file (common for converted TXT): split it into real chapters.
                String html = readText(s);
                List<Block> all = html == null ? new ArrayList<Block>() : HtmlText.toBlocks(html);
                List<List<Block>> parts = new ArrayList<List<Block>>();
                for (List<Block> p : HtmlText.splitByHeadings(all)) parts.addAll(HtmlText.splitLong(p, 40000));
                if (parts.size() > 1) {
                    for (int i = 0; i < parts.size(); i++) {
                        chapterPath.add(s);
                        cached.add(parts.get(i));
                        String pt = HtmlText.titleOf(parts.get(i));
                        chapterTitles.add(i == 0 && t != null && pt.length() == 0 ? t : pt);
                    }
                    continue;
                }
            }
            if (t == null) {
                String html = readText(s);
                t = html == null ? "" : HtmlText.titleOf(HtmlText.toBlocks(html));
            }
            chapterPath.add(s);
            cached.add(null);
            chapterTitles.add(t);
        }
    }

    private void parseNcx(String path, Map<String, String> toc) {
        String ncx = readText(path);
        if (ncx == null) return;
        String base = dirOf(path);
        Matcher m = Pattern.compile("(?is)<(?:\\w+:)?text[^>]*>(.*?)</(?:\\w+:)?text>|<(?:\\w+:)?content\\s[^>]*>").matcher(ncx);
        String pending = null;
        while (m.find()) {
            if (m.group(1) != null) {
                pending = clean(m.group(1));
            } else if (pending != null) {
                String src = HtmlText.attr(m.group(), "src");
                if (src != null) put(toc, resolve(base, src), pending);
                pending = null;
            }
        }
    }

    private void parseNav(String path, Map<String, String> toc) {
        String nav = readText(path);
        if (nav == null) return;
        String base = dirOf(path);
        Matcher navM = Pattern.compile("(?is)<nav[^>]*toc[^>]*>(.*?)</nav>").matcher(nav);
        String body = navM.find() ? navM.group(1) : nav;
        Matcher m = Pattern.compile("(?is)<a\\s([^>]*)>(.*?)</a>").matcher(body);
        while (m.find()) {
            String href = HtmlText.attr(" " + m.group(1), "href");
            if (href != null) put(toc, resolve(base, href), clean(m.group(2)));
        }
    }

    private static void put(Map<String, String> toc, String full, String title) {
        int hash = full.indexOf('#');
        if (hash >= 0) full = full.substring(0, hash);
        if (title.length() > 0 && !toc.containsKey(full)) toc.put(full, title);
    }

    private static String clean(String s) {
        return Util.trim(HtmlText.decodeEntities(s.replaceAll("<[^>]*>", " ")).replaceAll("\\s+", " "));
    }

    private static String firstTag(String xml, String tag) {
        Matcher m = Pattern.compile("(?is)<" + tag + "[^>]*>(.*?)</" + tag + ">").matcher(xml);
        return m.find() ? clean(m.group(1)) : "";
    }

    static String dirOf(String path) {
        int s = path.lastIndexOf('/');
        return s < 0 ? "" : path.substring(0, s + 1);
    }

    static String resolve(String baseDir, String href) {
        int hash = href.indexOf('#');
        String frag = "";
        if (hash >= 0) { frag = href.substring(hash); href = href.substring(0, hash); }
        try {
            href = URLDecoder.decode(href.replace("+", "%2B"), "UTF-8");
        } catch (Exception ignored) {}
        String p = href.startsWith("/") ? href.substring(1) : baseDir + href;
        String[] parts = p.split("/");
        List<String> stack = new ArrayList<String>();
        for (String part : parts) {
            if (part.length() == 0 || part.equals(".")) continue;
            if (part.equals("..")) { if (!stack.isEmpty()) stack.remove(stack.size() - 1); continue; }
            stack.add(part);
        }
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < stack.size(); i++) { if (i > 0) sb.append('/'); sb.append(stack.get(i)); }
        return sb.toString() + frag;
    }

    private ZipEntry entry(String path) {
        ZipEntry e = zip.getEntry(path);
        if (e == null) {
            String real = lowerNames.get(path.toLowerCase());
            if (real != null) e = zip.getEntry(real);
        }
        return e;
    }

    private byte[] readBytes(String path) {
        try {
            ZipEntry e = entry(path);
            return e == null ? null : Util.readAll(zip.getInputStream(e));
        } catch (Exception ex) {
            return null;
        }
    }

    private String readText(String path) {
        byte[] b = readBytes(path);
        if (b == null) return null;
        String head = new String(b, 0, Math.min(b.length, 200), Charset.forName("ISO-8859-1"));
        String cs = "UTF-8";
        Matcher m = Pattern.compile("encoding\\s*=\\s*[\"']([A-Za-z0-9_\\-]+)[\"']").matcher(head);
        if (m.find()) cs = m.group(1);
        if (b.length >= 2 && (b[0] & 0xFF) == 0xFF && (b[1] & 0xFF) == 0xFE) cs = "UTF-16LE";
        if (b.length >= 2 && (b[0] & 0xFF) == 0xFE && (b[1] & 0xFF) == 0xFF) cs = "UTF-16BE";
        String s;
        try {
            s = new String(b, Charset.forName(cs));
        } catch (Exception e) {
            s = new String(b, Charset.forName("UTF-8"));
        }
        if (s.length() > 0 && s.charAt(0) == '\uFEFF') s = s.substring(1);
        return s;
    }

    @Override public List<Block> chapter(int index) {
        if (cached.get(index) != null) return cached.get(index);
        String html = readText(chapterPath.get(index));
        if (html == null) return new ArrayList<Block>();
        return HtmlText.toBlocks(html);
    }

    @Override public byte[] image(int chapter, String ref) {
        if (ref.startsWith("data:")) {
            int comma = ref.indexOf(',');
            return comma > 0 ? Util.base64(ref.substring(comma + 1)) : null;
        }
        String path = resolve(dirOf(chapterPath.get(chapter)), ref);
        int hash = path.indexOf('#');
        if (hash >= 0) path = path.substring(0, hash);
        return readBytes(path);
    }

    @Override public byte[] cover() {
        return coverPath == null ? null : readBytes(coverPath);
    }

    @Override public void close() {
        try { zip.close(); } catch (Exception ignored) {}
    }
}

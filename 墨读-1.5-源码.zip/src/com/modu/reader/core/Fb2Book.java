package com.modu.reader.core;

import java.io.File;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** FictionBook 2 (.fb2). Sections become chapters; embedded binaries are images. */
public class Fb2Book extends Book {
    private final List<List<Block>> chapters = new ArrayList<List<Block>>();
    private final Map<String, String> binaries = new HashMap<String, String>();
    private String coverId;

    public Fb2Book(File file) throws Exception {
        byte[] b = Util.readFile(file);
        String head = new String(b, 0, Math.min(200, b.length), Charset.forName("ISO-8859-1"));
        Matcher em = Pattern.compile("encoding\\s*=\\s*[\"']([A-Za-z0-9_\\-]+)[\"']").matcher(head);
        String cs = em.find() ? em.group(1) : "UTF-8";
        String xml;
        try { xml = new String(b, Charset.forName(cs)); } catch (Exception e) { xml = new String(b, Charset.forName("UTF-8")); }
        b = null;

        String lower = HtmlText.asciiLower(xml);
        int p = 0;
        while ((p = lower.indexOf("<binary", p)) >= 0) {
            int gt = lower.indexOf('>', p), end = lower.indexOf("</binary>", p);
            if (gt < 0 || end < 0) break;
            String id = HtmlText.attr(" " + xml.substring(p + 7, gt), "id");
            if (id != null) binaries.put(id, xml.substring(gt + 1, end));
            p = end + 9;
        }
        xml = HtmlText.stripElements(xml, new String[]{"binary"});

        int ds = HtmlText.asciiLower(xml).indexOf("<description"), de = HtmlText.asciiLower(xml).indexOf("</description>");
        String desc = ds >= 0 && de > ds ? xml.substring(ds, de) : "";
        Matcher ti = Pattern.compile("(?is)<title-info>(.*?)</title-info>").matcher(desc);
        if (ti.find()) {
            String info = ti.group(1);
            title = tagText(info, "book-title");
            Matcher au = Pattern.compile("(?is)<author>(.*?)</author>").matcher(info);
            if (au.find()) {
                String a = au.group(1);
                author = Util.trim((tagText(a, "last-name") + tagText(a, "first-name") + " " + tagText(a, "nickname")).trim());
            }
            Matcher cp = Pattern.compile("(?is)<coverpage>(.*?)</coverpage>").matcher(info);
            if (cp.find()) {
                Matcher im = Pattern.compile("(?is)<image\\s[^>]*>").matcher(cp.group(1));
                if (im.find()) {
                    String h = HtmlText.attr(im.group(), "l:href");
                    if (h == null) h = HtmlText.attr(im.group(), "xlink:href");
                    if (h != null) coverId = h.startsWith("#") ? h.substring(1) : h;
                }
            }
        }
        xml = HtmlText.stripElements(xml, new String[]{"description"});
        // keep only the main body (skip <body name="notes"> etc.)
        lower = HtmlText.asciiLower(xml);
        StringBuilder main = new StringBuilder();
        p = 0;
        while ((p = lower.indexOf("<body", p)) >= 0) {
            int gt = lower.indexOf('>', p);
            if (gt < 0) break;
            int end = lower.indexOf("</body>", gt);
            if (end < 0) end = xml.length();
            String attrs = xml.substring(p + 5, gt);
            if (main.length() == 0 || !attrs.contains("name")) main.append(xml, gt + 1, end);
            p = end;
        }
        if (main.length() == 0) main.append(xml);
        String html = main.toString()
                .replaceAll("(?i)<title(\\s[^>]*)?>", "<h2>").replaceAll("(?i)</title>", "</h2>")
                .replaceAll("(?i)<subtitle(\\s[^>]*)?>", "<h3>").replaceAll("(?i)</subtitle>", "</h3>")
                .replaceAll("(?i)<section", "<mbp:pagebreak/><section");
        for (String part : html.split("<mbp:pagebreak/>")) {
            List<Block> blocks = HtmlText.toBlocks(part);
            if (!blocks.isEmpty()) chapters.addAll(HtmlText.splitLong(blocks, 40000));
        }
        if (chapters.size() == 1) {
            List<Block> all = chapters.remove(0);
            for (List<Block> part : HtmlText.splitByHeadings(all)) chapters.addAll(HtmlText.splitLong(part, 40000));
        }
        if (chapters.isEmpty()) chapters.add(new ArrayList<Block>());
        for (List<Block> c : chapters) chapterTitles.add(HtmlText.titleOf(c));
    }

    private static String tagText(String xml, String tag) {
        Matcher m = Pattern.compile("(?is)<" + tag + "[^>]*>(.*?)</" + tag + ">").matcher(xml);
        return m.find() ? Util.trim(HtmlText.decodeEntities(m.group(1).replaceAll("<[^>]*>", ""))) : "";
    }

    @Override public List<Block> chapter(int index) { return chapters.get(index); }

    @Override public byte[] image(int chapter, String ref) {
        String id = ref.startsWith("#") ? ref.substring(1) : ref;
        String data = binaries.get(id);
        return data == null ? null : Util.base64(data);
    }

    @Override public byte[] cover() {
        return coverId == null ? null : image(0, coverId);
    }
}

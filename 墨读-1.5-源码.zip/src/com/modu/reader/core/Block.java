package com.modu.reader.core;

/** One block of book content: a paragraph, a heading or an image reference. */
public final class Block {
    public static final int PARA = 0, HEADING = 1, IMAGE = 2;
    public final int type;
    public final String text;

    public Block(int type, String text) {
        this.type = type;
        this.text = text;
    }

    @Override public String toString() {
        return (type == PARA ? "P: " : type == HEADING ? "H: " : "IMG: ") + text;
    }
}

package com.modu.reader.core;

import java.io.File;
import java.nio.charset.Charset;
import java.util.zip.ZipFile;

public final class BookFactory {
    private BookFactory() {}

    public static final String TXT = "txt", EPUB = "epub", MOBI = "mobi", FB2 = "fb2", PDF = "pdf", WEB = "web";

    /** Detects the format from file content; the file name is only a hint. Returns null if unsupported. */
    public static String detect(File f, String nameHint) throws Exception {
        byte[] h = Util.readHead(f, 4096);
        String lower = nameHint == null ? "" : nameHint.toLowerCase();
        if (h.length >= 4 && h[0] == '%' && h[1] == 'P' && h[2] == 'D' && h[3] == 'F') return PDF;
        if (h.length >= 68) {
            String type = new String(h, 60, 8, Charset.forName("ISO-8859-1"));
            if (type.equals("BOOKMOBI") || type.equals("TEXtREAd")) return MOBI;
        }
        if (h.length >= 4 && h[0] == 'P' && h[1] == 'K' && h[2] == 3 && h[3] == 4) {
            ZipFile z = new ZipFile(f);
            try {
                if (z.getEntry("META-INF/container.xml") != null) return EPUB;
                java.util.Enumeration<? extends java.util.zip.ZipEntry> en = z.entries();
                while (en.hasMoreElements()) if (en.nextElement().getName().toLowerCase().endsWith(".opf")) return EPUB;
            } finally {
                z.close();
            }
            return null;
        }
        String text = new String(h, Charset.forName("ISO-8859-1"));
        if (text.contains("<FictionBook")) return FB2;
        if (lower.endsWith(".pdf") || lower.endsWith(".epub") || lower.endsWith(".mobi")
                || lower.endsWith(".azw3") || lower.endsWith(".azw")) return null; // name says binary, content disagrees
        boolean utf16 = h.length >= 2 && (((h[0] & 0xFF) == 0xFF && (h[1] & 0xFF) == 0xFE) || ((h[0] & 0xFF) == 0xFE && (h[1] & 0xFF) == 0xFF));
        if (utf16 || looksUtf16(h)) return TXT;
        int control = 0;
        for (byte b : h) {
            int c = b & 0xFF;
            if (c < 0x20 && c != '\t' && c != '\n' && c != '\r' && c != 0x0C && c != 0x1A) control++;
        }
        if (control > h.length / 100 + 1) return null; // binary file (image, archive, ...)
        return TXT;
    }

    private static boolean looksUtf16(byte[] h) {
        int even = 0, odd = 0;
        for (int i = 0; i < h.length; i++) if (h[i] == 0) { if ((i & 1) == 0) even++; else odd++; }
        return (odd > h.length / 5 && even < h.length / 50) || (even > h.length / 5 && odd < h.length / 50);
    }

    public static Book open(File f, String format, String txtCharset, String fallbackTitle) throws Exception {
        Book b;
        if (WEB.equals(format)) b = new com.modu.reader.web.WebBook(f);
        else if (EPUB.equals(format)) b = new EpubBook(f);
        else if (MOBI.equals(format)) b = new MobiBook(f);
        else if (FB2.equals(format)) b = new Fb2Book(f);
        else b = new TxtBook(f, txtCharset, fallbackTitle);
        if (b.title == null || b.title.length() == 0) b.title = fallbackTitle == null ? "" : fallbackTitle;
        return b;
    }
}

package com.modu.reader.core;

import java.io.File;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;

/** Plain-text novel: encoding auto-detection plus chapter detection by heading lines. */
public class TxtBook extends Book {
    private static final int MAX_CHAPTER = 40000;
    private static final int CHUNK = 10000;

    public final String charset;
    private final String text;
    private final List<int[]> ranges = new ArrayList<int[]>(); // start, end, hasHeadingLine
    private final List<String> rawTitles = new ArrayList<String>();

    public TxtBook(File file, String forcedCharset, String fallbackTitle) throws Exception {
        byte[] data = Util.readFile(file);
        String cs = forcedCharset != null ? forcedCharset : detect(data);
        charset = cs;
        String s = new String(data, Charset.forName(cs));
        data = null;
        if (s.length() > 0 && s.charAt(0) == '﻿') s = s.substring(1);
        if (s.indexOf('\r') >= 0) s = s.replace("\r\n", "\n").replace('\r', '\n');
        text = s;
        title = fallbackTitle == null ? "" : fallbackTitle;
        buildChapters();
    }

    // ---- encoding detection ---------------------------------------------------------

    public static String detect(byte[] d) {
        int n = d.length;
        if (n >= 3 && (d[0] & 0xFF) == 0xEF && (d[1] & 0xFF) == 0xBB && (d[2] & 0xFF) == 0xBF) return "UTF-8";
        if (n >= 2 && (d[0] & 0xFF) == 0xFF && (d[1] & 0xFF) == 0xFE) return "UTF-16LE";
        if (n >= 2 && (d[0] & 0xFF) == 0xFE && (d[1] & 0xFF) == 0xFF) return "UTF-16BE";
        int sample = Math.min(n, 8192), zeroEven = 0, zeroOdd = 0;
        for (int i = 0; i < sample; i++) if (d[i] == 0) { if ((i & 1) == 0) zeroEven++; else zeroOdd++; }
        if (sample > 16) {
            if (zeroOdd > sample / 5 && zeroEven < sample / 50) return "UTF-16LE";
            if (zeroEven > sample / 5 && zeroOdd < sample / 50) return "UTF-16BE";
        }
        if (isUtf8(d)) return "UTF-8";
        int len = Math.min(n, 65536);
        String gb = new String(d, 0, len, Charset.forName("GB18030"));
        String big5;
        try {
            big5 = new String(d, 0, len, Charset.forName("Big5"));
        } catch (Exception e) {
            return "GB18030";
        }
        int sg = score(gb, "的一是了我不人在他有这个们来到说你着就那么时"), sb = score(big5, "的一是了我不人在他有這個們來到說你著就那麼時");
        return sb > sg * 2 && sb > 5 ? "Big5" : "GB18030";
    }

    private static int score(String s, String common) {
        int c = 0;
        for (int i = 0; i < s.length(); i++) if (common.indexOf(s.charAt(i)) >= 0) c++;
        return c;
    }

    private static boolean isUtf8(byte[] d) {
        int i = 0, n = d.length, multi = 0;
        while (i < n) {
            int b = d[i] & 0xFF;
            if (b < 0x80) { i++; continue; }
            int need;
            if (b >= 0xC2 && b <= 0xDF) need = 1;
            else if (b >= 0xE0 && b <= 0xEF) need = 2;
            else if (b >= 0xF0 && b <= 0xF4) need = 3;
            else return false;
            if (i + need >= n) return true; // sequence cut off at end of file
            for (int k = 1; k <= need; k++) if ((d[i + k] & 0xC0) != 0x80) return false;
            i += need + 1;
            multi++;
        }
        return true;
    }

    // ---- chapters ---------------------------------------------------------------------

    private void buildChapters() {
        List<int[]> heads = new ArrayList<int[]>(); // line start offsets of heading lines
        List<String> headTitles = new ArrayList<String>();
        int n = text.length(), pos = 0;
        while (pos < n) {
            int nl = text.indexOf('\n', pos);
            if (nl < 0) nl = n;
            if (nl - pos <= 60) {
                String t = Util.trim(text.substring(pos, nl));
                if (HtmlText.isChapterLine(t)) {
                    heads.add(new int[]{pos});
                    headTitles.add(t);
                }
            }
            pos = nl + 1;
        }
        if (heads.size() >= 2) {
            int first = heads.get(0)[0];
            if (first > 0 && Util.trim(text.substring(0, first)).length() >= 10) addRange(0, first, false, "开篇");
            for (int i = 0; i < heads.size(); i++) {
                int s = heads.get(i)[0];
                int e = i + 1 < heads.size() ? heads.get(i + 1)[0] : n;
                addRange(s, e, true, headTitles.get(i));
            }
        } else {
            int s = 0, part = 1;
            while (s < n) {
                int e = cut(s, CHUNK);
                addRange(s, e, false, "第 " + (part++) + " 节");
                s = e;
            }
        }
        if (ranges.isEmpty()) addRange(0, n, false, title);
    }

    private int cut(int start, int size) {
        int n = text.length();
        if (start + size >= n) return n;
        int nl = text.indexOf('\n', start + size);
        if (nl < 0 || nl - start > size * 2) return Math.min(n, start + size);
        return nl + 1;
    }

    private void addRange(int s, int e, boolean heading, String t) {
        if (e - s <= MAX_CHAPTER) {
            ranges.add(new int[]{s, e, heading ? 1 : 0});
            chapterTitles.add(t);
            return;
        }
        int part = 1, p = s;
        while (p < e) {
            int q = Math.min(e, cut(p, MAX_CHAPTER / 2));
            ranges.add(new int[]{p, q, (heading && part == 1) ? 1 : 0});
            chapterTitles.add(part == 1 ? t : t + "（" + part + "）");
            part++;
            p = q;
        }
    }

    @Override public List<Block> chapter(int index) {
        int[] r = ranges.get(index);
        List<Block> out = new ArrayList<Block>();
        int pos = r[0], end = r[1];
        boolean first = true;
        while (pos < end) {
            int nl = text.indexOf('\n', pos);
            if (nl < 0 || nl > end) nl = end;
            String t = Util.trim(text.substring(pos, nl));
            if (t.length() > 0) {
                out.add(new Block(first && r[2] == 1 ? Block.HEADING : Block.PARA, t));
                first = false;
            }
            pos = nl + 1;
        }
        return out;
    }
}

package com.modu.reader;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Looper;
import android.util.Base64;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import com.modu.reader.web.BookSource;
import com.modu.reader.web.Dom;
import com.modu.reader.web.Js;
import com.modu.reader.web.Json;
import com.modu.reader.web.Rules;
import com.modu.reader.web.Source;
import com.modu.reader.web.SourceEngine;

import java.net.URLEncoder;
import java.security.MessageDigest;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

/**
 * Runs book-source JavaScript in a hidden WebView. Scripts see Legado-style helpers (java.ajax,
 * java.getString, base64, md5, aes, get/put …) backed by the bridge below. One script runs at a time.
 */
final class JsEngine implements Js.Host {
    private static JsEngine instance;

    private final Context app;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final Object lock = new Object();
    private WebView web;
    private volatile boolean loaded;
    private volatile Map<String, Object> current;
    private final SharedPreferences vars;

    static synchronized void install(Context c) {
        if (instance == null) {
            instance = new JsEngine(c.getApplicationContext());
            Js.host = instance;
        }
    }

    private JsEngine(Context app) {
        this.app = app;
        vars = app.getSharedPreferences("jsvars", Context.MODE_PRIVATE);
    }

    private void ensureWeb() throws Exception {
        if (web != null && loaded) return;
        final CountDownLatch latch = new CountDownLatch(1);
        ui.post(new Runnable() {
            @Override public void run() {
                try {
                    if (web == null) {
                        web = new WebView(app);
                        web.getSettings().setJavaScriptEnabled(true);
                        web.getSettings().setBlockNetworkImage(true);
                        web.addJavascriptInterface(new Bridge(), "__java");
                        web.setWebViewClient(new WebViewClient() {
                            @Override public void onPageFinished(WebView v, String url) {
                                loaded = true;
                                latch.countDown();
                            }
                        });
                        web.loadDataWithBaseURL("https://modu.local/", "<html><body></body></html>", "text/html", "utf-8", null);
                    } else {
                        latch.countDown();
                    }
                } catch (Throwable t) {
                    App.warn("创建脚本环境", t);
                    latch.countDown();
                }
            }
        });
        latch.await(20, TimeUnit.SECONDS);
        if (web == null || !loaded) throw new Exception("脚本环境启动失败");
    }

    private void reset() {
        ui.post(new Runnable() {
            @Override public void run() {
                try { if (web != null) web.destroy(); } catch (Throwable ignored) {}
                web = null;
                loaded = false;
            }
        });
    }

    @Override public Object eval(String code, Map<String, Object> vars) throws Exception {
        if (Looper.myLooper() == Looper.getMainLooper()) throw new Exception("不能在主线程运行书源脚本");
        synchronized (lock) {
            ensureWeb();
            current = vars;
            final String script = Js.PRELUDE + ";" + Js.wrap(code, vars);
            final String[] out = new String[1];
            final CountDownLatch latch = new CountDownLatch(1);
            ui.post(new Runnable() {
                @Override public void run() {
                    web.evaluateJavascript(script, new ValueCallback<String>() {
                        @Override public void onReceiveValue(String v) {
                            out[0] = v;
                            latch.countDown();
                        }
                    });
                }
            });
            boolean ok = latch.await(30, TimeUnit.SECONDS);
            current = null;
            if (!ok) {
                reset(); // a script that never finishes blocks the context: start a fresh one
                throw new Exception("书源脚本运行超时");
            }
            Object v = out[0] == null || out[0].equals("null") ? null : Json.parse(out[0]);
            if (!(v instanceof String)) throw new Exception("书源脚本没有返回结果");
            return Js.unwrap((String) v);
        }
    }

    /** Functions scripts reach through {@code java.*}. Called on the WebView's bridge thread. */
    private final class Bridge {
        private Map<String, Object> ctx() {
            Map<String, Object> c = current;
            return c == null ? new java.util.HashMap<String, Object>() : c;
        }

        @JavascriptInterface public String ajax(String url) {
            Js.IN_BRIDGE.set(true);
            try {
                Map<String, Object> c = ctx();
                Object eng = c.get("__engine"), src = c.get("__source");
                String base = String.valueOf(c.containsKey("__baseUrl") ? c.get("__baseUrl") : "");
                if (eng instanceof SourceEngine && src instanceof BookSource) {
                    String key = String.valueOf(c.containsKey("key") ? c.get("key") : "");
                    int page = c.get("page") instanceof Number ? ((Number) c.get("page")).intValue() : 1;
                    Source.Page p = ((SourceEngine) eng).request((BookSource) src, url, key, page, base.length() > 0 ? base : null);
                    return p.html;
                }
                return DownloadCenter.fetcher(app).get(url, null).html;
            } catch (Throwable t) {
                App.warn("java.ajax " + url, t);
                return "";
            } finally {
                Js.IN_BRIDGE.set(false);
            }
        }

        private Object node(String content) {
            if (content != null) return Rules.parseBody(content);
            Object n = ctx().get("__content");
            return n == null ? Dom.parse("") : n;
        }

        @JavascriptInterface public String getString(String rule, String content, boolean isUrl) {
            Js.IN_BRIDGE.set(true);
            try {
                return Rules.string(node(content), rule, String.valueOf(ctx().get("__baseUrl")), isUrl);
            } catch (Throwable t) {
                return "";
            } finally {
                Js.IN_BRIDGE.set(false);
            }
        }

        @JavascriptInterface public String getStringList(String rule, String content, boolean isUrl) {
            Js.IN_BRIDGE.set(true);
            try {
                return Json.write(Rules.strings(node(content), rule, String.valueOf(ctx().get("__baseUrl")), isUrl));
            } catch (Throwable t) {
                return "[]";
            } finally {
                Js.IN_BRIDGE.set(false);
            }
        }

        @JavascriptInterface public void setContent(String content, String baseUrl) {
            Map<String, Object> c = current;
            if (c == null) return;
            c.put("__content", Rules.parseBody(content));
            if (baseUrl != null) c.put("__baseUrl", baseUrl);
        }

        @JavascriptInterface public String get(String k) { return vars.getString(k, ""); }
        @JavascriptInterface public void put(String k, String v) { vars.edit().putString(k, v).apply(); }

        @JavascriptInterface public String base64Decode(String s, String charset) {
            try { return new String(Base64.decode(s, Base64.DEFAULT), charset); } catch (Throwable t) { return ""; }
        }

        @JavascriptInterface public String base64Encode(String s) {
            try { return Base64.encodeToString(s.getBytes("UTF-8"), Base64.NO_WRAP); } catch (Throwable t) { return ""; }
        }

        @JavascriptInterface public String md5(String s) {
            try {
                byte[] d = MessageDigest.getInstance("MD5").digest(s.getBytes("UTF-8"));
                StringBuilder sb = new StringBuilder();
                for (byte b : d) sb.append(String.format("%02x", b & 0xFF));
                return sb.toString();
            } catch (Throwable t) { return ""; }
        }

        @JavascriptInterface public String encode(String s, String charset) {
            try { return URLEncoder.encode(s, charset).replace("+", "%20"); } catch (Throwable t) { return s; }
        }

        @JavascriptInterface public String timeFormat(String t) {
            try {
                long ms = Long.parseLong(t.trim());
                if (ms < 100000000000L) ms *= 1000; // seconds
                return new SimpleDateFormat("yyyy/MM/dd HH:mm", Locale.getDefault()).format(new Date(ms));
            } catch (Throwable e) { return t; }
        }

        @JavascriptInterface public String htmlFormat(String s) {
            StringBuilder sb = new StringBuilder();
            for (String l : Dom.parse(s).text().split("\n")) {
                String t = l.trim();
                if (t.length() > 0) { if (sb.length() > 0) sb.append('\n'); sb.append(t); }
            }
            return sb.toString();
        }

        @JavascriptInterface public void log(String s) { App.log("书源脚本：" + (s.length() > 300 ? s.substring(0, 300) + "…" : s)); }

        @JavascriptInterface public String uuid() { return UUID.randomUUID().toString(); }

        @JavascriptInterface public String aes(String data, String key, String transformation, String iv, boolean decrypt) {
            try {
                Cipher c = Cipher.getInstance(transformation);
                SecretKeySpec k = new SecretKeySpec(key.getBytes("UTF-8"), "AES");
                boolean ecb = transformation.toUpperCase(Locale.ROOT).contains("ECB") || iv == null || iv.length() == 0;
                int mode = decrypt ? Cipher.DECRYPT_MODE : Cipher.ENCRYPT_MODE;
                if (ecb) c.init(mode, k); else c.init(mode, k, new IvParameterSpec(iv.getBytes("UTF-8")));
                if (decrypt) return new String(c.doFinal(Base64.decode(data, Base64.DEFAULT)), "UTF-8");
                return Base64.encodeToString(c.doFinal(data.getBytes("UTF-8")), Base64.NO_WRAP);
            } catch (Throwable t) {
                App.warn("java.aes", t);
                return "";
            }
        }

        @JavascriptInterface public String cookie(String url, String key) {
            try {
                String all = CookieManager.getInstance().getCookie(url);
                if (all == null) return "";
                if (key == null || key.length() == 0) return all;
                for (String part : all.split(";")) {
                    String p = part.trim();
                    if (p.startsWith(key + "=")) return p.substring(key.length() + 1);
                }
                return "";
            } catch (Throwable t) { return ""; }
        }
    }
}

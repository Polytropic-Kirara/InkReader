package com.modu.reader;

import android.app.job.JobParameters;
import android.app.job.JobService;

/** Background job that downloads web novels; it reschedules itself before the system's time limit. */
public class DownloadJob extends JobService {
    private volatile boolean stopped;

    @Override public boolean onStartJob(final JobParameters params) {
        stopped = false;
        final long deadline = System.currentTimeMillis() + 8 * 60 * 1000L;
        new Thread("modu-download") {
            @Override public void run() {
                boolean more;
                try {
                    more = DownloadCenter.runAll(getApplicationContext(), new DownloadCenter.Stop() {
                        @Override public boolean now() { return stopped || System.currentTimeMillis() > deadline; }
                    });
                } catch (Throwable t) {
                    more = true;
                }
                if (!stopped) jobFinished(params, more);
            }
        }.start();
        return true;
    }

    @Override public boolean onStopJob(JobParameters params) {
        stopped = true;
        return DownloadCenter.anyPending(getApplicationContext());
    }
}

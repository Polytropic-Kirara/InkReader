package com.modu.reader;

import android.animation.ObjectAnimator;
import android.animation.PropertyValuesHolder;
import android.animation.StateListAnimator;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.InsetDrawable;
import android.graphics.drawable.RippleDrawable;
import android.os.Build;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;

final class Ui {
    private Ui() {}

    static int dp(Context c, float v) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, c.getResources().getDisplayMetrics());
    }

    static GradientDrawable round(int fill, int stroke, float radiusPx, int strokeW) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setCornerRadius(radiusPx);
        if (strokeW > 0) g.setStroke(strokeW, stroke);
        return g;
    }

    static RippleDrawable ripple(int color, Drawable content, boolean bounded) {
        Drawable mask = bounded ? (content != null ? content : new ColorDrawable(0xFFFFFFFF)) : null;
        return new RippleDrawable(ColorStateList.valueOf(Theme.alpha(color, 0.18f)), content, mask);
    }

    static TextView text(Context c, String s, float sp, int color) {
        TextView t = new TextView(c);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        t.setIncludeFontPadding(true);
        return t;
    }

    /** Rounded button: filled with the accent color, or a soft outline. */
    static TextView pill(Context c, Theme th, String s, boolean filled, View.OnClickListener l) {
        TextView t = text(c, s, 14, filled ? 0xFFFFFFFF : th.text);
        t.setGravity(Gravity.CENTER);
        t.setSingleLine(true);
        int h = dp(c, 14), v = dp(c, 8);
        t.setPadding(h, v, h, v);
        GradientDrawable bgd = filled ? round(th.accent, 0, dp(c, 20), 0)
                : round(Theme.alpha(th.text, 0.06f), Theme.alpha(th.text, 0.12f), dp(c, 20), dp(c, 1));
        t.setBackground(ripple(filled ? 0xFFFFFFFF : th.text, bgd, true));
        t.setClickable(true);
        t.setOnClickListener(l);
        pressScale(t);
        return t;
    }

    /** Selectable chip used for option groups (background presets, animation types, …). */
    static TextView chip(Context c, Theme th, String s, boolean selected, View.OnClickListener l) {
        TextView t = text(c, s, 13, selected ? th.accent : th.text);
        t.setGravity(Gravity.CENTER);
        t.setSingleLine(true);
        int h = dp(c, 12), v = dp(c, 7);
        t.setPadding(h, v, h, v);
        t.setBackground(ripple(th.accent, round(selected ? Theme.alpha(th.accent, 0.14f) : Theme.alpha(th.text, 0.05f),
                selected ? th.accent : Theme.alpha(th.text, 0.10f), dp(c, 16), dp(c, selected ? 1.5f : 1)), true));
        t.setOnClickListener(l);
        pressScale(t);
        return t;
    }

    static ImageView icon(Context c, int type, int color, View.OnClickListener l) {
        ImageView v = new ImageView(c);
        v.setImageDrawable(new Icons(type, color));
        int p = dp(c, 10);
        v.setPadding(p, p, p, p);
        v.setLayoutParams(new LinearLayout.LayoutParams(dp(c, 44), dp(c, 44)));
        if (l != null) {
            v.setBackground(ripple(color, null, false));
            v.setOnClickListener(l);
            v.setClickable(true);
        }
        return v;
    }

    /** Big round icon button with a caption under it (reader menu). */
    static LinearLayout action(Context c, Theme th, int type, String caption, View.OnClickListener l) {
        LinearLayout box = new LinearLayout(c);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER_HORIZONTAL);
        box.setPadding(0, dp(c, 4), 0, dp(c, 4));
        ImageView iv = new ImageView(c);
        iv.setImageDrawable(new Icons(type, th.text));
        int p = dp(c, 11);
        iv.setPadding(p, p, p, p);
        iv.setBackground(round(Theme.alpha(th.text, 0.07f), 0, dp(c, 23), 0));
        box.addView(iv, new LinearLayout.LayoutParams(dp(c, 46), dp(c, 46)));
        TextView t = text(c, caption, 11.5f, th.sub);
        t.setPadding(dp(c, 2), dp(c, 6), dp(c, 2), 0);
        t.setGravity(Gravity.CENTER);
        t.setSingleLine(true);
        t.setEllipsize(android.text.TextUtils.TruncateAt.END);
        t.setIncludeFontPadding(false);
        box.addView(t, new LinearLayout.LayoutParams(-1, -2));
        box.setBackground(ripple(th.text, null, false));
        box.setClickable(true);
        box.setOnClickListener(l);
        pressScale(box);
        return box;
    }

    static void pressScale(View v) {
        StateListAnimator s = new StateListAnimator();
        s.addState(new int[]{android.R.attr.state_pressed}, ObjectAnimator.ofPropertyValuesHolder(v,
                PropertyValuesHolder.ofFloat("scaleX", 0.94f), PropertyValuesHolder.ofFloat("scaleY", 0.94f)).setDuration(110));
        s.addState(new int[0], ObjectAnimator.ofPropertyValuesHolder(v,
                PropertyValuesHolder.ofFloat("scaleX", 1f), PropertyValuesHolder.ofFloat("scaleY", 1f)).setDuration(160));
        v.setStateListAnimator(s);
    }

    static void tint(SeekBar s, Theme th) {
        s.setProgressTintList(ColorStateList.valueOf(th.accent));
        s.setThumbTintList(ColorStateList.valueOf(th.accent));
        s.setProgressBackgroundTintList(ColorStateList.valueOf(Theme.alpha(th.text, 0.25f)));
    }

    static Switch toggle(Context c, Theme th, boolean on, CompoundButton.OnCheckedChangeListener l) {
        Switch s = new Switch(c);
        s.setChecked(on);
        int[][] states = {{android.R.attr.state_checked}, {}};
        s.setThumbTintList(new ColorStateList(states, new int[]{th.accent, th.night ? 0xFF9A9A9A : 0xFFF5F0E6}));
        s.setTrackTintList(new ColorStateList(states, new int[]{Theme.alpha(th.accent, 0.5f), Theme.alpha(th.text, 0.25f)}));
        s.setOnCheckedChangeListener(l);
        return s;
    }

    static View divider(Context c, Theme th) {
        View v = new View(c);
        v.setBackgroundColor(th.divider);
        v.setLayoutParams(new LinearLayout.LayoutParams(-1, Math.max(1, dp(c, 0.7f))));
        return v;
    }

    /** Color swatch with a sample glyph; used for reading backgrounds. */
    static LinearLayout swatch(Context c, Theme th, int color, String label, boolean selected, boolean night, View.OnClickListener l) {
        LinearLayout box = new LinearLayout(c);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER_HORIZONTAL);
        TextView sq = text(c, "文", 15, Theme.textFor(color, night));
        sq.setGravity(Gravity.CENTER);
        sq.setBackground(round(color, selected ? th.accent : Theme.alpha(th.text, 0.15f), dp(c, 12), dp(c, selected ? 2.5f : 1)));
        box.addView(sq, new LinearLayout.LayoutParams(dp(c, 46), dp(c, 46)));
        TextView t = text(c, label, 11, selected ? th.accent : th.sub);
        t.setPadding(0, dp(c, 4), 0, 0);
        t.setGravity(Gravity.CENTER);
        box.addView(t, new LinearLayout.LayoutParams(-1, -2));
        box.setPadding(dp(c, 5), 0, dp(c, 5), 0);
        box.setClickable(true);
        box.setOnClickListener(l);
        pressScale(box);
        return box;
    }

    static LinearLayout customSwatch(Context c, Theme th, boolean selected, int color, boolean night, View.OnClickListener l) {
        LinearLayout box = new LinearLayout(c);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER_HORIZONTAL);
        TextView sq = text(c, selected ? "文" : "+", selected ? 15 : 20, selected ? Theme.textFor(color, night) : 0xFFFFFFFF);
        sq.setGravity(Gravity.CENTER);
        if (selected) {
            sq.setBackground(round(color, th.accent, dp(c, 12), dp(c, 2.5f)));
        } else {
            GradientDrawable g = new GradientDrawable();
            g.setShape(GradientDrawable.RECTANGLE);
            g.setCornerRadius(dp(c, 12));
            g.setGradientType(GradientDrawable.SWEEP_GRADIENT);
            g.setColors(new int[]{0xFFE57373, 0xFFFFD54F, 0xFF81C784, 0xFF4FC3F7, 0xFFBA68C8, 0xFFE57373});
            sq.setBackground(g);
        }
        box.addView(sq, new LinearLayout.LayoutParams(dp(c, 46), dp(c, 46)));
        TextView t = text(c, "自定义", 11, selected ? th.accent : th.sub);
        t.setPadding(0, dp(c, 4), 0, 0);
        t.setGravity(Gravity.CENTER);
        box.addView(t, new LinearLayout.LayoutParams(-1, -2));
        box.setPadding(dp(c, 5), 0, dp(c, 5), 0);
        box.setClickable(true);
        box.setOnClickListener(l);
        pressScale(box);
        return box;
    }

    /** Indeterminate progress dialog in theme colors. */
    static AlertDialog progress(Context c, Theme th, String msg) {
        LinearLayout row = new LinearLayout(c);
        row.setGravity(Gravity.CENTER_VERTICAL);
        int p = dp(c, 24);
        row.setPadding(p, p, p, p);
        android.widget.ProgressBar pb = new android.widget.ProgressBar(c);
        pb.setIndeterminateTintList(ColorStateList.valueOf(th.accent));
        row.addView(pb, new LinearLayout.LayoutParams(dp(c, 36), dp(c, 36)));
        TextView t = text(c, msg, 15, th.text);
        t.setPadding(dp(c, 18), 0, 0, 0);
        row.addView(t);
        AlertDialog d = dialog(c, th).setView(row).setCancelable(false).create();
        d.show();
        style(d, th);
        return d;
    }

    // ---- dialogs -----------------------------------------------------------------------

    static AlertDialog.Builder dialog(Context c, Theme th) {
        return new AlertDialog.Builder(c, th.night ? android.R.style.Theme_Material_Dialog_Alert
                : android.R.style.Theme_Material_Light_Dialog_Alert);
    }

    /** Shows the dialog on the theme's warm/dark surface instead of the default white/grey. */
    static AlertDialog show(AlertDialog.Builder b, Theme th) {
        AlertDialog d = b.create();
        d.show();
        style(d, th);
        return d;
    }

    static void style(AlertDialog d, Theme th) {
        Window w = d.getWindow();
        if (w != null) {
            Context c = d.getContext();
            w.setBackgroundDrawable(new InsetDrawable(round(th.surface, 0, dp(c, 18), 0), dp(c, 16)));
        }
        int[] ids = {AlertDialog.BUTTON_POSITIVE, AlertDialog.BUTTON_NEGATIVE, AlertDialog.BUTTON_NEUTRAL};
        for (int id : ids) {
            Button btn = d.getButton(id);
            if (btn != null) btn.setTextColor(id == AlertDialog.BUTTON_POSITIVE ? th.accent : th.sub);
        }
    }

    // ---- system bars -------------------------------------------------------------------

    /** Colors system bars; in a fullscreen reader they only show in split screen / windowed mode. */
    static void bars(Activity a, int status, int nav) {
        Window w = a.getWindow();
        w.setStatusBarColor(status);
        w.setNavigationBarColor(nav);
        int flags = w.getDecorView().getSystemUiVisibility() & ~(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | 0x10);
        if (Theme.luminance(status) > 0.55f) flags |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
        if (Build.VERSION.SDK_INT >= 26 && Theme.luminance(nav) > 0.55f) flags |= 0x10; // LIGHT_NAVIGATION_BAR
        w.getDecorView().setSystemUiVisibility(flags);
    }

    /** Launch flags that open an activity in its own window, next to this one in split screen. */
    static int adjacentFlags() {
        return 0x00001000 /* FLAG_ACTIVITY_LAUNCH_ADJACENT */
                | Intent.FLAG_ACTIVITY_NEW_TASK
                | Intent.FLAG_ACTIVITY_MULTIPLE_TASK;
    }
}

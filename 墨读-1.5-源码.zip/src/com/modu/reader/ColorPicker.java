package com.modu.reader;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

/** HSV color picker with gradient sliders and a live page preview. */
final class ColorPicker {
    interface Listener { void onPick(int color); }

    private ColorPicker() {}

    static void show(final Context c, final Theme th, int initial, final boolean nightPreview, final Listener l) {
        final float[] hsv = new float[3];
        Color.colorToHSV(initial, hsv);
        LinearLayout root = new LinearLayout(c);
        root.setOrientation(LinearLayout.VERTICAL);
        int pad = Ui.dp(c, 22);
        root.setPadding(pad, Ui.dp(c, 8), pad, 0);

        final TextView preview = Ui.text(c, "　　山风吹过城墙，少年握紧手中的剑。\n　　夜色渐深，灯火一盏盏亮起。", 15, 0);
        preview.setLineSpacing(0, 1.4f);
        int pp = Ui.dp(c, 16);
        preview.setPadding(pp, pp, pp, pp);
        root.addView(preview, new LinearLayout.LayoutParams(-1, -2));

        final Slider hue = new Slider(c), sat = new Slider(c), val = new Slider(c);
        final Runnable update = new Runnable() {
            @Override public void run() {
                hsv[0] = hue.value * 360f;
                hsv[1] = sat.value;
                hsv[2] = val.value;
                int col = Color.HSVToColor(hsv);
                preview.setBackground(Ui.round(col, th.divider, Ui.dp(c, 12), Ui.dp(c, 1)));
                preview.setTextColor(Theme.textFor(col, nightPreview));
                float[] h1 = {hsv[0], 1f, 1f};
                sat.setColors(new int[]{Color.HSVToColor(new float[]{hsv[0], 0f, hsv[2]}), Color.HSVToColor(new float[]{hsv[0], 1f, hsv[2]})});
                val.setColors(new int[]{0xFF000000, Color.HSVToColor(new float[]{hsv[0], hsv[1], 1f})});
                hue.invalidate();
            }
        };
        int[] rainbow = new int[7];
        for (int i = 0; i < 7; i++) rainbow[i] = Color.HSVToColor(new float[]{i * 60f, 1f, 1f});
        hue.setColors(rainbow);
        hue.value = hsv[0] / 360f;
        sat.value = hsv[1];
        val.value = hsv[2];
        Slider.Listener sl = new Slider.Listener() { @Override public void changed() { update.run(); } };
        hue.listener = sl; sat.listener = sl; val.listener = sl;
        addRow(c, th, root, "色相", hue);
        addRow(c, th, root, "饱和度", sat);
        addRow(c, th, root, "亮度", val);
        update.run();

        AlertDialog.Builder b = Ui.dialog(c, th).setTitle("自定义背景色").setView(root)
                .setPositiveButton("使用", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) { l.onPick(Color.HSVToColor(hsv)); }
                })
                .setNegativeButton("取消", null);
        Ui.show(b, th);
    }

    private static void addRow(Context c, Theme th, LinearLayout root, String name, Slider s) {
        TextView t = Ui.text(c, name, 12.5f, th.sub);
        t.setPadding(0, Ui.dp(c, 12), 0, 0);
        root.addView(t);
        root.addView(s, new LinearLayout.LayoutParams(-1, Ui.dp(c, 36)));
    }

    static final class Slider extends View {
        interface Listener { void changed(); }
        float value;
        Listener listener;
        private int[] colors = {0xFF000000, 0xFFFFFFFF};
        private final Paint track = new Paint(Paint.ANTI_ALIAS_FLAG), knob = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final RectF r = new RectF();

        Slider(Context c) {
            super(c);
            knob.setStyle(Paint.Style.STROKE);
        }

        void setColors(int[] cs) {
            colors = cs;
            invalidate();
        }

        @Override protected void onDraw(Canvas c) {
            float d = getResources().getDisplayMetrics().density;
            float kr = 10 * d;
            r.set(kr, getHeight() / 2f - 5 * d, getWidth() - kr, getHeight() / 2f + 5 * d);
            track.setShader(new LinearGradient(r.left, 0, r.right, 0, colors, null, Shader.TileMode.CLAMP));
            c.drawRoundRect(r, 5 * d, 5 * d, track);
            float x = r.left + value * r.width(), y = getHeight() / 2f;
            knob.setStyle(Paint.Style.FILL);
            knob.setColor(0xFFFFFFFF);
            knob.setShadowLayer(3 * d, 0, d, 0x55000000);
            c.drawCircle(x, y, kr, knob);
            knob.setShadowLayer(0, 0, 0, 0);
        }

        @Override public boolean onTouchEvent(MotionEvent e) {
            float d = getResources().getDisplayMetrics().density, kr = 10 * d;
            value = Math.max(0f, Math.min(1f, (e.getX() - kr) / Math.max(1f, getWidth() - 2 * kr)));
            if (e.getAction() == MotionEvent.ACTION_DOWN && getParent() != null) getParent().requestDisallowInterceptTouchEvent(true);
            if (listener != null) listener.changed();
            invalidate();
            return true;
        }
    }
}

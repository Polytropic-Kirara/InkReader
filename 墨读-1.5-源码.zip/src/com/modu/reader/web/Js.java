package com.modu.reader.web;

import java.util.HashMap;
import java.util.Map;

/**
 * JavaScript support for book-source rules. The host (a WebView on Android, Node in tests) runs code
 * with Legado-style globals: result, baseUrl, key, page, book, chapter, source, java.*, cookie.
 */
public final class Js {
    private Js() {}

    public interface Host {
        /** Runs {@code code}; returns the value as a JSON-like Java object (String, Map, List, Number, Boolean or null). */
        Object eval(String code, Map<String, Object> vars) throws Exception;
    }

    public static volatile Host host;

    /** Per-thread context for the rules being evaluated (source, key, page, book…). */
    private static final ThreadLocal<Map<String, Object>> CTX = new ThreadLocal<Map<String, Object>>() {
        @Override protected Map<String, Object> initialValue() { return new HashMap<String, Object>(); }
    };
    /** True while a bridge call (java.ajax …) is running, to avoid re-entering the single JS context. */
    public static final ThreadLocal<Boolean> IN_BRIDGE = new ThreadLocal<Boolean>() {
        @Override protected Boolean initialValue() { return false; }
    };

    public static boolean available() { return host != null && !IN_BRIDGE.get(); }

    public static Map<String, Object> ctx() { return CTX.get(); }

    public static void set(String k, Object v) { CTX.get().put(k, v); }

    public static Object run(String code, Object result, String baseUrl) throws Exception {
        Host h = host;
        if (h == null || IN_BRIDGE.get()) throw new Exception("不支持 JavaScript");
        Map<String, Object> vars = new HashMap<String, Object>(CTX.get());
        vars.put("result", result);
        vars.put("baseUrl", baseUrl == null ? "" : baseUrl);
        return h.eval(code, vars);
    }

    /** JavaScript that defines the java.* helpers on top of a native bridge object {@code __java}. */
    public static final String PRELUDE =
            "(function(){if(window.__modu)return;window.__modu=1;var J=window.__java;" +
            "function R(b,u){b=b==null?'':String(b);return{body:function(){return b},toString:function(){return b},code:function(){return 200},url:function(){return u},headers:function(){return {}}};}" +
            "window.java={" +
            "ajax:function(u){return J.ajax(String(u))}," +
            "ajaxAll:function(a){var o=[];for(var i=0;i<a.length;i++)o.push(R(J.ajax(String(a[i])),String(a[i])));return o}," +
            "connect:function(u){return R(J.ajax(String(u)),String(u))}," +
            "get:function(k){var v=J.get(String(k));return v==null?'':v}," +
            "put:function(k,v){J.put(String(k),v==null?'':String(v));return v}," +
            "getString:function(r,c,u){return J.getString(String(r),c==null?null:String(c),!!u)}," +
            "getStringList:function(r,c,u){return JSON.parse(J.getStringList(String(r),c==null?null:String(c),!!u))}," +
            "getElements:function(r){return JSON.parse(J.getStringList('@css:'+String(r).replace(/^@css:/,'')+'@html',null,false))}," +
            "getElement:function(r){var l=java.getElements(r);return l.length?l[0]:''}," +
            "setContent:function(c,b){J.setContent(String(c),b==null?null:String(b))}," +
            "base64Decode:function(s,c){return J.base64Decode(String(s),c?String(c):'UTF-8')}," +
            "base64Encode:function(s,f){return J.base64Encode(String(s))}," +
            "md5Encode:function(s){return J.md5(String(s))}," +
            "md5Encode16:function(s){return J.md5(String(s)).substring(8,24)}," +
            "encodeURI:function(s,c){return J.encode(String(s),c?String(c):'UTF-8')}," +
            "timeFormat:function(t){return J.timeFormat(String(t))}," +
            "timeFormatUTC:function(t,f,o){return J.timeFormat(String(t))}," +
            "htmlFormat:function(s){return J.htmlFormat(String(s))}," +
            "log:function(s){J.log(String(s));return s},logType:function(s){return typeof s}," +
            "toast:function(s){J.log('toast: '+s)},longToast:function(s){J.log('toast: '+s)}," +
            "randomUUID:function(){return J.uuid()}," +
            "androidId:function(){return J.uuid().replace(/-/g,'').substring(0,16)}," +
            "aesDecodeToString:function(d,k,t,iv){return J.aes(String(d),String(k),String(t),iv==null?'':String(iv),true)}," +
            "aesBase64DecodeToString:function(d,k,t,iv){return J.aes(String(d),String(k),String(t),iv==null?'':String(iv),true)}," +
            "aesEncodeToBase64String:function(d,k,t,iv){return J.aes(String(d),String(k),String(t),iv==null?'':String(iv),false)}," +
            "aesEncodeToString:function(d,k,t,iv){return J.aes(String(d),String(k),String(t),iv==null?'':String(iv),false)}," +
            "createSymmetricCrypto:function(t,k,iv){return{decryptStr:function(d){return J.aes(String(d),String(k),String(t),iv==null?'':String(iv),true)}," +
            "encryptBase64:function(d){return J.aes(String(d),String(k),String(t),iv==null?'':String(iv),false)}}}," +
            "hexDecodeToString:function(h){var s='';for(var i=0;i<h.length;i+=2)s+='%'+h.substr(i,2);try{return decodeURIComponent(s)}catch(e){return unescape(s)}}," +
            "hexEncodeToString:function(s){var u=unescape(encodeURIComponent(s)),o='';for(var i=0;i<u.length;i++)o+=('0'+u.charCodeAt(i).toString(16)).slice(-2);return o}," +
            "utf8ToGbk:function(s){return s},t2s:function(s){return s},s2t:function(s){return s}," +
            "getCookie:function(t,k){return J.cookie(String(t),k?String(k):'')}," +
            "startBrowser:function(){},startBrowserAwait:function(u){return R(J.ajax(String(u)),String(u))}" +
            "};" +
            "window.cookie={getCookie:function(u){return J.cookie(String(u),'')},getKey:function(u,k){return J.cookie(String(u),String(k))},setCookie:function(){},removeCookie:function(){}};" +
            "window.__norm=function(v){if(v===undefined)return null;if(v&&typeof v==='object'&&!Array.isArray(v)&&typeof v.body==='function')return v.body();" +
            "if(v instanceof String)return String(v);if(Array.isArray(v))return v.map(function(x){return x&&typeof x==='object'&&typeof x.body==='function'?x.body():x});return v};" +
            "})();";

    /** Wraps code so it runs with the given globals and returns {"ok":1,"v":value} as a JSON string. */
    public static String wrap(String code, Map<String, Object> vars) {
        StringBuilder sb = new StringBuilder("(function(){");
        for (Map.Entry<String, Object> e : vars.entrySet()) {
            String k = e.getKey();
            if (!k.matches("[A-Za-z_$][A-Za-z0-9_$]*") || k.equals("source") || k.startsWith("__")) continue;
            sb.append("var ").append(k).append('=').append(Json.write(plain(e.getValue()))).append(';');
        }
        Object src = vars.get("source");
        Map<String, Object> sm = src instanceof Map ? Json.map(src) : new HashMap<String, Object>();
        sb.append("var source=").append(Json.write(sm)).append(";source.getKey=function(){return source.bookSourceUrl||''};")
                .append("source.getVariable=function(){return java.get('__var_'+source.bookSourceUrl)};")
                .append("source.setVariable=function(v){java.put('__var_'+source.bookSourceUrl,v)};")
                .append("if(typeof book==='object'&&book){book.getVariable=function(k){return java.get('__book_'+(k||''))};book.setVariable=function(k,v){java.put('__book_'+k,v)};}")
                .append("try{var __v=eval(").append(Json.write(code)).append(");return JSON.stringify({ok:1,v:__norm(__v)});}")
                .append("catch(e){return JSON.stringify({ok:0,e:String(e&&e.message||e)});}})()");
        return sb.toString();
    }

    private static Object plain(Object v) {
        if (v == null || v instanceof String || v instanceof Number || v instanceof Boolean || v instanceof Map || v instanceof java.util.List) return v;
        if (v instanceof Dom.Node) return Html.outer((Dom.Node) v, false);
        return String.valueOf(v);
    }

    /** Decodes the {"ok":..} envelope produced by {@link #wrap}. */
    public static Object unwrap(String json) throws Exception {
        Map<String, Object> m = Json.map(Json.parse(json));
        Object ok = m.get("ok");
        if (ok instanceof Number && ((Number) ok).intValue() == 1) return m.get("v");
        throw new Exception("JavaScript 出错：" + Json.str(m, "e"));
    }
}

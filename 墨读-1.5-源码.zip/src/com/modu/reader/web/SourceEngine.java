package com.modu.reader.web;

import java.io.IOException;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Runs a book source: search, book details, table of contents and chapter text. */
public final class SourceEngine {
    public static final class Result {
        public String name = "", author = "", kind = "", lastChapter = "", intro = "", cover = "", bookUrl = "";
        public BookSource source;
    }

    public static final class Info {
        public String name = "", author = "", kind = "", lastChapter = "", intro = "", cover = "", tocUrl = "";
    }

    private final Fetcher f;

    public SourceEngine(Fetcher f) { this.f = f; }

    // ---- requests ----------------------------------------------------------------------

    private static final Pattern TPL = Pattern.compile("\\{\\{(.*?)\\}\\}");
    private static final Pattern PAGE_LIST = Pattern.compile("<([^<>]*,[^<>]*)>");

    /** Builds and performs a request from a source URL rule ("path?k={{key}},{json options}"). */
    public Source.Page request(BookSource s, String rule, String key, int page, String referer) throws IOException {
        rule = rule.trim();
        if ((rule.startsWith("<js>") || rule.startsWith("@js:")) && Js.available()) {
            // the URL itself is computed by a script
            Js.set("key", key);
            Js.set("page", page);
            String code = rule.startsWith("@js:") ? rule.substring(4) : rule.substring(4, rule.indexOf("</js>") < 0 ? rule.length() : rule.indexOf("</js>"));
            String rest = rule.startsWith("<js>") && rule.indexOf("</js>") >= 0 ? rule.substring(rule.indexOf("</js>") + 5) : "";
            try { rule = Json.text(Js.run(code, rest, s.url)).trim(); } catch (Exception e) { throw new IOException(e.getMessage()); }
        }
        String urlPart = rule.trim(), opts = null;
        int comma = Rules.indexTop(urlPart, ",{");
        if (comma > 0 && urlPart.endsWith("}")) { opts = urlPart.substring(comma + 1); urlPart = urlPart.substring(0, comma); }
        Map<String, Object> o = new LinkedHashMap<String, Object>();
        if (opts != null) { try { o = Json.map(Json.parse(opts)); } catch (Exception ignored) {} }
        String charset = Json.str(o, "charset");
        if (charset.length() == 0) charset = null;
        String method = Json.str(o, "method").toUpperCase();
        String body = o.containsKey("body") ? Json.text(o.get("body")) : null;
        urlPart = fill(urlPart, key, page, charset);
        if (body != null) body = fill(body, key, page, charset);
        String full = Extractor.resolve(s.url.endsWith("/") || urlPart.startsWith("/") || urlPart.startsWith("http") ? s.url : s.url + "/", urlPart);
        if (full == null) throw new IOException("书源地址无效");
        Map<String, String> headers = new LinkedHashMap<String, String>();
        String header = s.header.trim();
        if ((header.startsWith("@js:") || header.startsWith("<js>")) && Js.available()) {
            try {
                String code = header.startsWith("@js:") ? header.substring(4) : header.substring(4, header.indexOf("</js>") < 0 ? header.length() : header.indexOf("</js>"));
                header = Json.text(Js.run(code, "", s.url));
            } catch (Exception e) { header = ""; }
        }
        if (header.length() > 0 && !Rules.usesJs(header)) {
            try { for (Map.Entry<String, Object> e : Json.map(Json.parse(header)).entrySet()) headers.put(e.getKey(), Json.text(e.getValue())); } catch (Exception ignored) {}
        }
        Object hh = o.get("headers");
        if (hh instanceof String) { try { hh = Json.parse((String) hh); } catch (Exception ignored) {} }
        for (Map.Entry<String, Object> e : Json.map(hh).entrySet()) headers.put(e.getKey(), Json.text(e.getValue()));
        if (headers.containsKey("User-Agent")) { f.userAgentOverride = headers.remove("User-Agent"); }
        try {
            return f.request(full, referer, "POST".equals(method) || (body != null && !"GET".equals(method)) ? (body == null ? "" : body) : null, charset, headers);
        } finally {
            f.userAgentOverride = null;
        }
    }

    private static String fill(String t, String key, int page, String charset) {
        Matcher pl = PAGE_LIST.matcher(t);
        StringBuffer sb = new StringBuffer();
        while (pl.find()) {
            String[] items = pl.group(1).split(",", -1);
            String pick = items[Math.min(Math.max(page, 1), items.length) - 1];
            pl.appendReplacement(sb, Matcher.quoteReplacement(pick));
        }
        pl.appendTail(sb);
        t = sb.toString();
        Matcher m = TPL.matcher(t);
        sb = new StringBuffer();
        while (m.find()) {
            String inner = m.group(1).trim(), val;
            if (inner.equals("key")) val = encode(key, charset);
            else if (inner.equals("page")) val = String.valueOf(page);
            else if (inner.matches("[0-9page+\\-*/()\\s]+")) val = String.valueOf(arith(inner.replace("page", String.valueOf(page))));
            else if (Js.available()) {
                try {
                    Js.set("key", key);
                    Js.set("page", page);
                    val = Json.text(Js.run(inner, "", ""));
                } catch (Exception e) { val = ""; }
            } else val = "";
            m.appendReplacement(sb, Matcher.quoteReplacement(val));
        }
        m.appendTail(sb);
        return sb.toString().replace("searchKey", encode(key, charset)).replace("searchPage", String.valueOf(page));
    }

    private static String encode(String s, String charset) {
        if (s == null) return "";
        try { return URLEncoder.encode(s, charset == null ? "UTF-8" : charset).replace("+", "%20"); } catch (Exception e) { return s; }
    }

    /** + - * / and parentheses on integers. */
    static long arith(String e) {
        final String s = e.replace(" ", "");
        final int[] pos = {0};
        return new Object() {
            long expr() { long v = term(); while (pos[0] < s.length() && (s.charAt(pos[0]) == '+' || s.charAt(pos[0]) == '-')) { char op = s.charAt(pos[0]++); long t = term(); v = op == '+' ? v + t : v - t; } return v; }
            long term() { long v = fac(); while (pos[0] < s.length() && (s.charAt(pos[0]) == '*' || s.charAt(pos[0]) == '/')) { char op = s.charAt(pos[0]++); long t = fac(); v = op == '*' ? v * t : (t == 0 ? 0 : v / t); } return v; }
            long fac() {
                if (pos[0] < s.length() && s.charAt(pos[0]) == '(') { pos[0]++; long v = expr(); pos[0]++; return v; }
                if (pos[0] < s.length() && s.charAt(pos[0]) == '-') { pos[0]++; return -fac(); }
                int a = pos[0];
                while (pos[0] < s.length() && Character.isDigit(s.charAt(pos[0]))) pos[0]++;
                return a == pos[0] ? 0 : Long.parseLong(s.substring(a, pos[0]));
            }
        }.expr();
    }

    private Object init(BookSource s, Map<String, Object> rules, Object root) {
        String init = s.rule(rules, "init");
        if (init.length() == 0 || (Rules.usesJs(init) && !Js.available())) return root;
        List<Object> l = Rules.elements(root, init);
        return l.isEmpty() ? root : l.get(0);
    }

    // ---- search ------------------------------------------------------------------------

    private void context(BookSource s, String key, int page) {
        Js.ctx().clear();
        Js.set("key", key == null ? "" : key);
        Js.set("page", page);
        Js.set("source", s.toMap());
        Js.set("__source", s);
        Js.set("__engine", this);
    }

    private void content(Object root, String url) {
        Js.set("__content", root);
        Js.set("__baseUrl", url);
        Js.set("baseUrl", url);
    }

    public List<Result> search(BookSource s, String key, int page) throws IOException {
        if (!s.canSearch()) throw new IOException("这个书源的搜索需要 JavaScript，暂不支持");
        context(s, key, page);
        Source.Page p = request(s, s.searchUrl, key, page, null);
        Object root = Rules.parseBody(p.html);
        content(root, p.url);
        List<Result> out = new ArrayList<Result>();
        String listRule = s.rule(s.search, "bookList");
        boolean reverse = listRule.startsWith("-");
        if (reverse || listRule.startsWith("+")) listRule = listRule.substring(1);
        List<Object> items = Rules.elements(root, listRule);
        if (items.isEmpty() && s.rule(s.info, "name").length() > 0) {
            // some sites jump straight to the book page when there is one match
            Info in = parseInfo(s, init(s, s.info, root), p.url);
            if (in.name.length() > 0) {
                Result r = new Result();
                r.name = in.name; r.author = in.author; r.kind = in.kind; r.lastChapter = in.lastChapter;
                r.intro = in.intro; r.cover = in.cover; r.bookUrl = p.url; r.source = s;
                out.add(r);
                return out;
            }
        }
        for (Object it : items) {
            Result r = new Result();
            r.source = s;
            r.name = clean(Rules.string(it, s.rule(s.search, "name"), p.url, false));
            if (r.name.length() == 0) continue;
            r.author = cleanAuthor(Rules.string(it, s.rule(s.search, "author"), p.url, false));
            r.kind = clean(Rules.string(it, s.rule(s.search, "kind"), p.url, false).replace('\n', ' '));
            r.lastChapter = clean(Rules.string(it, s.rule(s.search, "lastChapter"), p.url, false));
            r.intro = Rules.string(it, s.rule(s.search, "intro"), p.url, false).trim();
            r.cover = Rules.string(it, s.rule(s.search, "coverUrl"), p.url, true);
            r.bookUrl = Rules.string(it, s.rule(s.search, "bookUrl"), p.url, true);
            if (r.bookUrl.length() == 0) r.bookUrl = p.url;
            out.add(r);
        }
        if (reverse) java.util.Collections.reverse(out);
        return out;
    }

    private static String clean(String s) { return s == null ? "" : s.replaceAll("[\\s　]+", " ").trim(); }

    private static String cleanAuthor(String s) {
        return clean(s).replaceAll("^(作\\s*者|作者名|著)\\s*[：:]?\\s*", "").replaceAll("\\s*(著|所著)$", "");
    }

    // ---- details & contents ------------------------------------------------------------

    private Info parseInfo(BookSource s, Object node, String base) {
        Info in = new Info();
        Map<String, Object> r = s.info;
        in.name = clean(Rules.string(node, s.rule(r, "name"), base, false));
        in.author = cleanAuthor(Rules.string(node, s.rule(r, "author"), base, false));
        in.kind = clean(Rules.string(node, s.rule(r, "kind"), base, false).replace('\n', ' '));
        in.lastChapter = clean(Rules.string(node, s.rule(r, "lastChapter"), base, false));
        in.intro = Rules.string(node, s.rule(r, "intro"), base, false).trim();
        in.cover = Rules.string(node, s.rule(r, "coverUrl"), base, true);
        String toc = s.rule(r, "tocUrl");
        in.tocUrl = toc.length() == 0 ? base : Rules.string(node, toc, base, true);
        if (in.tocUrl.length() == 0) in.tocUrl = base;
        return in;
    }

    public Info info(BookSource s, Result r) throws IOException {
        Info base = new Info();
        base.name = r.name; base.author = r.author; base.kind = r.kind; base.lastChapter = r.lastChapter;
        base.intro = r.intro; base.cover = r.cover; base.tocUrl = r.bookUrl;
        if (s.info.isEmpty()) return base;
        context(s, "", 1);
        Js.set("book", bookMap(r.name, r.author, r.bookUrl));
        Source.Page p = request(s, r.bookUrl, "", 1, null);
        Object root = Rules.parseBody(p.html);
        content(root, p.url);
        Info in = parseInfo(s, init(s, s.info, root), p.url);
        if (in.name.length() == 0) in.name = base.name;
        if (in.author.length() == 0) in.author = base.author;
        if (in.intro.length() == 0) in.intro = base.intro;
        if (in.cover.length() == 0) in.cover = base.cover;
        if (in.kind.length() == 0) in.kind = base.kind;
        if (in.lastChapter.length() == 0) in.lastChapter = base.lastChapter;
        return in;
    }

    private static Map<String, Object> bookMap(String name, String author, String url) {
        Map<String, Object> b = new LinkedHashMap<String, Object>();
        b.put("name", name == null ? "" : name);
        b.put("author", author == null ? "" : author);
        b.put("bookUrl", url == null ? "" : url);
        b.put("tocUrl", url == null ? "" : url);
        return b;
    }

    public List<String[]> toc(BookSource s, String tocUrl) throws IOException {
        context(s, "", 1);
        if (!Js.ctx().containsKey("book")) Js.set("book", bookMap("", "", tocUrl));
        List<String[]> out = new ArrayList<String[]>();
        Set<String> seenPages = new HashSet<String>(), seenUrls = new HashSet<String>();
        List<String> queue = new ArrayList<String>();
        queue.add(tocUrl);
        String listRule = s.rule(s.toc, "chapterList");
        boolean reverse = listRule.startsWith("-");
        if (reverse || listRule.startsWith("+")) listRule = listRule.substring(1);
        int pages = 0;
        while (!queue.isEmpty() && pages < 100) {
            String url = queue.remove(0);
            if (seenPages.contains(url)) continue;
            seenPages.add(url);
            pages++;
            Source.Page p = request(s, url, "", 1, null);
            Object root = Rules.parseBody(p.html);
            content(root, p.url);
            List<Object> items = Rules.elements(root, listRule);
            if (items.isEmpty() && pages == 1 && listRule.length() == 0) {
                for (String[] e : Extractor.toc(Dom.parse(p.html), p.url).links) out.add(e);
                break;
            }
            List<String[]> pageItems = new ArrayList<String[]>();
            for (Object it : items) {
                String name = clean(Rules.string(it, s.rule(s.toc, "chapterName"), p.url, false));
                String u = Rules.string(it, s.rule(s.toc, "chapterUrl"), p.url, true);
                if (u.length() == 0) u = p.url + "#" + (out.size() + pageItems.size());
                if (name.length() == 0 || seenUrls.contains(u)) continue;
                seenUrls.add(u);
                pageItems.add(new String[]{name, u});
            }
            if (reverse) java.util.Collections.reverse(pageItems);
            out.addAll(pageItems);
            String next = s.rule(s.toc, "nextTocUrl");
            if (next.length() > 0) for (String n : Rules.strings(root, next, p.url, true)) if (!seenPages.contains(n) && !n.equals(p.url)) queue.add(n);
        }
        return out;
    }

    public List<String> content(BookSource s, String url, String nextChapterUrl, List<String> adRules) throws IOException {
        context(s, "", 1);
        Map<String, Object> ch = new LinkedHashMap<String, Object>();
        ch.put("url", url);
        ch.put("title", "");
        Js.set("chapter", ch);
        Js.set("nextChapterUrl", nextChapterUrl == null ? "" : nextChapterUrl);
        String rule = s.rule(s.content, "content");
        List<String> lines = new ArrayList<String>();
        Set<String> seen = new HashSet<String>();
        String cur = url, title = "";
        int pages = 0;
        while (cur != null && cur.length() > 0 && pages < 30 && !seen.contains(cur)) {
            seen.add(cur);
            pages++;
            Source.Page p = request(s, cur, "", 1, null);
            if (rule.length() == 0 || (Rules.usesJs(rule) && !Js.available())) {
                Extractor.Chapter c = Extractor.chapter(Dom.parse(p.html), p.url, adRules);
                return c.paras;
            }
            Object root = Rules.parseBody(p.html);
            content(root, p.url);
            String text = Rules.string(root, rule, p.url, false);
            if (text.indexOf('<') >= 0 && text.indexOf('>') > text.indexOf('<')) text = Dom.parse(text).text();
            for (String l : text.split("\n")) lines.add(l);
            String next = s.rule(s.content, "nextContentUrl");
            cur = next.length() == 0 ? null : Rules.string(root, next, p.url, true);
            if (cur != null && nextChapterUrl != null && cur.equals(nextChapterUrl)) cur = null;
        }
        String joined;
        String replace = s.rule(s.content, "replaceRegex");
        if (replace.length() > 0 && !Rules.usesJs(replace)) {
            StringBuilder sb = new StringBuilder();
            for (String l : lines) sb.append(l).append('\n');
            joined = applyReplace(sb.toString(), replace);
            lines = new ArrayList<String>();
            for (String l : joined.split("\n")) lines.add(l);
        }
        return Extractor.filterLines(lines, title, adRules);
    }

    /** replaceRegex "##a|b##repl##c" style: pairs of pattern/replacement separated by ##. */
    static String applyReplace(String text, String spec) {
        String s = spec.startsWith("##") ? spec.substring(2) : spec;
        String[] parts = s.split("##", -1);
        for (int i = 0; i < parts.length; i += 2) {
            String pat = parts[i], rep = i + 1 < parts.length ? parts[i + 1] : "";
            if (pat.length() == 0) continue;
            try { text = text.replaceAll(pat, rep); } catch (Exception e) { text = text.replace(pat, rep); }
        }
        return text;
    }
}

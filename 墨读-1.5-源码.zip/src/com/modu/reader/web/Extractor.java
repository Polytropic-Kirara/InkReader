package com.modu.reader.web;

import com.modu.reader.core.HtmlText;
import com.modu.reader.core.Util;

import java.net.URI;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Finds the reading text of a novel chapter page (readability-style scoring tuned for Chinese
 * novel sites), plus the chapter title, book name and the previous / next / contents links.
 * Also recognises table-of-contents pages and returns their chapter links in order.
 */
public final class Extractor {
    private Extractor() {}

    public static final class Chapter {
        public String title = "", rawTitle = "", bookName = "", author = "";
        public String nextUrl, prevUrl, tocUrl;
        public boolean nextIsPage;
        public final List<String> paras = new ArrayList<String>();

        public int chars() {
            int c = 0;
            for (String p : paras) c += p.length();
            return c;
        }
    }

    public static final class Toc {
        public String bookName = "", author = "", nextPage;
        public final List<String[]> links = new ArrayList<String[]>(); // {title, url}
    }

    // ---- noise -------------------------------------------------------------------------

    private static final Set<String> NOISE_TAGS = new HashSet<String>();
    private static final Set<String> NOISE_WORDS = new HashSet<String>();
    static {
        for (String s : new String[]{"script", "style", "noscript", "iframe", "select", "button", "input", "textarea",
                "svg", "canvas", "video", "audio", "object", "embed", "template", "nav", "footer", "aside", "form"}) NOISE_TAGS.add(s);
        for (String s : new String[]{"ad", "ads", "adv", "advert", "advertisement", "banner", "footer", "foot", "copyright",
                "comment", "comments", "share", "recommend", "related", "sidebar", "side", "menu", "nav", "navbar", "breadcrumb",
                "crumbs", "toolbar", "login", "search", "rank", "tuijian", "guanggao", "gg", "topbar", "setting", "readset",
                "hot", "links", "friendlink", "tags", "bottom", "pagebar", "report", "popup", "modal", "dialog", "cookie",
                "sponsor", "promo", "download", "app", "qrcode"}) NOISE_WORDS.add(s);
    }

    private static final Pattern GOOD = Pattern.compile("(?i)(content|chapter|text|txt|article|read|book|nr\\d*|novel|zhengwen|cont|main|entry|detail)");

    private static boolean noisy(Dom.Node n) {
        String s = (n.id() + " " + n.cls()).toLowerCase();
        if (s.trim().length() == 0) return false;
        for (String tok : s.split("[\\s_\\-]+")) if (NOISE_WORDS.contains(tok)) return true;
        return false;
    }

    private static void clean(Dom.Node n) {
        List<Dom.Node> kids = new ArrayList<Dom.Node>(n.children);
        for (Dom.Node c : kids) {
            if (c.isText()) continue;
            if (NOISE_TAGS.contains(c.tag)) { c.remove(); continue; }
            String style = c.attr("style");
            if (style != null && style.replace(" ", "").toLowerCase().contains("display:none")) { c.remove(); continue; }
            if (noisy(c)) {
                int[] tl = textAndLinks(c);
                if (tl[0] < 300 || tl[1] > tl[0] * 0.4) { c.remove(); continue; }
            }
            clean(c);
        }
    }

    // ---- scoring -----------------------------------------------------------------------

    private static int weight(String s) {
        int w = 0;
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c >= 0x4E00 && c <= 0x9FFF) w += 3;
            else if (c > ' ' && c != '　') w += 1;
        }
        return w;
    }

    /** {total text weight, weight inside links} for a subtree. */
    private static int[] textAndLinks(Dom.Node n) {
        int[] r = new int[2];
        tl(n, false, r);
        return r;
    }

    private static void tl(Dom.Node n, boolean inLink, int[] r) {
        if (n.isText()) {
            int w = weight(n.text);
            r[0] += w;
            if (inLink) r[1] += w;
            return;
        }
        boolean link = inLink || n.tag.equals("a");
        for (Dom.Node c : n.children) tl(c, link, r);
    }

    private static boolean hasBlockChild(Dom.Node n) {
        for (Dom.Node c : n.children) if (!c.isText() && !c.tag.equals("br") && Dom.BLOCK.contains(c.tag)) return true;
        return false;
    }

    /** Text that sits directly in this element: its own text nodes, inline children and simple paragraph children. */
    private static int directWeight(Dom.Node n) {
        int w = 0;
        for (Dom.Node c : n.children) {
            if (c.isText()) w += weight(c.text);
            else if (c.tag.equals("a")) continue;
            else if (!Dom.BLOCK.contains(c.tag) || ((c.tag.equals("p") || c.tag.equals("div")) && !hasBlockChild(c))) {
                int[] t = textAndLinks(c);
                w += t[0] - t[1];
            }
        }
        return w;
    }

    private static Dom.Node best;
    private static double bestScore;

    private static synchronized Dom.Node pick(Dom.Node root) {
        best = null;
        bestScore = 0;
        score(root);
        return best;
    }

    private static void score(Dom.Node n) {
        for (Dom.Node c : n.children) {
            if (c.isText()) continue;
            if (!c.tag.equals("a")) {
                int d = directWeight(c);
                if (d > 60) {
                    int[] t = textAndLinks(c);
                    double density = t[0] == 0 ? 1 : (double) t[1] / t[0];
                    double s = d * (1 - density);
                    if (GOOD.matcher(c.id() + " " + c.cls()).find()) s *= 1.3;
                    int lines = 0;
                    for (Dom.Node k : c.children) if (!k.isText() && (k.tag.equals("br") || k.tag.equals("p"))) lines++;
                    s *= 1 + Math.min(0.5, lines / 40.0);
                    if (s > bestScore) { bestScore = s; best = c; }
                }
            }
            score(c);
        }
    }

    // ---- ad lines ----------------------------------------------------------------------

    private static final Pattern AD_PHRASE = Pattern.compile(
            "请收藏|加入书签|最新章节|最快更新|更新最快|手机阅读|手机用户|手机版|本章未完|点击下一页|下一页继续|请记住本书|"
                    + "记住本站|本站地址|天才一秒|一秒记住|推荐票|求月票|求订阅|章节错误|txt下载|全文阅读|免费阅读|无弹窗|"
                    + "看最新|百度搜索|请访问|书友群|阅读模式|转码|最新网址|新笔趣阁|笔趣阁|顶点小说|请勿转载|章节报错|"
                    + "未完待续请|移动版|app下载|关注公众号|公众号|微信搜|(?i:https?://|www\\.)");
    private static final Pattern DOMAIN = Pattern.compile("(?i)[a-z0-9-]+\\.(com|net|org|cc|la|cn|co|info|xyz|top|me|io|tw|vip|biz|site|online)\\b");
    private static final Pattern INLINE_AD = Pattern.compile(
            "[（(\\[【][^（）()\\[\\]【】]{0,40}?(收藏|最新|阅读|www|com|net|本站|网址|更新|手机|首发|笔趣)[^（）()\\[\\]【】]{0,40}?[）)\\]】]");

    public static List<String> filterLines(List<String> lines, String title, List<String> userRules) {
        List<String> out = new ArrayList<String>();
        List<Pattern> custom = new ArrayList<Pattern>();
        if (userRules != null) for (String r : userRules) {
            r = r.trim();
            if (r.length() == 0) continue;
            try { custom.add(Pattern.compile(r)); } catch (Exception e) { custom.add(Pattern.compile(Pattern.quote(r))); }
        }
        String nt = norm(title);
        for (String line : lines) {
            String t = Util.trim(line);
            for (Pattern p : custom) t = p.matcher(t).replaceAll("");
            t = INLINE_AD.matcher(t).replaceAll("");
            t = Util.trim(t);
            if (t.length() == 0) continue;
            if (out.isEmpty() && nt.length() > 0 && norm(t).equals(nt)) continue; // title repeated in body
            boolean ad = (t.length() < 80 && (AD_PHRASE.matcher(t).find() || DOMAIN.matcher(t).find()));
            if (ad) continue;
            out.add(t);
        }
        // trailing junk such as "上一章 目录 下一章"
        while (!out.isEmpty()) {
            String last = out.get(out.size() - 1);
            if (last.length() < 30 && (last.contains("上一章") || last.contains("下一章") || last.contains("目录") || last.contains("返回"))) out.remove(out.size() - 1);
            else break;
        }
        return out;
    }

    // ---- titles ------------------------------------------------------------------------

    private static final Pattern PAGE_MARK = Pattern.compile(
            "\\s*([（(]\\s*\\d+\\s*/\\s*\\d+\\s*[）)]|[（(]?第\\s*\\d+\\s*页[）)]?|[（(]\\s*\\d+\\s*[）)]$|_\\d+$|-\\d+$|\\s+\\d+/\\d+$)");
    private static final Pattern SPLIT = Pattern.compile("\\s*[_|｜\\-—–]\\s*");

    /** Chapter title without page markers, for comparing pages of one chapter. */
    public static String norm(String t) {
        if (t == null) return "";
        String s = PAGE_MARK.matcher(t).replaceAll("");
        return s.replaceAll("[\\s　]+", "").replaceAll("[：:，,。.!！]+$", "");
    }

    public static String cleanTitle(String t) {
        return Util.trim(PAGE_MARK.matcher(t == null ? "" : t).replaceAll("")).replaceAll("\\s+", " ");
    }

    // ---- links -------------------------------------------------------------------------

    public static String resolve(String base, String href) {
        if (href == null) return null;
        href = href.trim();
        if (href.length() == 0 || href.startsWith("#") || href.toLowerCase().startsWith("javascript:") || href.startsWith("mailto:")) return null;
        try {
            return new URI(base.replace(" ", "%20")).resolve(href.replace(" ", "%20")).toString();
        } catch (Exception e) {
            try {
                if (href.startsWith("http")) return href;
                URI b = new URI(base);
                return b.getScheme() + "://" + b.getHost() + (href.startsWith("/") ? "" : "/") + href;
            } catch (Exception e2) {
                return null;
            }
        }
    }

    private static String linkText(Dom.Node a) {
        String t = a.ownText();
        if (t.length() == 0) { String ti = a.attr("title"); if (ti != null) t = ti; }
        return t.replaceAll("[←→《》<>«»\\[\\]【】→←↑↓\\s·]", "");
    }

    private static String stem(String url) {
        String u = url.replaceAll("[?#].*$", "");
        u = u.replaceAll("\\.(s?html?|php|aspx?|jsp)$", "");
        u = u.replaceAll("[_\\-]\\d{1,2}$", "");
        return u;
    }

    private static void links(Dom.Node root, String url, Chapter c) {
        String nextChapter = null, nextPage = null, prevChapter = null, prevPage = null, toc = null;
        for (Dom.Node a : root.all("a")) {
            String t = linkText(a);
            if (t.length() == 0 || t.length() > 12) continue;
            String href = resolve(url, a.attr("href"));
            if (href == null || href.equals(url)) continue;
            if (t.contains("下一章") || t.equals("下章") || t.contains("下一节") || t.contains("下一回") || t.contains("下一篇")) {
                if (nextChapter == null) nextChapter = href;
            } else if (t.contains("下一页") || t.equals("下页") || t.equalsIgnoreCase("next") || t.equals("下一頁")) {
                if (nextPage == null) nextPage = href;
            } else if (t.contains("上一章") || t.equals("上章") || t.contains("上一节") || t.contains("上一回") || t.contains("上一篇")) {
                if (prevChapter == null) prevChapter = href;
            } else if (t.contains("上一页") || t.equals("上页") || t.equals("上一頁")) {
                if (prevPage == null) prevPage = href;
            } else if (t.contains("目录") || t.equals("目錄") || t.contains("章节列表") || t.equals("返回书页") || t.equals("书页") || t.equals("返回目录")) {
                if (toc == null) toc = href;
            }
        }
        c.tocUrl = toc;
        c.prevUrl = prevChapter != null ? prevChapter : prevPage;
        boolean marked = PAGE_MARK.matcher(c.rawTitle).find();
        if (nextPage != null && (nextChapter == null || !nextPage.equals(nextChapter))
                && (nextChapter != null || marked || stem(nextPage).equals(stem(url)))) {
            c.nextUrl = nextPage;
            c.nextIsPage = true;
        } else {
            c.nextUrl = nextChapter != null ? nextChapter : nextPage;
        }
        if (c.nextUrl != null && toc != null && c.nextUrl.equals(toc)) c.nextUrl = null; // last chapter links back to contents
        if (c.nextUrl != null) {
            // "next" that points at the book's index page means the end
            try {
                String path = new URI(c.nextUrl).getPath();
                String cur = new URI(url).getPath();
                if (path != null && cur != null && path.endsWith("/") && cur.startsWith(path)) c.nextUrl = null;
            } catch (Exception ignored) {}
        }
    }

    // ---- chapter -----------------------------------------------------------------------

    public static Chapter chapter(Dom.Node root, String url, List<String> userRules) {
        Chapter c = new Chapter();
        Dom.Node titleTag = Dom.first(root, "title");
        String docTitle = titleTag == null ? "" : titleTag.ownText();
        String bn = Dom.meta(root, "og:novel:book_name");
        if (bn == null) bn = Dom.meta(root, "og:novel:bookname");
        String au = Dom.meta(root, "og:novel:author");
        if (au != null) c.author = au;


        // title: the heading closest before the content
        String h = null;
        for (String tag : new String[]{"h1", "h2", "h3"}) {
            for (Dom.Node hn : root.all(tag)) {
                String t = hn.ownText();
                if (t.length() >= 1 && t.length() <= 60) { h = t; break; }
            }
            if (h != null) break;
        }
        String[] parts = SPLIT.split(docTitle);
        if (h == null) h = parts.length > 0 ? parts[0] : docTitle;
        c.rawTitle = h;
        c.title = cleanTitle(h);
        if (bn != null) c.bookName = bn;
        else if (parts.length >= 2) {
            // "第一章 xx_书名_站名" or "书名 第一章 - 站名"
            String second = parts[1].trim();
            c.bookName = norm(parts[0]).equals(norm(h)) ? second : parts[0].replace(h, "").trim();
            if (c.bookName.length() == 0) c.bookName = second;
        }
        links(root, url, c);   // before cleaning: page bars are often inside "noisy" containers
        clean(root);
        Dom.Node body = pick(root);
        if (body == null) return c;
        List<String> lines = new ArrayList<String>();
        for (String l : body.text().split("\n")) lines.add(l);
        c.paras.addAll(filterLines(lines, c.title, userRules));
        return c;
    }

    // ---- table of contents -------------------------------------------------------------

    private static final Pattern CHAPTERISH = Pattern.compile(
            "^(第\\s*[0-9０-９零〇一二两三四五六七八九十百千万]+\\s*[章回节卷集部篇话]|[0-9０-９]{1,5}[\\.、．:：\\s]|序|楔子|引子|番外|终章|尾声|后记|chapter|Chapter)");

    public static Toc toc(Dom.Node root, String url) {
        Toc toc = new Toc();
        String bn = Dom.meta(root, "og:novel:book_name");
        String au = Dom.meta(root, "og:novel:author");
        if (au != null) toc.author = au;
        if (bn != null) toc.bookName = bn;
        else {
            Dom.Node h1 = Dom.first(root, "h1");
            if (h1 != null) toc.bookName = h1.ownText();
            else {
                Dom.Node t = Dom.first(root, "title");
                if (t != null) toc.bookName = SPLIT.split(t.ownText())[0];
            }
        }
        // group links by their container; the container with the most chapter-like links is the contents
        Map<Dom.Node, List<Dom.Node>> groups = new HashMap<Dom.Node, List<Dom.Node>>();
        for (Dom.Node a : root.all("a")) {
            String t = a.ownText();
            if (t.length() == 0 || t.length() > 50 || a.attr("href") == null) continue;
            Dom.Node box = a.parent;
            int up = 0;
            while (box != null && up < 4 && !(box.tag.equals("ul") || box.tag.equals("ol") || box.tag.equals("dl")
                    || box.tag.equals("tbody") || box.tag.equals("table") || (box.tag.equals("div") && box.all("a").size() >= 8))) {
                box = box.parent;
                up++;
            }
            if (box == null || up >= 4) box = a.parent;
            List<Dom.Node> l = groups.get(box);
            if (l == null) { l = new ArrayList<Dom.Node>(); groups.put(box, l); }
            l.add(a);
        }
        Dom.Node bestBox = null;
        int bestCount = 0;
        for (Map.Entry<Dom.Node, List<Dom.Node>> e : groups.entrySet()) {
            int ch = 0;
            for (Dom.Node a : e.getValue()) if (CHAPTERISH.matcher(a.ownText()).find()) ch++;
            int score = ch * 2 + e.getValue().size();
            if (ch >= 3 && score > bestCount) { bestCount = score; bestBox = e.getKey(); }
        }
        if (bestBox == null) return toc;
        List<Dom.Node> as = groups.get(bestBox);
        // a <dl> often starts with a "latest chapters" block before the real list (<dt>正文</dt>)
        if (bestBox.tag.equals("dl")) {
            int lastDt = -1, idx = 0;
            List<Dom.Node> kids = bestBox.elements();
            for (int i = 0; i < kids.size(); i++) if (kids.get(i).tag.equals("dt")) lastDt = i;
            if (lastDt > 0) {
                Set<Dom.Node> keep = new HashSet<Dom.Node>();
                for (int i = lastDt; i < kids.size(); i++) keep.addAll(kids.get(i).all("a"));
                List<Dom.Node> filtered = new ArrayList<Dom.Node>();
                for (Dom.Node a : as) if (keep.contains(a)) filtered.add(a);
                if (filtered.size() >= 3) as = filtered;
            }
        }
        // keep the last occurrence of each URL (a "latest" block repeats the final chapters first)
        Map<String, Integer> lastIndex = new HashMap<String, Integer>();
        List<String[]> raw = new ArrayList<String[]>();
        for (Dom.Node a : as) {
            String href = resolve(url, a.attr("href"));
            if (href == null) continue;
            raw.add(new String[]{Util.trim(a.ownText()), href});
            lastIndex.put(href, raw.size() - 1);
        }
        for (int i = 0; i < raw.size(); i++) if (lastIndex.get(raw.get(i)[1]) == i) toc.links.add(raw.get(i));
        // contents split over several pages
        for (Dom.Node a : root.all("a")) {
            String t = linkText(a);
            if ((t.contains("下一页") || t.equals("下页")) && !as.contains(a)) {
                String href = resolve(url, a.attr("href"));
                if (href != null && !href.equals(url)) { toc.nextPage = href; break; }
            }
        }
        return toc;
    }

    /** True when a page looks like a contents page rather than a chapter. */
    public static boolean looksLikeToc(Toc t, Chapter c) {
        return t.links.size() >= 10 && (c == null || c.chars() < 400 || t.links.size() > 30);
    }

    static String firstMatch(Pattern p, String s) {
        Matcher m = p.matcher(s);
        return m.find() ? m.group() : null;
    }

    @SuppressWarnings("unused")
    private static boolean isChapterLine(String s) { return HtmlText.isChapterLine(s); }
}

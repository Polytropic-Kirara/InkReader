package com.modu.reader.web;

import java.util.Map;

/** Serialises DOM nodes back to HTML (for rules that ask for "html"). */
public final class Html {
    private Html() {}

    public static String outer(Dom.Node n, boolean dropScripts) {
        StringBuilder sb = new StringBuilder();
        write(n, sb, dropScripts);
        return sb.toString();
    }

    public static String inner(Dom.Node n, boolean dropScripts) {
        StringBuilder sb = new StringBuilder();
        for (Dom.Node c : n.children) write(c, sb, dropScripts);
        return sb.toString();
    }

    private static void write(Dom.Node n, StringBuilder sb, boolean drop) {
        if (n.isText()) {
            boolean raw = n.parent != null && (n.parent.tag.equals("script") || n.parent.tag.equals("style"));
            sb.append(raw ? n.text : esc(n.text));
            return;
        }
        if (n.tag.equals("#root")) { for (Dom.Node c : n.children) write(c, sb, drop); return; }
        if (drop && (n.tag.equals("script") || n.tag.equals("style"))) return;
        sb.append('<').append(n.tag);
        if (n.attrs != null) for (Map.Entry<String, String> a : n.attrs.entrySet())
            sb.append(' ').append(a.getKey()).append("=\"").append(esc(a.getValue()).replace("\"", "&quot;")).append('"');
        sb.append('>');
        if (Dom.VOID.contains(n.tag)) return;
        for (Dom.Node c : n.children) write(c, sb, drop);
        sb.append("</").append(n.tag).append('>');
    }

    private static String esc(String s) {
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;");
    }
}

package com.modu.reader.web;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * A downloaded web novel on disk: meta.txt (key=value), chapters.txt (title TAB url per chapter),
 * toc.txt (the full contents list, when downloading from a contents page) and c/N.txt per chapter.
 */
public final class WebStore {
    public final File dir;
    private final Map<String, String> meta = new LinkedHashMap<String, String>();
    public final List<String[]> chapters = new ArrayList<String[]>();
    public final List<String[]> toc = new ArrayList<String[]>();

    private WebStore(File dir) { this.dir = dir; }

    public static WebStore create(File dir, String title, String author, String startUrl, List<String[]> tocList) throws IOException {
        dir.mkdirs();
        new File(dir, "c").mkdirs();
        WebStore s = new WebStore(dir);
        s.meta.put("title", title);
        s.meta.put("author", author == null ? "" : author);
        s.meta.put("source", startUrl);
        s.meta.put("mode", tocList != null ? "toc" : "chain");
        s.meta.put("next", tocList != null ? "" : startUrl);
        s.meta.put("state", "downloading");
        if (tocList != null) {
            s.toc.addAll(tocList);
            s.writeList("toc.txt", s.toc);
        }
        s.writeList("chapters.txt", s.chapters);
        s.saveMeta();
        return s;
    }

    public static WebStore load(File dir) throws IOException {
        WebStore s = new WebStore(dir);
        for (String line : readLines(new File(dir, "meta.txt"))) {
            int eq = line.indexOf('=');
            if (eq > 0) s.meta.put(line.substring(0, eq), unescape(line.substring(eq + 1)));
        }
        s.readList("chapters.txt", s.chapters);
        s.readList("toc.txt", s.toc);
        return s;
    }

    public synchronized String get(String k) {
        String v = meta.get(k);
        return v == null ? "" : v;
    }

    public synchronized void set(String k, String v) { meta.put(k, v == null ? "" : v); }

    public boolean tocMode() { return "toc".equals(get("mode")); }

    public synchronized void saveMeta() throws IOException {
        StringBuilder sb = new StringBuilder();
        for (Map.Entry<String, String> e : meta.entrySet()) sb.append(e.getKey()).append('=').append(escape(e.getValue())).append('\n');
        write(new File(dir, "meta.txt"), sb.toString());
    }

    public synchronized void appendChapter(String title, String url, List<String> paras) throws IOException {
        int n = chapters.size();
        StringBuilder sb = new StringBuilder();
        sb.append(title).append('\n');
        for (String p : paras) sb.append(p).append('\n');
        write(new File(dir, "c/" + n + ".txt"), sb.toString());
        chapters.add(new String[]{title, url});
        writeList("chapters.txt", chapters);
    }

    /** Forgets downloaded chapters (used when switching to a source that cannot be matched). */
    public synchronized void resetChapters() throws IOException {
        for (int i = 0; i < chapters.size(); i++) new File(dir, "c/" + i + ".txt").delete();
        chapters.clear();
        writeList("chapters.txt", chapters);
    }

    public synchronized void setToc(List<String[]> list) throws IOException {
        toc.clear();
        toc.addAll(list);
        writeList("toc.txt", toc);
    }

    public List<String> chapterLines(int i) throws IOException {
        return readLines(new File(dir, "c/" + i + ".txt"));
    }

    private void writeList(String name, List<String[]> list) throws IOException {
        StringBuilder sb = new StringBuilder();
        for (String[] e : list) sb.append(clean(e[0])).append('\t').append(clean(e[1])).append('\n');
        write(new File(dir, name), sb.toString());
    }

    private void readList(String name, List<String[]> out) throws IOException {
        File f = new File(dir, name);
        if (!f.exists()) return;
        for (String line : readLines(f)) {
            int t = line.indexOf('\t');
            if (t >= 0) out.add(new String[]{line.substring(0, t), line.substring(t + 1)});
        }
    }

    private static String clean(String s) { return s == null ? "" : s.replace('\t', ' ').replace('\n', ' ').replace('\r', ' '); }
    private static String escape(String s) { return s.replace("\\", "\\\\").replace("\n", "\\n"); }
    private static String unescape(String s) { return s.replace("\\n", "\n").replace("\\\\", "\\"); }

    private static void write(File f, String s) throws IOException {
        File tmp = new File(f.getPath() + ".tmp");
        Writer w = new OutputStreamWriter(new FileOutputStream(tmp), "UTF-8");
        try { w.write(s); } finally { w.close(); }
        if (!tmp.renameTo(f)) { f.delete(); if (!tmp.renameTo(f)) throw new IOException("写入失败：" + f.getName()); }
    }

    static List<String> readLines(File f) throws IOException {
        List<String> out = new ArrayList<String>();
        if (!f.exists()) return out;
        BufferedReader r = new BufferedReader(new InputStreamReader(new FileInputStream(f), "UTF-8"));
        try {
            String l;
            while ((l = r.readLine()) != null) out.add(l);
        } finally {
            r.close();
        }
        return out;
    }
}

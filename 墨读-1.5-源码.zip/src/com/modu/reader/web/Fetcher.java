package com.modu.reader.web;

import com.modu.reader.core.Util;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.Charset;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.GZIPInputStream;

/** HTTP page fetcher with charset detection (many Chinese sites still serve GBK), cookies and retries. */
public class Fetcher implements Source {
    public interface Cookies {
        String get(String url);
        void set(String url, List<String> setCookie);
    }

    public String userAgent = "Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Mobile Safari/537.36";
    public Cookies cookies;
    public volatile String userAgentOverride;
    public int timeoutMs = 15000;
    public int attempts = 3;

    private static final Pattern META_CS = Pattern.compile("(?i)<meta[^>]+charset\\s*=\\s*[\"']?\\s*([a-z0-9_\\-]+)");

    @Override public Page get(String url, String referer) throws IOException {
        return request(url, referer, null, null, null);
    }

    public Page post(String url, String referer, String body, String charset) throws IOException {
        return request(url, referer, body, charset, null);
    }

    /** Full request: POST when body is non-null; charset also forces how the response is decoded. */
    public Page request(String url, String referer, String body, String charset, Map<String, String> headers) throws IOException {
        IOException last = null;
        for (int attempt = 0; attempt < Math.max(1, attempts); attempt++) {
            try {
                return once(url, referer, body, charset, headers);
            } catch (IOException e) {
                last = e;
                if (attempt + 1 >= attempts) break;
                try { Thread.sleep(800L * (attempt + 1)); } catch (InterruptedException ie) { throw e; }
            }
        }
        throw last;
    }

    private Page once(String url, String referer, String body, String bodyCharset, Map<String, String> headers) throws IOException {
        String cur = url;
        for (int hop = 0; hop < 6; hop++) {
            HttpURLConnection c = (HttpURLConnection) new URL(cur).openConnection();
            c.setInstanceFollowRedirects(false);
            c.setConnectTimeout(timeoutMs);
            c.setReadTimeout(timeoutMs);
            c.setRequestProperty("User-Agent", userAgentOverride != null ? userAgentOverride : userAgent);
            c.setRequestProperty("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8");
            c.setRequestProperty("Accept-Language", "zh-CN,zh;q=0.9,en;q=0.6");
            c.setRequestProperty("Accept-Encoding", "gzip");
            if (referer != null) c.setRequestProperty("Referer", referer);
            if (headers != null) for (Map.Entry<String, String> h : headers.entrySet()) c.setRequestProperty(h.getKey(), h.getValue());
            if (cookies != null) {
                String ck = cookies.get(cur);
                if (ck != null && ck.length() > 0) c.setRequestProperty("Cookie", ck);
            }
            if (body != null) {
                c.setDoOutput(true);
                c.setRequestMethod("POST");
                c.setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=" + (bodyCharset == null ? "UTF-8" : bodyCharset));
                OutputStream os = c.getOutputStream();
                os.write(body.getBytes(bodyCharset == null ? "UTF-8" : bodyCharset));
                os.close();
            }
            int code = c.getResponseCode();
            if (cookies != null) {
                Map<String, List<String>> h = c.getHeaderFields();
                for (Map.Entry<String, List<String>> e : h.entrySet()) {
                    if (e.getKey() != null && e.getKey().equalsIgnoreCase("Set-Cookie")) cookies.set(cur, e.getValue());
                }
            }
            if (code >= 300 && code < 400 && c.getHeaderField("Location") != null) {
                String loc = Extractor.resolve(cur, c.getHeaderField("Location"));
                c.disconnect();
                if (loc == null) throw new IOException("无效的跳转");
                cur = loc;
                body = null; // redirected POST becomes GET
                continue;
            }
            if (code >= 400) {
                c.disconnect();
                throw new IOException("网页返回错误 " + code);
            }
            InputStream in = c.getInputStream();
            if ("gzip".equalsIgnoreCase(c.getContentEncoding())) in = new GZIPInputStream(in);
            byte[] data = readLimited(in, 8 * 1024 * 1024);
            String ct = c.getContentType();
            c.disconnect();
            if (bodyCharset != null && bodyCharset.length() > 0) ct = "text/html; charset=" + bodyCharset;
            return new Page(cur, decode(data, ct));
        }
        throw new IOException("跳转次数过多");
    }

    private static byte[] readLimited(InputStream in, int max) throws IOException {
        try {
            ByteArrayOutputStream out = new ByteArrayOutputStream(64 * 1024);
            byte[] buf = new byte[32 * 1024];
            int n, total = 0;
            while ((n = in.read(buf)) > 0) {
                out.write(buf, 0, n);
                total += n;
                if (total > max) break;
            }
            return out.toByteArray();
        } finally {
            in.close();
        }
    }

    /** Raw bytes of a URL (covers). */
    public byte[] bytes(String url, String referer) throws IOException {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        c.setConnectTimeout(timeoutMs);
        c.setReadTimeout(timeoutMs);
        c.setInstanceFollowRedirects(true);
        c.setRequestProperty("User-Agent", userAgent);
        if (referer != null) c.setRequestProperty("Referer", referer);
        if (c.getResponseCode() >= 400) { c.disconnect(); throw new IOException("HTTP " + c.getResponseCode()); }
        byte[] b = readLimited(c.getInputStream(), 6 * 1024 * 1024);
        c.disconnect();
        return b;
    }

    public static String decode(byte[] data, String contentType) {
        String cs = null;
        if (contentType != null) {
            Matcher m = Pattern.compile("(?i)charset\\s*=\\s*\"?([a-z0-9_\\-]+)").matcher(contentType);
            if (m.find()) cs = m.group(1);
        }
        if (cs == null) {
            String head = new String(data, 0, Math.min(data.length, 4096), Charset.forName("ISO-8859-1"));
            Matcher m = META_CS.matcher(head);
            if (m.find()) cs = m.group(1);
        }
        if (cs == null) cs = Util.isUtf8(data, data.length) ? "UTF-8" : "GB18030";
        String low = cs.toLowerCase();
        if (low.equals("gbk") || low.equals("gb2312") || low.equals("gb_2312-80") || low.equals("x-gbk")) cs = "GB18030";
        try {
            return new String(data, Charset.forName(cs));
        } catch (Exception e) {
            return new String(data, Charset.forName("UTF-8"));
        }
    }
}

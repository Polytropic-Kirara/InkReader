package com.modu.reader.web;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Evaluates book-source rules in the "阅读 / Legado" syntax (the parts that need no JavaScript):
 * default rules ({@code class.x.0@tag.a@href}), {@code @css:}, JSONPath ({@code $.a[*]} / {@code @json:}),
 * simple XPath ({@code //div[@id='x']/a/@href}), {@code && || %%} combinations, {@code ##regex##replace}
 * purification and {@code {{...}}} templates.
 */
public final class Rules {
    private Rules() {}

    /** Parses a response body into a DOM tree or a JSON value. */
    public static Object parseBody(String body) {
        String t = body.trim();
        if ((t.startsWith("{") && t.endsWith("}")) || (t.startsWith("[") && t.endsWith("]"))) {
            try { return Json.parse(t); } catch (Exception ignored) {}
        }
        return Dom.parse(body);
    }

    public static boolean usesJs(String rule) {
        return rule != null && (rule.contains("<js>") || rule.contains("@js:") || rule.contains("java.") || rule.contains("{{js"));
    }

    private static final Pattern JS_BLOCK = Pattern.compile("(?s)<js>.*?</js>|@js:.*$");

    private static String stripJs(String rule) {
        return JS_BLOCK.matcher(rule).replaceAll("").trim();
    }

    // ---- public API --------------------------------------------------------------------

    public static List<Object> elements(Object node, String rule) {
        List<Object> out = new ArrayList<Object>();
        if (rule == null) return out;
        rule = rule.trim();
        if (hasJs(rule) && Js.available()) {
            try { return jsElements(node, rule); } catch (Exception e) { return out; }
        }
        rule = stripJs(rule);
        if (rule.length() == 0) return out;
        String[] comb = combinator(rule);
        if (comb != null) {
            List<List<Object>> parts = new ArrayList<List<Object>>();
            for (String p : splitOn(rule, comb[0])) parts.add(elements(node, p));
            if (comb[0].equals("||")) { for (List<Object> l : parts) if (!l.isEmpty()) return l; return out; }
            if (comb[0].equals("&&")) { for (List<Object> l : parts) out.addAll(l); return out; }
            int max = 0;
            for (List<Object> l : parts) max = Math.max(max, l.size());
            for (int i = 0; i < max; i++) for (List<Object> l : parts) if (i < l.size()) out.add(l.get(i));
            return out;
        }
        int purify = rule.indexOf("##");
        if (purify >= 0) rule = rule.substring(0, purify);
        return single(node, rule, false);
    }

    public static String string(Object node, String rule, String baseUrl, boolean url) {
        List<String> l = strings(node, rule, baseUrl, url);
        if (l.isEmpty()) return "";
        if (url) return l.get(0);
        StringBuilder sb = new StringBuilder();
        for (String s : l) { if (sb.length() > 0) sb.append('\n'); sb.append(s); }
        return sb.toString().trim();
    }

    public static List<String> strings(Object node, String rule, String baseUrl, boolean url) {
        List<String> out = new ArrayList<String>();
        if (rule == null) return out;
        rule = rule.trim();
        if (rule.length() == 0) return out;
        rule = rule.replaceAll("@put:\\{[^}]*\\}", "");
        if (hasJs(rule) && Js.available()) {
            try { return jsStrings(node, rule, baseUrl, url); } catch (Exception e) { return out; }
        }
        boolean hadJs = rule.contains("<js>") || rule.startsWith("@js:");
        rule = stripJs(rule);
        if (rule.length() == 0) { if (hadJs) return out; return out; }

        // purification suffix: ##regex##replacement(###)
        String regex = null, repl = "";
        boolean firstOnly = false;
        int purify = indexTop(rule, "##");
        if (purify >= 0) {
            String tail = rule.substring(purify + 2);
            rule = rule.substring(0, purify);
            if (tail.endsWith("###")) { firstOnly = true; tail = tail.substring(0, tail.length() - 3); }
            int sep = tail.indexOf("##");
            if (sep >= 0) { regex = tail.substring(0, sep); repl = tail.substring(sep + 2); }
            else regex = tail;
        }

        if (rule.contains("{{") && !rule.startsWith("$") && !rule.startsWith("@json:")) {
            out.add(template(node, rule, baseUrl));
        } else if (rule.length() == 0) {
            out.add(node instanceof Dom.Node ? ((Dom.Node) node).ownText() : Json.text(node));
        } else {
            String[] comb = combinator(rule);
            if (comb != null) {
                List<List<String>> parts = new ArrayList<List<String>>();
                for (String p : splitOn(rule, comb[0])) parts.add(strings(node, p, baseUrl, false));
                if (comb[0].equals("||")) { for (List<String> l : parts) if (!joinedEmpty(l)) { out.addAll(l); break; } }
                else if (comb[0].equals("&&")) { for (List<String> l : parts) out.addAll(l); }
                else {
                    int max = 0;
                    for (List<String> l : parts) max = Math.max(max, l.size());
                    for (int i = 0; i < max; i++) for (List<String> l : parts) if (i < l.size()) out.add(l.get(i));
                }
            } else {
                for (Object o : single(node, rule, true)) out.add(o instanceof String ? (String) o : Json.text(o));
            }
        }
        List<String> fin = new ArrayList<String>();
        for (String s : out) {
            if (regex != null && regex.length() > 0) {
                try {
                    Matcher m = Pattern.compile(regex).matcher(s);
                    s = firstOnly ? (m.find() ? m.group().replaceAll(regex, repl) : "") : m.replaceAll(repl);
                } catch (Exception e) {
                    s = s.replace(regex, repl);
                }
            }
            if (url) {
                String r = Extractor.resolve(baseUrl == null ? "" : baseUrl, s.trim());
                if (r != null) fin.add(r);
            } else fin.add(s);
        }
        return fin;
    }

    private static boolean joinedEmpty(List<String> l) {
        for (String s : l) if (s.trim().length() > 0) return false;
        return true;
    }

    // ---- templates ---------------------------------------------------------------------

    private static String template(Object node, String rule, String baseUrl) {
        StringBuilder sb = new StringBuilder();
        int i = 0;
        while (i < rule.length()) {
            int a = rule.indexOf("{{", i);
            if (a < 0) { sb.append(rule.substring(i)); break; }
            sb.append(rule, i, a);
            int b = rule.indexOf("}}", a + 2);
            if (b < 0) { sb.append(rule.substring(a)); break; }
            String inner = rule.substring(a + 2, b).trim();
            if (Js.available() && !looksLikeRule(inner)) {
                try { sb.append(Json.text(Js.run(inner, jsValue(node), baseUrl))); } catch (Exception e) { /* leave empty */ }
            } else {
                sb.append(string(node, inner, baseUrl, false));
            }
            i = b + 2;
        }
        return sb.toString();
    }

    // ---- JavaScript pipeline ---------------------------------------------------------

    static boolean hasJs(String rule) {
        return rule.contains("<js>") || rule.contains("@js:");
    }

    static boolean looksLikeRule(String s) {
        return s.startsWith("@") || s.startsWith("$.") || s.startsWith("$[") || s.startsWith("//") || s.startsWith("class.")
                || s.startsWith("id.") || s.startsWith("tag.") || s.startsWith("text.") || s.startsWith("children");
    }

    /** Splits a rule into plain-rule and JavaScript parts, in order. */
    static List<String[]> splitJs(String rule) {
        List<String[]> out = new ArrayList<String[]>();
        int i = 0;
        while (i < rule.length()) {
            int a = rule.indexOf("<js>", i), b = rule.indexOf("@js:", i);
            if (b >= 0 && (a < 0 || b < a)) {
                if (b > i) out.add(new String[]{"r", rule.substring(i, b)});
                out.add(new String[]{"j", rule.substring(b + 4)});
                break;
            }
            if (a >= 0) {
                if (a > i) out.add(new String[]{"r", rule.substring(i, a)});
                int e = rule.indexOf("</js>", a);
                if (e < 0) e = rule.length();
                out.add(new String[]{"j", rule.substring(a + 4, e)});
                i = Math.min(rule.length(), e + 5);
                continue;
            }
            out.add(new String[]{"r", rule.substring(i)});
            break;
        }
        return out;
    }

    /** What a script sees as {@code result}: text for pages and strings, JSON as-is, a list as a list. */
    static Object jsValue(Object v) {
        if (v instanceof Dom.Node) return Html.outer((Dom.Node) v, false);
        if (v instanceof List) {
            List<Object> l = new ArrayList<Object>();
            for (Object o : (List<?>) v) l.add(o instanceof Dom.Node ? Html.outer((Dom.Node) o, false) : o);
            return l;
        }
        return v;
    }

    static Object toNode(Object v) {
        if (v instanceof String) {
            String t = ((String) v).trim();
            if (t.startsWith("<")) return Dom.parse(t);
            if (t.startsWith("{") || t.startsWith("[")) { try { return Json.parse(t); } catch (Exception ignored) {} }
            return v;
        }
        return v;
    }

    private static List<String> jsStrings(Object node, String rule, String baseUrl, boolean url) throws Exception {
        Object value = node;
        boolean started = false;
        for (String[] part : splitJs(rule)) {
            String t = part[1].trim();
            if (t.length() == 0) continue;
            if (part[0].equals("r")) {
                Object base = started ? toNode(value instanceof List ? join((List<?>) value) : value) : node;
                value = string(base, t, baseUrl, false);
            } else {
                value = Js.run(t, jsValue(value), baseUrl);
            }
            started = true;
        }
        List<String> out = new ArrayList<String>();
        if (value instanceof List) { for (Object o : (List<?>) value) out.add(Json.text(o)); }
        else if (value != null && !(value instanceof Dom.Node)) out.add(Json.text(value));
        if (!url) return out;
        List<String> fin = new ArrayList<String>();
        for (String s : out) { String r = Extractor.resolve(baseUrl == null ? "" : baseUrl, s.trim()); if (r != null) fin.add(r); }
        return fin;
    }

    private static String join(List<?> l) {
        StringBuilder sb = new StringBuilder();
        for (Object o : l) { if (sb.length() > 0) sb.append('\n'); sb.append(Json.text(o)); }
        return sb.toString();
    }

    private static List<Object> jsElements(Object node, String rule) throws Exception {
        Object value = node;
        boolean started = false;
        for (String[] part : splitJs(rule)) {
            String t = part[1].trim();
            if (t.length() == 0) continue;
            if (part[0].equals("r")) {
                Object base = started ? (value instanceof List ? value : toNode(value)) : node;
                if (base instanceof List && !(base instanceof Dom.Node)) {
                    List<Object> acc = new ArrayList<Object>();
                    for (Object o : (List<?>) base) acc.addAll(elements(toNode(o), t));
                    value = acc;
                } else value = elements(base, t);
            } else {
                value = Js.run(t, jsValue(value), "");
            }
            started = true;
        }
        List<Object> out = new ArrayList<Object>();
        if (value instanceof List) { for (Object o : (List<?>) value) out.add(toNode(o)); }
        else if (value != null) {
            Object n = toNode(value);
            if (n instanceof List) out.addAll((List<?>) n); else out.add(n);
        }
        return out;
    }

    // ---- dispatch ----------------------------------------------------------------------

    private static String[] combinator(String rule) {
        for (String c : new String[]{"||", "&&", "%%"}) if (indexTop(rule, c) >= 0) return new String[]{c};
        return null;
    }

    /** Index of {@code token} outside brackets, parentheses and quotes. */
    static int indexTop(String s, String token) {
        int depth = 0;
        char q = 0;
        for (int i = 0; i + token.length() <= s.length(); i++) {
            char c = s.charAt(i);
            if (q != 0) { if (c == q) q = 0; continue; }
            if (c == '\'' || c == '"') { q = c; continue; }
            if (c == '[' || c == '(') depth++;
            else if (c == ']' || c == ')') depth--;
            if (depth == 0 && s.startsWith(token, i)) return i;
        }
        return -1;
    }

    private static List<String> splitOn(String s, String token) {
        List<String> out = new ArrayList<String>();
        int i;
        while ((i = indexTop(s, token)) >= 0) {
            out.add(s.substring(0, i));
            s = s.substring(i + token.length());
        }
        out.add(s);
        return out;
    }

    private static List<Object> single(Object node, String rule, boolean wantString) {
        String r = rule.trim();
        boolean json = node instanceof java.util.Map || node instanceof List || (node instanceof String && !(node instanceof Dom.Node));
        if (r.startsWith("@json:")) return jsonPath(node, r.substring(6), wantString);
        if (r.startsWith("$.") || r.startsWith("$[") || r.equals("$")) return jsonPath(node, r, wantString);
        if (json) {
            // bare keys on JSON nodes behave like JSONPath
            return jsonPath(node, r.startsWith("$") ? r : "$." + r, wantString);
        }
        Dom.Node dn = (Dom.Node) node;
        if (r.startsWith("@css:")) return css(dn, r.substring(5), wantString);
        if (r.startsWith("@XPath:") || r.startsWith("@xpath:")) return xpath(dn, r.substring(7), wantString);
        if (r.startsWith("//") || r.startsWith("./")) return xpath(dn, r, wantString);
        if (r.startsWith("@@")) r = r.substring(2);
        return legacy(dn, r, wantString);
    }

    // ---- JSON --------------------------------------------------------------------------

    private static List<Object> jsonPath(Object node, String expr, boolean wantString) {
        Object root = node;
        if (node instanceof String) {
            try { root = Json.parse((String) node); } catch (Exception e) { return new ArrayList<Object>(); }
        }
        List<Object> r = Json.path(root, expr);
        if (!wantString && r.size() == 1 && r.get(0) instanceof List) return new ArrayList<Object>((List<?>) r.get(0));
        if (wantString) {
            List<Object> s = new ArrayList<Object>();
            for (Object o : r) {
                if (o instanceof List) for (Object x : (List<?>) o) s.add(Json.text(x));
                else s.add(Json.text(o));
            }
            return s;
        }
        return r;
    }

    // ---- CSS ---------------------------------------------------------------------------

    private static List<Object> css(Dom.Node node, String rule, boolean wantString) {
        String sel = rule, getter = null;
        if (wantString) {
            int at = lastTopAt(rule);
            if (at >= 0) { sel = rule.substring(0, at); getter = rule.substring(at + 1); }
            else getter = "text";
        }
        List<Dom.Node> els = sel.trim().length() == 0 ? one(node) : Css.select(node, sel.trim());
        return wantString ? get(els, getter) : new ArrayList<Object>(els);
    }

    private static List<Dom.Node> one(Dom.Node n) {
        List<Dom.Node> l = new ArrayList<Dom.Node>();
        l.add(n);
        return l;
    }

    private static int lastTopAt(String s) {
        int depth = 0, last = -1;
        char q = 0;
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (q != 0) { if (c == q) q = 0; continue; }
            if (c == '\'' || c == '"') q = c;
            else if (c == '[' || c == '(') depth++;
            else if (c == ']' || c == ')') depth--;
            else if (c == '@' && depth == 0) last = i;
        }
        return last;
    }

    // ---- default (JSoup-style) rules ---------------------------------------------------

    private static List<Object> legacy(Dom.Node node, String rule, boolean wantString) {
        List<String> segs = new ArrayList<String>();
        int depth = 0, start = 0;
        char q = 0;
        for (int i = 0; i < rule.length(); i++) {
            char c = rule.charAt(i);
            if (q != 0) { if (c == q) q = 0; continue; }
            if (c == '\'' || c == '"') q = c;
            else if (c == '[' || c == '(') depth++;
            else if (c == ']' || c == ')') depth--;
            else if (c == '@' && depth == 0) { segs.add(rule.substring(start, i)); start = i + 1; }
        }
        segs.add(rule.substring(start));
        String getter = null;
        if (wantString) {
            getter = segs.remove(segs.size() - 1);
            if (segs.isEmpty() && !isGetter(getter)) { segs.add(getter); getter = "text"; }
        }
        List<Dom.Node> cur = one(node);
        for (String seg : segs) {
            seg = seg.trim();
            if (seg.length() == 0) continue;
            List<Dom.Node> next = new ArrayList<Dom.Node>();
            for (Dom.Node n : cur) next.addAll(segment(n, seg));
            cur = next;
            if (cur.isEmpty()) break;
        }
        return wantString ? get(cur, getter) : new ArrayList<Object>(cur);
    }

    private static boolean isGetter(String g) {
        return g.equals("text") || g.equals("textNodes") || g.equals("ownText") || g.equals("html") || g.equals("all")
                || g.equals("href") || g.equals("src") || g.equals("content") || g.equals("value") || g.equals("title")
                || g.equals("alt") || g.startsWith("data-");
    }

    private static final Pattern INDEX_BRACKET = Pattern.compile("^(.*?)\\[(!?)([-0-9:,\\s]+)\\]$");

    private static List<Dom.Node> segment(Dom.Node n, String seg) {
        // index forms: name.0  name.-1  name!0  name[0,2]  name[1:3]  name[!0]
        String body = seg;
        String idx = null;
        boolean exclude = false;
        Matcher bm = INDEX_BRACKET.matcher(seg);
        if (bm.matches() && !seg.startsWith("[")) {
            body = bm.group(1);
            exclude = bm.group(2).length() > 0;
            idx = bm.group(3);
        } else {
            int bang = seg.lastIndexOf('!');
            if (bang > 0 && seg.substring(bang + 1).matches("[-0-9:]+")) {
                body = seg.substring(0, bang);
                idx = seg.substring(bang + 1).replace(':', ',');
                exclude = true;
            } else {
                Matcher dm = Pattern.compile("^(class|id|tag|text)\\.(.+?)\\.(-?\\d+(?::-?\\d+)*)$").matcher(seg);
                if (dm.matches()) { body = dm.group(1) + "." + dm.group(2); idx = dm.group(3).replace(':', ','); }
            }
        }
        List<Dom.Node> found;
        if (body.equals("children")) {
            found = n.elements();
        } else {
            int dot = body.indexOf('.');
            String type = dot > 0 ? body.substring(0, dot) : "";
            String name = dot > 0 ? body.substring(dot + 1) : "";
            if (type.equals("class")) found = Css.select(n, "." + name.trim().replace(" ", "."));
            else if (type.equals("id")) found = Css.select(n, "#" + name.trim());
            else if (type.equals("tag")) found = Css.select(n, name.trim());
            else if (type.equals("text")) {
                found = new ArrayList<Dom.Node>();
                for (Dom.Node e : Css.select(n, "*")) {
                    for (Dom.Node k : e.children) if (k.isText() && k.text.contains(name)) { found.add(e); break; }
                }
            } else found = Css.select(n, body);
            // a class/id/tag search starting at n itself excludes n
            found.remove(n);
        }
        if (idx == null) return found;
        return pickIndex(found, idx, exclude);
    }

    private static List<Dom.Node> pickIndex(List<Dom.Node> l, String spec, boolean exclude) {
        int n = l.size();
        List<Integer> picks = new ArrayList<Integer>();
        for (String part : spec.split(",")) {
            part = part.trim();
            if (part.length() == 0) continue;
            if (part.contains(":")) {
                String[] p = part.split(":", -1);
                int a = p[0].length() == 0 ? 0 : Integer.parseInt(p[0].trim());
                int b = p[1].length() == 0 ? n - 1 : Integer.parseInt(p[1].trim());
                if (a < 0) a += n;
                if (b < 0) b += n;
                for (int k = a; k <= b; k++) picks.add(k);
            } else {
                int k = Integer.parseInt(part);
                if (k < 0) k += n;
                picks.add(k);
            }
        }
        List<Dom.Node> out = new ArrayList<Dom.Node>();
        if (exclude) {
            for (int k = 0; k < n; k++) if (!picks.contains(k)) out.add(l.get(k));
        } else {
            for (int k : picks) if (k >= 0 && k < n) out.add(l.get(k));
        }
        return out;
    }

    private static List<Object> get(List<Dom.Node> els, String getter) {
        List<Object> out = new ArrayList<Object>();
        if (getter == null) getter = "text";
        getter = getter.trim();
        for (Dom.Node e : els) {
            String v;
            if (getter.equals("text")) v = e.ownText();
            else if (getter.equals("textNodes")) {
                StringBuilder sb = new StringBuilder();
                for (Dom.Node k : e.children) if (k.isText() && k.text.trim().length() > 0) { if (sb.length() > 0) sb.append('\n'); sb.append(k.text.trim()); }
                v = sb.toString();
            } else if (getter.equals("ownText")) {
                StringBuilder sb = new StringBuilder();
                for (Dom.Node k : e.children) if (k.isText()) sb.append(k.text);
                v = sb.toString().replaceAll("\\s+", " ").trim();
            } else if (getter.equals("html") || getter.equals("all")) {
                v = Html.outer(e, getter.equals("html"));
            } else {
                v = e.attr(getter.toLowerCase());
                if (v == null) continue;
            }
            out.add(v);
        }
        return out;
    }

    // ---- XPath (common subset) ---------------------------------------------------------

    private static List<Object> xpath(Dom.Node node, String expr, boolean wantString) {
        String e = expr.trim();
        String getter = null;
        Matcher m = Pattern.compile("/(text\\(\\)|@[\\w:-]+)$").matcher(e);
        if (m.find()) {
            String g = m.group(1);
            getter = g.equals("text()") ? "text" : g.substring(1);
            e = e.substring(0, m.start());
        }
        List<Dom.Node> cur = one(node);
        int i = 0;
        if (e.startsWith(".")) i = 1;
        while (i < e.length()) {
            boolean deep = e.startsWith("//", i);
            i += deep ? 2 : 1;
            int j = i, depth = 0;
            while (j < e.length()) {
                char c = e.charAt(j);
                if (c == '[') depth++;
                else if (c == ']') depth--;
                else if (c == '/' && depth == 0) break;
                j++;
            }
            String step = e.substring(i, j);
            i = j;
            String tag = step, preds = "";
            int br = step.indexOf('[');
            if (br >= 0) { tag = step.substring(0, br); preds = step.substring(br); }
            List<Dom.Node> next = new ArrayList<Dom.Node>();
            for (Dom.Node n : cur) {
                List<Dom.Node> cand = new ArrayList<Dom.Node>();
                if (deep) { for (Dom.Node d : Css.select(n, tag.equals("*") || tag.length() == 0 ? "*" : tag)) if (d != n) cand.add(d); }
                else for (Dom.Node c : n.elements()) if (tag.equals("*") || c.tag.equals(tag)) cand.add(c);
                next.addAll(applyPreds(cand, preds));
            }
            cur = next;
        }
        if (!wantString) return new ArrayList<Object>(cur);
        return get(cur, getter == null ? "text" : getter);
    }

    private static List<Dom.Node> applyPreds(List<Dom.Node> cand, String preds) {
        Matcher pm = Pattern.compile("\\[([^\\]]+)\\]").matcher(preds);
        List<Dom.Node> cur = cand;
        while (pm.find()) {
            String p = pm.group(1).trim();
            List<Dom.Node> next = new ArrayList<Dom.Node>();
            if (p.matches("-?\\d+")) {
                int k = Integer.parseInt(p) - 1;
                if (k >= 0 && k < cur.size()) next.add(cur.get(k));
            } else if (p.equals("last()")) {
                if (!cur.isEmpty()) next.add(cur.get(cur.size() - 1));
            } else {
                Matcher eq = Pattern.compile("^@([\\w:-]+)\\s*=\\s*['\"](.*)['\"]$").matcher(p);
                Matcher has = Pattern.compile("^@([\\w:-]+)$").matcher(p);
                Matcher con = Pattern.compile("^contains\\(\\s*@([\\w:-]+)\\s*,\\s*['\"](.*)['\"]\\s*\\)$").matcher(p);
                Matcher txt = Pattern.compile("^contains\\(\\s*text\\(\\)\\s*,\\s*['\"](.*)['\"]\\s*\\)$").matcher(p);
                for (Dom.Node n : cur) {
                    if (eq.matches()) { String v = n.attr(eq.group(1)); if (v != null && v.equals(eq.group(2))) next.add(n); }
                    else if (has.matches()) { if (n.attr(has.group(1)) != null) next.add(n); }
                    else if (con.matches()) { String v = n.attr(con.group(1)); if (v != null && v.contains(con.group(2))) next.add(n); }
                    else if (txt.matches()) { if (n.ownText().contains(txt.group(1))) next.add(n); }
                }
            }
            cur = next;
        }
        return cur;
    }
}

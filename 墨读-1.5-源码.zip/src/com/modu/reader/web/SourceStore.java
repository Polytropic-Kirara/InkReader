package com.modu.reader.web;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.util.ArrayList;
import java.util.List;

/** The user's imported book sources, kept as one JSON file in the Legado export format. */
public final class SourceStore {
    private SourceStore() {}

    public static synchronized List<BookSource> load(File f) {
        if (!f.exists()) return new ArrayList<BookSource>();
        try {
            FileInputStream in = new FileInputStream(f);
            byte[] b = com.modu.reader.core.Util.readAll(in);
            return BookSource.parseAll(new String(b, "UTF-8"));
        } catch (Exception e) {
            return new ArrayList<BookSource>();
        }
    }

    public static synchronized void save(File f, List<BookSource> list) throws IOException {
        File tmp = new File(f.getPath() + ".tmp");
        Writer w = new OutputStreamWriter(new FileOutputStream(tmp), "UTF-8");
        try { w.write(BookSource.writeAll(list)); } finally { w.close(); }
        if (!tmp.renameTo(f)) { f.delete(); tmp.renameTo(f); }
    }

    /** Adds or replaces (same bookSourceUrl) sources. Returns {added, replaced}. */
    public static int[] merge(List<BookSource> into, List<BookSource> incoming) {
        int added = 0, replaced = 0;
        for (BookSource s : incoming) {
            int idx = -1;
            for (int i = 0; i < into.size(); i++) if (into.get(i).url.equals(s.url)) { idx = i; break; }
            if (idx >= 0) { into.set(idx, s); replaced++; } else { into.add(s); added++; }
        }
        return new int[]{added, replaced};
    }

    public static BookSource find(List<BookSource> list, String url) {
        for (BookSource s : list) if (s.url.equals(url)) return s;
        return null;
    }
}

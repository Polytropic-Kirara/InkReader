package com.modu.reader.web;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Minimal JSON reader/writer (maps, lists, strings, numbers, booleans, null) plus a JSONPath subset. */
public final class Json {
    private Json() {}

    public static Object parse(String s) {
        P p = new P(s);
        p.ws();
        Object v = p.value();
        return v;
    }

    private static final class P {
        final String s;
        int i;

        P(String s) { this.s = s; }

        void ws() {
            while (i < s.length()) {
                char c = s.charAt(i);
                if (c == ' ' || c == '\n' || c == '\r' || c == '\t' || c == '﻿') i++;
                else if (c == '/' && i + 1 < s.length() && s.charAt(i + 1) == '/') { while (i < s.length() && s.charAt(i) != '\n') i++; }
                else break;
            }
        }

        Object value() {
            ws();
            if (i >= s.length()) throw new IllegalArgumentException("JSON 不完整");
            char c = s.charAt(i);
            if (c == '{') return obj();
            if (c == '[') return arr();
            if (c == '"' || c == '\'') return str();
            if (s.startsWith("true", i)) { i += 4; return Boolean.TRUE; }
            if (s.startsWith("false", i)) { i += 5; return Boolean.FALSE; }
            if (s.startsWith("null", i)) { i += 4; return null; }
            return num();
        }

        Map<String, Object> obj() {
            Map<String, Object> m = new LinkedHashMap<String, Object>();
            i++;
            ws();
            if (i < s.length() && s.charAt(i) == '}') { i++; return m; }
            while (i < s.length()) {
                ws();
                String k = str();
                ws();
                if (i < s.length() && s.charAt(i) == ':') i++;
                Object v = value();
                m.put(k, v);
                ws();
                if (i < s.length() && s.charAt(i) == ',') { i++; ws(); if (i < s.length() && s.charAt(i) == '}') { i++; return m; } continue; }
                if (i < s.length() && s.charAt(i) == '}') { i++; return m; }
                throw new IllegalArgumentException("JSON 格式错误，位置 " + i);
            }
            return m;
        }

        List<Object> arr() {
            List<Object> l = new ArrayList<Object>();
            i++;
            ws();
            if (i < s.length() && s.charAt(i) == ']') { i++; return l; }
            while (i < s.length()) {
                l.add(value());
                ws();
                if (i < s.length() && s.charAt(i) == ',') { i++; ws(); if (i < s.length() && s.charAt(i) == ']') { i++; return l; } continue; }
                if (i < s.length() && s.charAt(i) == ']') { i++; return l; }
                throw new IllegalArgumentException("JSON 格式错误，位置 " + i);
            }
            return l;
        }

        String str() {
            char q = s.charAt(i);
            if (q != '"' && q != '\'') { // unquoted key
                int a = i;
                while (i < s.length() && (Character.isLetterOrDigit(s.charAt(i)) || s.charAt(i) == '_' || s.charAt(i) == '$')) i++;
                return s.substring(a, i);
            }
            i++;
            StringBuilder sb = new StringBuilder();
            while (i < s.length()) {
                char c = s.charAt(i++);
                if (c == q) return sb.toString();
                if (c == '\\' && i < s.length()) {
                    char e = s.charAt(i++);
                    switch (e) {
                        case 'n': sb.append('\n'); break;
                        case 't': sb.append('\t'); break;
                        case 'r': sb.append('\r'); break;
                        case 'b': sb.append('\b'); break;
                        case 'f': sb.append('\f'); break;
                        case 'u':
                            if (i + 4 <= s.length()) { sb.append((char) Integer.parseInt(s.substring(i, i + 4), 16)); i += 4; }
                            break;
                        default: sb.append(e);
                    }
                } else sb.append(c);
            }
            return sb.toString();
        }

        Object num() {
            int a = i;
            while (i < s.length() && "+-0123456789.eE".indexOf(s.charAt(i)) >= 0) i++;
            String t = s.substring(a, i);
            if (t.length() == 0) throw new IllegalArgumentException("JSON 格式错误，位置 " + i);
            try {
                if (t.contains(".") || t.contains("e") || t.contains("E")) return Double.parseDouble(t);
                return Long.parseLong(t);
            } catch (NumberFormatException e) {
                return Double.parseDouble(t);
            }
        }
    }

    // ---- writing -----------------------------------------------------------------------

    public static String write(Object v) {
        StringBuilder sb = new StringBuilder();
        write(v, sb);
        return sb.toString();
    }

    @SuppressWarnings("unchecked")
    private static void write(Object v, StringBuilder sb) {
        if (v == null) sb.append("null");
        else if (v instanceof String) quote((String) v, sb);
        else if (v instanceof Map) {
            sb.append('{');
            boolean first = true;
            for (Map.Entry<String, Object> e : ((Map<String, Object>) v).entrySet()) {
                if (!first) sb.append(',');
                first = false;
                quote(e.getKey(), sb);
                sb.append(':');
                write(e.getValue(), sb);
            }
            sb.append('}');
        } else if (v instanceof List) {
            sb.append('[');
            boolean first = true;
            for (Object o : (List<Object>) v) {
                if (!first) sb.append(',');
                first = false;
                write(o, sb);
            }
            sb.append(']');
        } else sb.append(String.valueOf(v));
    }

    private static void quote(String s, StringBuilder sb) {
        sb.append('"');
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            switch (c) {
                case '"': sb.append("\\\""); break;
                case '\\': sb.append("\\\\"); break;
                case '\n': sb.append("\\n"); break;
                case '\r': sb.append("\\r"); break;
                case '\t': sb.append("\\t"); break;
                default:
                    if (c < 0x20) sb.append(String.format("\\u%04x", (int) c));
                    else sb.append(c);
            }
        }
        sb.append('"');
    }

    // ---- helpers -----------------------------------------------------------------------

    @SuppressWarnings("unchecked")
    public static Map<String, Object> map(Object o) {
        return o instanceof Map ? (Map<String, Object>) o : new LinkedHashMap<String, Object>();
    }

    public static String str(Map<String, Object> m, String k) {
        Object v = m.get(k);
        if (v == null) return "";
        if (v instanceof Double && ((Double) v) == Math.rint((Double) v)) return String.valueOf(((Double) v).longValue());
        return String.valueOf(v);
    }

    public static String text(Object v) {
        if (v == null) return "";
        if (v instanceof String) return (String) v;
        if (v instanceof Double && ((Double) v) == Math.rint((Double) v)) return String.valueOf(((Double) v).longValue());
        if (v instanceof Map || v instanceof List) return write(v);
        return String.valueOf(v);
    }

    // ---- JSONPath subset: $.a.b, $..a, [*], [0], [-1], ['k'], [0,2], [1:3], [?(@.k)] ----

    @SuppressWarnings("unchecked")
    public static List<Object> path(Object root, String expr) {
        List<Object> cur = new ArrayList<Object>();
        cur.add(root);
        String e = expr.trim();
        if (e.startsWith("$")) e = e.substring(1);
        else if (e.startsWith("@")) e = e.substring(1);
        int i = 0;
        while (i < e.length() && !cur.isEmpty()) {
            char c = e.charAt(i);
            List<Object> next = new ArrayList<Object>();
            if (c == '.' && i + 1 < e.length() && e.charAt(i + 1) == '.') {
                i += 2;
                int a = i;
                while (i < e.length() && e.charAt(i) != '.' && e.charAt(i) != '[') i++;
                String key = e.substring(a, i);
                for (Object o : cur) deep(o, key, next);
            } else if (c == '.') {
                i++;
                int a = i;
                while (i < e.length() && e.charAt(i) != '.' && e.charAt(i) != '[') i++;
                String key = e.substring(a, i);
                for (Object o : cur) child(o, key, next);
            } else if (c == '[') {
                int close = matchBracket(e, i);
                String in = e.substring(i + 1, close).trim();
                i = close + 1;
                for (Object o : cur) bracket(o, in, next);
            } else {
                int a = i;
                while (i < e.length() && e.charAt(i) != '.' && e.charAt(i) != '[') i++;
                String key = e.substring(a, i);
                for (Object o : cur) child(o, key, next);
            }
            cur = next;
        }
        return cur;
    }

    private static int matchBracket(String e, int open) {
        int depth = 0;
        char q = 0;
        for (int k = open; k < e.length(); k++) {
            char c = e.charAt(k);
            if (q != 0) { if (c == q) q = 0; continue; }
            if (c == '\'' || c == '"') q = c;
            else if (c == '[') depth++;
            else if (c == ']') { depth--; if (depth == 0) return k; }
        }
        return e.length() - 1;
    }

    @SuppressWarnings("unchecked")
    private static void child(Object o, String key, List<Object> out) {
        if (key.equals("*")) {
            if (o instanceof Map) out.addAll(((Map<String, Object>) o).values());
            else if (o instanceof List) out.addAll((List<Object>) o);
            return;
        }
        if (o instanceof Map) {
            Map<String, Object> m = (Map<String, Object>) o;
            if (m.containsKey(key)) out.add(m.get(key));
        } else if (o instanceof List) {
            for (Object x : (List<Object>) o) if (x instanceof Map && ((Map<String, Object>) x).containsKey(key)) out.add(((Map<String, Object>) x).get(key));
        }
    }

    @SuppressWarnings("unchecked")
    private static void deep(Object o, String key, List<Object> out) {
        if (o instanceof Map) {
            for (Map.Entry<String, Object> en : ((Map<String, Object>) o).entrySet()) {
                if (key.equals("*") || en.getKey().equals(key)) out.add(en.getValue());
                deep(en.getValue(), key, out);
            }
        } else if (o instanceof List) {
            for (Object x : (List<Object>) o) deep(x, key, out);
        }
    }

    @SuppressWarnings("unchecked")
    private static void bracket(Object o, String in, List<Object> out) {
        if (in.equals("*")) { child(o, "*", out); return; }
        if (in.startsWith("'") || in.startsWith("\"")) {
            for (String k : in.split(",")) child(o, k.trim().replaceAll("^['\"]|['\"]$", ""), out);
            return;
        }
        if (in.startsWith("?(")) {
            String cond = in.substring(2, in.length() - 1).trim();
            if (!(o instanceof List)) return;
            for (Object x : (List<Object>) o) if (test(x, cond)) out.add(x);
            return;
        }
        if (!(o instanceof List)) return;
        List<Object> l = (List<Object>) o;
        int n = l.size();
        if (in.contains(":")) {
            String[] p = in.split(":", -1);
            int a = p[0].trim().length() == 0 ? 0 : Integer.parseInt(p[0].trim());
            int b = p.length < 2 || p[1].trim().length() == 0 ? n : Integer.parseInt(p[1].trim());
            if (a < 0) a += n;
            if (b < 0) b += n;
            for (int k = Math.max(0, a); k < Math.min(n, b); k++) out.add(l.get(k));
            return;
        }
        for (String part : in.split(",")) {
            try {
                int k = Integer.parseInt(part.trim());
                if (k < 0) k += n;
                if (k >= 0 && k < n) out.add(l.get(k));
            } catch (NumberFormatException ignored) {}
        }
    }

    private static boolean test(Object x, String cond) {
        // supports @.key, @.key == 'v', @.key != 'v'
        String op = cond.contains("!=") ? "!=" : cond.contains("==") ? "==" : null;
        if (op == null) return !path(x, cond).isEmpty() && path(x, cond).get(0) != null;
        String[] p = cond.split(op, 2);
        List<Object> v = path(x, p[0].trim());
        String want = p[1].trim().replaceAll("^['\"]|['\"]$", "");
        boolean eq = !v.isEmpty() && text(v.get(0)).equals(want);
        return op.equals("==") ? eq : !eq;
    }
}

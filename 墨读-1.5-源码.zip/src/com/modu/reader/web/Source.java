package com.modu.reader.web;

import java.io.IOException;

/** Where pages come from: plain HTTP in the background, or the in-app browser for script-heavy sites. */
public interface Source {
    final class Page {
        public final String url, html;
        public Page(String url, String html) { this.url = url; this.html = html; }
    }

    Page get(String url, String referer) throws IOException;
}

package com.modu.reader.web;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

/**
 * CSS selectors on {@link Dom} trees, covering what book sources use: tag, #id, .class, [attr],
 * [attr=v] ^= $= *= ~=, descendant / child / sibling combinators, groups, and jsoup-style pseudos
 * :first-child :last-child :nth-child() :eq() :lt() :gt() :contains() :containsOwn() :has() :not().
 */
public final class Css {
    private Css() {}

    private static final class Attr {
        String name, op, value;
    }

    private static final class Compound {
        String tag;            // null = any
        String id;
        final List<String> classes = new ArrayList<String>();
        final List<Attr> attrs = new ArrayList<Attr>();
        final List<String[]> pseudos = new ArrayList<String[]>(); // {name, arg}
    }

    private static final class Step {
        char comb;             // ' ' descendant, '>' child, '+' adjacent, '~' sibling (combinator BEFORE this compound)
        Compound c;
    }

    public static List<Dom.Node> select(Dom.Node root, String selector) {
        Set<Dom.Node> out = new LinkedHashSet<Dom.Node>();
        for (String group : splitTop(selector, ',')) {
            group = group.trim();
            if (group.length() == 0) continue;
            List<Step> steps = parse(group);
            if (steps.isEmpty()) continue;
            collect(root, root, steps, out);
        }
        // keep document order across groups
        if (selector.indexOf(',') >= 0) {
            List<Dom.Node> ordered = new ArrayList<Dom.Node>();
            order(root, out, ordered);
            return ordered;
        }
        return new ArrayList<Dom.Node>(out);
    }

    private static void order(Dom.Node n, Set<Dom.Node> set, List<Dom.Node> out) {
        if (set.contains(n)) out.add(n);
        for (Dom.Node c : n.children) if (!c.isText()) order(c, set, out);
    }

    private static void collect(Dom.Node scope, Dom.Node n, List<Step> steps, Set<Dom.Node> out) {
        if (!n.isText() && !n.tag.equals("#root") && matchesFrom(n, steps, steps.size() - 1, scope)) out.add(n);
        for (Dom.Node c : n.children) if (!c.isText()) collect(scope, c, steps, out);
    }

    public static boolean matches(Dom.Node n, String selector) {
        for (String group : splitTop(selector, ',')) {
            List<Step> steps = parse(group.trim());
            if (!steps.isEmpty() && matchesFrom(n, steps, steps.size() - 1, null)) return true;
        }
        return false;
    }

    private static boolean matchesFrom(Dom.Node n, List<Step> steps, int idx, Dom.Node scope) {
        Step s = steps.get(idx);
        if (!match(n, s.c)) return false;
        if (idx == 0) return true;
        switch (s.comb) {
            case '>': {
                Dom.Node p = n.parent;
                return p != null && !p.tag.equals("#root") && within(p, scope) && matchesFrom(p, steps, idx - 1, scope);
            }
            case '+': {
                Dom.Node p = prevElement(n);
                return p != null && matchesFrom(p, steps, idx - 1, scope);
            }
            case '~': {
                for (Dom.Node p = prevElement(n); p != null; p = prevElement(p)) if (matchesFrom(p, steps, idx - 1, scope)) return true;
                return false;
            }
            default: {
                for (Dom.Node p = n.parent; p != null && !p.tag.equals("#root"); p = p.parent) {
                    if (!within(p, scope)) return false;
                    if (matchesFrom(p, steps, idx - 1, scope)) return true;
                }
                return false;
            }
        }
    }

    private static boolean within(Dom.Node p, Dom.Node scope) {
        if (scope == null || scope.tag.equals("#root")) return true;
        for (Dom.Node a = p; a != null; a = a.parent) if (a == scope) return true;
        return false;
    }

    private static Dom.Node prevElement(Dom.Node n) {
        if (n.parent == null) return null;
        List<Dom.Node> sib = n.parent.children;
        for (int i = sib.indexOf(n) - 1; i >= 0; i--) if (!sib.get(i).isText()) return sib.get(i);
        return null;
    }

    private static int elementIndex(Dom.Node n) {
        if (n.parent == null) return 0;
        int i = 0;
        for (Dom.Node c : n.parent.children) {
            if (c == n) return i;
            if (!c.isText()) i++;
        }
        return i;
    }

    private static int elementCount(Dom.Node parent) {
        int i = 0;
        for (Dom.Node c : parent.children) if (!c.isText()) i++;
        return i;
    }

    private static boolean match(Dom.Node n, Compound c) {
        if (c.tag != null && !c.tag.equals("*") && !c.tag.equals(n.tag)) return false;
        if (c.id != null && !c.id.equals(n.id())) return false;
        for (String cl : c.classes) if (!n.hasClass(cl)) return false;
        for (Attr a : c.attrs) {
            String v = n.attr(a.name);
            if (v == null) return false;
            if (a.op == null) continue;
            String w = a.value;
            if (a.op.equals("=") && !v.equals(w)) return false;
            if (a.op.equals("^=") && !v.startsWith(w)) return false;
            if (a.op.equals("$=") && !v.endsWith(w)) return false;
            if (a.op.equals("*=") && !v.contains(w)) return false;
            if (a.op.equals("!=") && v.equals(w)) return false;
            if (a.op.equals("~=")) {
                boolean found = false;
                for (String t : v.split("\\s+")) if (t.equals(w)) found = true;
                if (!found) return false;
            }
            if (a.op.equals("|=") && !(v.equals(w) || v.startsWith(w + "-"))) return false;
        }
        for (String[] p : c.pseudos) {
            String name = p[0], arg = p[1];
            if (name.equals("first-child") && elementIndex(n) != 0) return false;
            if (name.equals("last-child") && (n.parent == null || elementIndex(n) != elementCount(n.parent) - 1)) return false;
            if (name.equals("only-child") && (n.parent == null || elementCount(n.parent) != 1)) return false;
            if (name.equals("eq") && elementIndex(n) != parseInt(arg)) return false;
            if (name.equals("lt") && elementIndex(n) >= parseInt(arg)) return false;
            if (name.equals("gt") && elementIndex(n) <= parseInt(arg)) return false;
            if (name.equals("nth-child") && !nth(elementIndex(n) + 1, arg)) return false;
            if (name.equals("nth-last-child") && (n.parent == null || !nth(elementCount(n.parent) - elementIndex(n), arg))) return false;
            if (name.equals("contains") && !n.ownText().toLowerCase().contains(unquote(arg).toLowerCase())) return false;
            if (name.equals("containsown")) {
                StringBuilder own = new StringBuilder();
                for (Dom.Node k : n.children) if (k.isText()) own.append(k.text);
                if (!own.toString().toLowerCase().contains(unquote(arg).toLowerCase())) return false;
            }
            if (name.equals("has") && select(n, arg).isEmpty()) return false;
            if (name.equals("not") && matches(n, arg)) return false;
        }
        return true;
    }

    private static int parseInt(String s) {
        try { return Integer.parseInt(s.trim()); } catch (Exception e) { return -1; }
    }

    private static String unquote(String s) {
        s = s.trim();
        if (s.length() >= 2 && (s.charAt(0) == '"' || s.charAt(0) == '\'') && s.charAt(s.length() - 1) == s.charAt(0)) return s.substring(1, s.length() - 1);
        return s;
    }

    private static boolean nth(int pos, String arg) {
        String a = arg.replace(" ", "").toLowerCase();
        if (a.equals("odd")) return pos % 2 == 1;
        if (a.equals("even")) return pos % 2 == 0;
        int ni = a.indexOf('n');
        if (ni < 0) return pos == parseInt(a);
        String sa = a.substring(0, ni), sb = a.substring(ni + 1);
        int step = sa.length() == 0 || sa.equals("+") ? 1 : sa.equals("-") ? -1 : parseInt(sa);
        int off = sb.length() == 0 ? 0 : parseInt(sb.replace("+", ""));
        if (step == 0) return pos == off;
        int k = pos - off;
        return k % step == 0 && k / step >= 0;
    }

    // ---- parsing -----------------------------------------------------------------------

    static List<String> splitTop(String s, char sep) {
        List<String> out = new ArrayList<String>();
        int depth = 0, start = 0;
        char q = 0;
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (q != 0) { if (c == q) q = 0; continue; }
            if (c == '"' || c == '\'') q = c;
            else if (c == '(' || c == '[') depth++;
            else if (c == ')' || c == ']') depth--;
            else if (c == sep && depth == 0) { out.add(s.substring(start, i)); start = i + 1; }
        }
        out.add(s.substring(start));
        return out;
    }

    private static List<Step> parse(String sel) {
        List<Step> steps = new ArrayList<Step>();
        int i = 0, n = sel.length();
        char comb = ' ';
        while (i < n) {
            char c = sel.charAt(i);
            if (c == ' ' || c == '\t' || c == '\n') { i++; continue; }
            if (c == '>' || c == '+' || c == '~') { comb = c; i++; continue; }
            Compound cp = new Compound();
            int start = i;
            // tag
            int a = i;
            while (i < n && (Character.isLetterOrDigit(sel.charAt(i)) || sel.charAt(i) == '-' || sel.charAt(i) == '_' || sel.charAt(i) == '*' || sel.charAt(i) == '|')) i++;
            if (i > a) cp.tag = sel.substring(a, i).toLowerCase();
            while (i < n) {
                char d = sel.charAt(i);
                if (d == '#') {
                    int b = ++i;
                    while (i < n && isName(sel.charAt(i))) i++;
                    cp.id = sel.substring(b, i);
                } else if (d == '.') {
                    int b = ++i;
                    while (i < n && isName(sel.charAt(i))) i++;
                    cp.classes.add(sel.substring(b, i));
                } else if (d == '[') {
                    int close = closeOf(sel, i, '[', ']');
                    String in = sel.substring(i + 1, close);
                    i = close + 1;
                    Attr at = new Attr();
                    String[] ops = {"^=", "$=", "*=", "~=", "|=", "!=", "="};
                    int pos = -1;
                    String op = null;
                    for (String o : ops) {
                        int k = in.indexOf(o);
                        if (k > 0 && (pos < 0 || k < pos)) { pos = k; op = o; }
                    }
                    if (op == null) at.name = in.trim().toLowerCase();
                    else {
                        at.name = in.substring(0, pos).trim().toLowerCase();
                        at.op = op;
                        at.value = unquote(in.substring(pos + op.length()));
                    }
                    cp.attrs.add(at);
                } else if (d == ':') {
                    int b = ++i;
                    while (i < n && (isName(sel.charAt(i)))) i++;
                    String name = sel.substring(b, i).toLowerCase();
                    String arg = "";
                    if (i < n && sel.charAt(i) == '(') {
                        int close = closeOf(sel, i, '(', ')');
                        arg = sel.substring(i + 1, close);
                        i = close + 1;
                    }
                    cp.pseudos.add(new String[]{name, arg});
                } else break;
            }
            if (i == start) { i++; continue; } // unknown character
            Step st = new Step();
            st.comb = comb;
            st.c = cp;
            steps.add(st);
            comb = ' ';
        }
        return steps;
    }

    private static boolean isName(char c) {
        return Character.isLetterOrDigit(c) || c == '-' || c == '_' || c > 127;
    }

    private static int closeOf(String s, int open, char o, char cl) {
        int depth = 0;
        char q = 0;
        for (int k = open; k < s.length(); k++) {
            char c = s.charAt(k);
            if (q != 0) { if (c == q) q = 0; continue; }
            if (c == '"' || c == '\'') q = c;
            else if (c == o) depth++;
            else if (c == cl) { depth--; if (depth == 0) return k; }
        }
        return s.length() - 1;
    }
}

package com.modu.reader.web;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Matching chapters between different sites (for changing source). */
public final class Chapters {
    private Chapters() {}

    private static final Pattern NUM = Pattern.compile("第\\s*([0-9０-９零〇一二两三四五六七八九十百千万]+)\\s*[章回节话卷]|^\\s*([0-9]{1,5})[\\s.、．:：]");

    public static long number(String title) {
        Matcher m = NUM.matcher(title);
        if (!m.find()) return -1;
        String n = m.group(1) != null ? m.group(1) : m.group(2);
        return parseNumber(n);
    }

    public static long parseNumber(String s) {
        StringBuilder digits = new StringBuilder();
        for (char c : s.toCharArray()) {
            if (c >= '０' && c <= '９') digits.append((char) ('0' + c - '０'));
            else if (c >= '0' && c <= '9') digits.append(c);
        }
        if (digits.length() == s.length()) return Long.parseLong(digits.toString());
        long total = 0, section = 0, num = 0;
        for (char c : s.toCharArray()) {
            int d = "零〇一二两三四五六七八九".indexOf(c);
            if (d >= 0) {
                int[] map = {0, 0, 1, 2, 2, 3, 4, 5, 6, 7, 8, 9};
                num = map[d];
                continue;
            }
            int unit = c == '十' ? 10 : c == '百' ? 100 : c == '千' ? 1000 : c == '万' ? 10000 : 0;
            if (unit == 0) continue;
            if (unit == 10000) { section = (section + num) * 10000; total += section; section = 0; num = 0; continue; }
            if (num == 0 && unit == 10) num = 1; // 十二 = 12
            section += num * unit;
            num = 0;
        }
        return total + section + num;
    }

    /** Title reduced to its words, without the chapter number, spaces or punctuation. */
    public static String words(String title) {
        String t = NUM.matcher(title).replaceFirst("");
        return t.replaceAll("[\\p{P}\\p{S}\\s　]+", "").toLowerCase();
    }

    /** Index in {@code list} of the chapter matching {@code title}, searching around {@code hint}; -1 if none. */
    public static int find(List<String[]> list, String title, int hint) {
        long n = number(title);
        String w = words(title);
        int best = -1, bestScore = 0;
        for (int i = 0; i < list.size(); i++) {
            String t = list.get(i)[0];
            int score = 0;
            long m = number(t);
            String tw = words(t);
            if (n >= 0 && m == n) score += 2;
            if (w.length() > 0 && tw.equals(w)) score += 3;
            else if (w.length() >= 2 && (tw.contains(w) || w.contains(tw)) && tw.length() >= 2) score += 1;
            if (score == 0) continue;
            if (score > bestScore || (score == bestScore && Math.abs(i - hint) < Math.abs(best - hint))) { best = i; bestScore = score; }
        }
        return bestScore >= 2 ? best : -1;
    }

    /**
     * Switches a book to another site's contents list: chapters already downloaded stay, downloading
     * continues after the matching chapter. Returns the matched index in the new list, or -1.
     */
    public static int switchToc(WebStore s, List<String[]> newToc, String tocUrl) throws Exception {
        int have = s.chapters.size();
        int match = have == 0 ? -1 : find(newToc, s.chapters.get(have - 1)[0], have - 1);
        if (have > 0 && match < 0) return -1;
        List<String[]> list = new ArrayList<String[]>(s.chapters);
        for (int i = match + 1; i < newToc.size(); i++) list.add(newToc.get(i));
        s.setToc(list);
        s.set("mode", "toc");
        s.set("toc", tocUrl);
        s.set("state", "downloading");
        s.saveMeta();
        return match;
    }
}

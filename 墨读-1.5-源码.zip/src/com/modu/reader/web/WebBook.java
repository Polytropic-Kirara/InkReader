package com.modu.reader.web;

import com.modu.reader.core.Block;
import com.modu.reader.core.Book;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

/** Reads a downloaded web novel. Chapters still downloading appear when the book is reopened. */
public class WebBook extends Book {
    private final WebStore store;

    public WebBook(File dir) throws Exception {
        store = WebStore.load(dir);
        title = store.get("title");
        author = store.get("author");
        for (String[] c : store.chapters) chapterTitles.add(c[0]);
        if (chapterTitles.isEmpty()) chapterTitles.add("正在下载…");
    }

    public boolean downloading() { return "downloading".equals(store.get("state")); }

    @Override public List<Block> chapter(int index) throws Exception {
        List<Block> out = new ArrayList<Block>();
        if (store.chapters.isEmpty()) {
            out.add(new Block(Block.PARA, "这本书还在下载，第一章下载完成后重新打开即可阅读。"));
            return out;
        }
        List<String> lines = store.chapterLines(index);
        for (int i = 0; i < lines.size(); i++) {
            String l = lines.get(i);
            if (l.length() == 0) continue;
            out.add(new Block(i == 0 ? Block.HEADING : Block.PARA, l));
        }
        return out;
    }
}

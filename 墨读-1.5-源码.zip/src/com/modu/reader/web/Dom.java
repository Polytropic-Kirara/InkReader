package com.modu.reader.web;

import com.modu.reader.core.HtmlText;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/** A small, forgiving HTML tree builder: real-world novel pages are full of unclosed and stray tags. */
public final class Dom {
    private Dom() {}

    public static final class Node {
        public final String tag;            // lower-case tag name; "#text" for text, "#root" for the document
        public String text;                 // text nodes only (entities decoded)
        public final Map<String, String> attrs;
        public final List<Node> children = new ArrayList<Node>();
        public Node parent;

        Node(String tag, Map<String, String> attrs) {
            this.tag = tag;
            this.attrs = attrs;
        }

        public boolean isText() { return "#text".equals(tag); }

        public String attr(String k) {
            if (attrs == null) return null;
            return attrs.get(k);
        }

        public String id() { String v = attr("id"); return v == null ? "" : v; }
        public String cls() { String v = attr("class"); return v == null ? "" : v; }

        public boolean hasClass(String c) {
            for (String s : cls().split("\\s+")) if (s.equals(c)) return true;
            return false;
        }

        /** All text below this node, with block elements and &lt;br&gt; becoming line breaks. */
        public String text() {
            StringBuilder sb = new StringBuilder();
            collect(this, sb);
            return sb.toString();
        }

        /** Text on one line (whitespace collapsed). */
        public String ownText() {
            return text().replaceAll("\\s+", " ").trim();
        }

        public List<Node> all(String name) {
            List<Node> out = new ArrayList<Node>();
            find(this, name, out);
            return out;
        }

        public void remove() {
            if (parent != null) parent.children.remove(this);
            parent = null;
        }

        public int index() { return parent == null ? 0 : parent.children.indexOf(this); }

        public List<Node> elements() {
            List<Node> out = new ArrayList<Node>();
            for (Node c : children) if (!c.isText()) out.add(c);
            return out;
        }

        @Override public String toString() { return isText() ? "\"" + text + "\"" : "<" + tag + (id().length() > 0 ? "#" + id() : "") + ">"; }
    }

    static final Set<String> VOID = set("area", "base", "br", "col", "embed", "hr", "img", "input", "link", "meta",
            "param", "source", "track", "wbr", "keygen");
    static final Set<String> RAW = set("script", "style", "textarea", "title", "noscript", "xmp", "template");
    public static final Set<String> BLOCK = set("p", "div", "br", "li", "ul", "ol", "dl", "dt", "dd", "table", "tr", "td",
            "th", "tbody", "thead", "h1", "h2", "h3", "h4", "h5", "h6", "pre", "blockquote", "section", "article", "header",
            "footer", "aside", "nav", "main", "form", "hr", "center", "figure", "figcaption", "address");
    private static final Set<String> CLOSES_P = set("p", "div", "ul", "ol", "dl", "table", "h1", "h2", "h3", "h4", "h5",
            "h6", "pre", "blockquote", "section", "article", "header", "footer", "aside", "nav", "form", "hr", "center", "main");

    private static Set<String> set(String... a) {
        Set<String> s = new HashSet<String>();
        for (String x : a) s.add(x);
        return s;
    }

    public static Node parse(String html) {
        Node root = new Node("#root", null);
        Node cur = root;
        int i = 0, n = html.length();
        String lower = HtmlText.asciiLower(html);
        while (i < n) {
            int lt = html.indexOf('<', i);
            if (lt < 0) lt = n;
            if (lt > i) addText(cur, html.substring(i, lt));
            if (lt >= n) break;
            i = lt;
            if (html.startsWith("<!--", i)) {
                int e = html.indexOf("-->", i + 4);
                i = e < 0 ? n : e + 3;
                continue;
            }
            char c1 = i + 1 < n ? html.charAt(i + 1) : ' ';
            if (c1 == '!' || c1 == '?') {
                int e = html.indexOf('>', i);
                i = e < 0 ? n : e + 1;
                continue;
            }
            if (c1 == '/') {
                int e = html.indexOf('>', i);
                if (e < 0) break;
                String name = html.substring(i + 2, e).trim().toLowerCase();
                int sp = name.indexOf(' ');
                if (sp >= 0) name = name.substring(0, sp);
                i = e + 1;
                Node a = cur;
                while (a != null && a != root && !a.tag.equals(name)) a = a.parent;
                if (a != null && a != root) cur = a.parent;
                continue;
            }
            if (!Character.isLetter(c1)) { // a lone '<' in text
                addText(cur, "<");
                i++;
                continue;
            }
            int e = tagEnd(html, i + 1);
            String inner = html.substring(i + 1, e < 0 ? n : e);
            i = e < 0 ? n : e + 1;
            boolean selfClose = inner.endsWith("/");
            int ne = 0;
            while (ne < inner.length() && !Character.isWhitespace(inner.charAt(ne)) && inner.charAt(ne) != '/') ne++;
            String name = inner.substring(0, ne).toLowerCase();
            Map<String, String> attrs = attrs(inner.substring(ne));
            // implicit closes
            if (CLOSES_P.contains(name)) cur = closeUp(cur, root, "p", true);
            if (name.equals("li")) cur = closeUp(cur, root, "li", false);
            if (name.equals("dt") || name.equals("dd")) { cur = closeUp(cur, root, "dt", false); cur = closeUp(cur, root, "dd", false); }
            if (name.equals("tr")) { cur = closeUp(cur, root, "td", false); cur = closeUp(cur, root, "th", false); cur = closeUp(cur, root, "tr", false); }
            if (name.equals("td") || name.equals("th")) { cur = closeUp(cur, root, "td", false); cur = closeUp(cur, root, "th", false); }
            if (name.equals("option")) cur = closeUp(cur, root, "option", false);
            Node node = new Node(name, attrs);
            node.parent = cur;
            cur.children.add(node);
            if (RAW.contains(name)) {
                int close = lower.indexOf("</" + name, i);
                if (close < 0) close = n;
                String raw = html.substring(i, close);
                if (name.equals("title") || name.equals("textarea")) addText(node, raw);
                else if (raw.length() > 0) { Node t = new Node("#text", null); t.text = raw; t.parent = node; node.children.add(t); }
                int gt = html.indexOf('>', close);
                i = gt < 0 ? n : gt + 1;
                continue;
            }
            if (!selfClose && !VOID.contains(name)) cur = node;
        }
        return root;
    }

    /** Closes the nearest open element named {@code name}, but never across a block container when {@code stopAtBlock}. */
    private static Node closeUp(Node cur, Node root, String name, boolean stopAtBlock) {
        Node a = cur;
        int depth = 0;
        while (a != null && a != root && depth < 3) {
            if (a.tag.equals(name)) return a.parent;
            if (stopAtBlock && !a.tag.equals("span") && !a.tag.equals("font") && !a.tag.equals("b") && !a.tag.equals("i")
                    && !a.tag.equals("a") && !a.tag.equals("em") && !a.tag.equals("strong")) break;
            if (!stopAtBlock && (a.tag.equals("ul") || a.tag.equals("ol") || a.tag.equals("dl") || a.tag.equals("table") || a.tag.equals("select"))) break;
            a = a.parent;
            depth++;
        }
        return cur;
    }

    private static int tagEnd(String s, int from) {
        char q = 0;
        for (int k = from; k < s.length(); k++) {
            char c = s.charAt(k);
            if (q != 0) { if (c == q) q = 0; }
            else if (c == '"' || c == '\'') {
                // only treat as a quote when it starts an attribute value
                int p = k - 1;
                while (p > from && Character.isWhitespace(s.charAt(p))) p--;
                if (s.charAt(p) == '=') q = c;
            } else if (c == '>') return k;
        }
        return -1;
    }

    private static Map<String, String> attrs(String s) {
        Map<String, String> m = new HashMap<String, String>();
        int i = 0, n = s.length();
        while (i < n) {
            while (i < n && (Character.isWhitespace(s.charAt(i)) || s.charAt(i) == '/')) i++;
            int a = i;
            while (i < n && !Character.isWhitespace(s.charAt(i)) && s.charAt(i) != '=' && s.charAt(i) != '/') i++;
            if (i == a) { i++; continue; }
            String key = s.substring(a, i).toLowerCase();
            while (i < n && Character.isWhitespace(s.charAt(i))) i++;
            String val = "";
            if (i < n && s.charAt(i) == '=') {
                i++;
                while (i < n && Character.isWhitespace(s.charAt(i))) i++;
                if (i < n && (s.charAt(i) == '"' || s.charAt(i) == '\'')) {
                    char q = s.charAt(i++);
                    int e = s.indexOf(q, i);
                    if (e < 0) e = n;
                    val = s.substring(i, e);
                    i = e + 1;
                } else {
                    int b = i;
                    while (i < n && !Character.isWhitespace(s.charAt(i))) i++;
                    val = s.substring(b, i);
                }
            }
            if (!m.containsKey(key)) m.put(key, HtmlText.decodeEntities(val));
        }
        return m;
    }

    private static void addText(Node parent, String raw) {
        String t = HtmlText.decodeEntities(raw);
        if (t.length() == 0) return;
        Node last = parent.children.isEmpty() ? null : parent.children.get(parent.children.size() - 1);
        if (last != null && last.isText()) { last.text += t; return; }
        Node tn = new Node("#text", null);
        tn.text = t;
        tn.parent = parent;
        parent.children.add(tn);
    }

    private static void collect(Node n, StringBuilder sb) {
        if (n.isText()) {
            if (n.parent != null && (n.parent.tag.equals("script") || n.parent.tag.equals("style"))) return;
            sb.append(n.text);
            return;
        }
        if (n.tag.equals("script") || n.tag.equals("style") || n.tag.equals("noscript") || n.tag.equals("template")) return;
        boolean block = BLOCK.contains(n.tag);
        if (block) sb.append('\n');
        for (Node c : n.children) collect(c, sb);
        if (block) sb.append('\n');
    }

    private static void find(Node n, String name, List<Node> out) {
        for (Node c : n.children) {
            if (c.isText()) continue;
            if (c.tag.equals(name)) out.add(c);
            find(c, name, out);
        }
    }

    /** First element under {@code n} with this tag (depth-first), or null. */
    public static Node first(Node n, String name) {
        for (Node c : n.children) {
            if (c.isText()) continue;
            if (c.tag.equals(name)) return c;
            Node r = first(c, name);
            if (r != null) return r;
        }
        return null;
    }

    public static String meta(Node root, String key) {
        for (Node m : root.all("meta")) {
            String p = m.attr("property"), nm = m.attr("name");
            if (key.equalsIgnoreCase(p) || key.equalsIgnoreCase(nm)) {
                String c = m.attr("content");
                if (c != null && c.trim().length() > 0) return c.trim();
            }
        }
        return null;
    }
}

package com.modu.reader.web;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** Downloads a web novel chapter by chapter, merging chapters that are split over several pages. */
public final class Downloader {
    private Downloader() {}

    public interface Listener {
        void onChapter(WebStore s, int count, String title);
        boolean stop();
    }

    public static final int DONE = 0, STOPPED = 1, ERROR = 2;

    /** Reads one chapter's text by URL (book sources use their own content rules). */
    public interface ChapterReader {
        List<String> read(String url, String nextChapterUrl) throws Exception;
    }

    /** Reads a whole contents list (book sources use their own contents rules). */
    public interface TocReader {
        List<String[]> toc(String url) throws Exception;
    }

    /** One chapter, all its pages merged. {@code next[0]} receives the following chapter's URL (or null). */
    public static Extractor.Chapter fetchChapter(Source src, String url, String referer, List<String> rules, String[] next, String[] lastPage) throws Exception {
        Source.Page p = src.get(url, referer);
        Extractor.Chapter c = Extractor.chapter(Dom.parse(p.html), p.url, rules);
        String pageUrl = p.url;
        Set<String> seen = new HashSet<String>();
        seen.add(p.url);
        int pages = 1;
        String following = c.nextUrl;
        boolean isPage = c.nextIsPage;
        while (isPage && following != null && pages < 40 && !seen.contains(following)) {
            Source.Page q = src.get(following, pageUrl);
            Extractor.Chapter d = Extractor.chapter(Dom.parse(q.html), q.url, rules);
            String nt = Extractor.norm(d.title);
            if (nt.length() > 0 && !nt.equals(Extractor.norm(c.title))) break; // it was actually the next chapter
            seen.add(q.url);
            pageUrl = q.url;
            pages++;
            // drop a repeated last line/first line overlap
            List<String> add = new ArrayList<String>(d.paras);
            if (!add.isEmpty() && !c.paras.isEmpty() && add.get(0).equals(c.paras.get(c.paras.size() - 1))) add.remove(0);
            c.paras.addAll(add);
            following = d.nextUrl;
            isPage = d.nextIsPage;
            if (d.tocUrl != null && c.tocUrl == null) c.tocUrl = d.tocUrl;
        }
        if (next != null) next[0] = following;
        if (lastPage != null) lastPage[0] = pageUrl;
        return c;
    }

    public static int run(WebStore s, Source src, Listener l, long delayMs, List<String> rules) {
        return run(s, src, l, delayMs, rules, null);
    }

    public static int run(WebStore s, Source src, Listener l, long delayMs, List<String> rules, ChapterReader reader) {
        try {
            if (s.tocMode()) {
                int i = s.chapters.size();
                while (i < s.toc.size()) {
                    if (l != null && l.stop()) return stopped(s);
                    String[] e = s.toc.get(i);
                    String[] lp = new String[1];
                    List<String> paras;
                    String title = e[0];
                    if (reader != null) {
                        paras = new ArrayList<String>(reader.read(e[1], i + 1 < s.toc.size() ? s.toc.get(i + 1)[1] : null));
                        lp[0] = e[1];
                    } else {
                        Extractor.Chapter c = fetchChapter(src, e[1], s.get("toc"), rules, null, lp);
                        paras = c.paras;
                        if (title.length() == 0) title = c.title;
                    }
                    if (paras.isEmpty()) paras.add("（这一章没有识别到正文，可能需要在浏览器里打开原网页查看）");
                    s.appendChapter(title, e[1], paras);
                    s.set("lastPage", lp[0]);
                    s.saveMeta();
                    i++;
                    if (l != null) l.onChapter(s, s.chapters.size(), title);
                    pause(delayMs);
                }
            } else {
                Set<String> seen = new HashSet<String>();
                for (String[] c : s.chapters) seen.add(c[1]);
                String url = s.get("next");
                int empty = 0;
                while (url.length() > 0) {
                    if (l != null && l.stop()) return stopped(s);
                    if (seen.contains(url)) break;
                    String ref = s.chapters.isEmpty() ? null : s.chapters.get(s.chapters.size() - 1)[1];
                    String[] next = new String[1], lp = new String[1];
                    Extractor.Chapter c = fetchChapter(src, url, ref, rules, next, lp);
                    if (c.paras.isEmpty()) {
                        if (++empty >= 2 || s.chapters.isEmpty()) {
                            s.set("state", "error");
                            s.set("error", "没有识别到正文：" + url);
                            s.saveMeta();
                            return ERROR;
                        }
                        c.paras.add("（这一章没有识别到正文）");
                    } else {
                        empty = 0;
                    }
                    if (s.get("toc").length() == 0 && c.tocUrl != null) s.set("toc", c.tocUrl);
                    s.appendChapter(c.title.length() > 0 ? c.title : "第 " + (s.chapters.size() + 1) + " 章", url, c.paras);
                    seen.add(url);
                    s.set("lastPage", lp[0]);
                    s.set("next", next[0] == null ? "" : next[0]);
                    s.saveMeta();
                    if (l != null) l.onChapter(s, s.chapters.size(), c.title);
                    url = next[0] == null ? "" : next[0];
                    pause(delayMs);
                }
            }
            s.set("state", "done");
            s.set("error", "");
            s.saveMeta();
            return DONE;
        } catch (Throwable t) {
            try {
                s.set("state", "error");
                s.set("error", t.getMessage() == null ? t.toString() : t.getMessage());
                s.saveMeta();
            } catch (Exception ignored) {}
            return ERROR;
        }
    }

    private static int stopped(WebStore s) {
        try { s.saveMeta(); } catch (Exception ignored) {}
        return STOPPED;
    }

    private static void pause(long ms) {
        if (ms <= 0) return;
        try { Thread.sleep(ms); } catch (InterruptedException ignored) {}
    }

    /** Reads a contents page (and its following pages) into a chapter list. */
    public static Extractor.Toc fetchToc(Source src, String url) throws Exception {
        Extractor.Toc all = null;
        Set<String> urls = new HashSet<String>();
        Set<String> pagesSeen = new HashSet<String>();
        String cur = url;
        int pages = 0;
        while (cur != null && pages < 60 && !pagesSeen.contains(cur)) {
            pagesSeen.add(cur);
            Source.Page p = src.get(cur, null);
            Extractor.Toc t = Extractor.toc(Dom.parse(p.html), p.url);
            if (all == null) all = t;
            else for (String[] e : t.links) if (!urls.contains(e[1])) all.links.add(e);
            for (String[] e : t.links) urls.add(e[1]);
            cur = t.nextPage;
            pages++;
            if (t.links.isEmpty()) break;
        }
        return all == null ? new Extractor.Toc() : all;
    }

    /** Looks for new chapters. Returns how many were found; the book is marked for downloading if any. */
    public static int checkUpdate(WebStore s, Source src, List<String> rules) throws Exception {
        return checkUpdate(s, src, rules, null);
    }

    public static int checkUpdate(WebStore s, Source src, List<String> rules, TocReader tr) throws Exception {
        if (s.tocMode()) {
            List<String[]> links = tr != null ? tr.toc(s.get("toc")) : fetchToc(src, s.get("toc")).links;
            Set<String> known = new HashSet<String>();
            for (String[] e : s.toc) known.add(e[1]);
            List<String[]> list = new ArrayList<String[]>(s.toc);
            int added = 0;
            for (String[] e : links) if (!known.contains(e[1])) { list.add(e); added++; }
            if (added > 0) {
                s.setToc(list);
                s.set("state", "downloading");
                s.saveMeta();
            }
            return added;
        }
        String last = s.get("lastPage");
        if (last.length() == 0) return 0;
        Source.Page p = src.get(last, null);
        Extractor.Chapter c = Extractor.chapter(Dom.parse(p.html), p.url, rules);
        String next = c.nextUrl;
        if (next == null) return 0;
        for (String[] e : s.chapters) if (e[1].equals(next)) return 0;
        s.set("next", next);
        s.set("state", "downloading");
        s.saveMeta();
        return 1;
    }
}

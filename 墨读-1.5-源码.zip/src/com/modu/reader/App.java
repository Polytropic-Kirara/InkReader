package com.modu.reader;

import android.app.Activity;
import android.app.Application;
import android.content.pm.PackageInfo;
import android.os.Build;
import android.os.Bundle;

import java.io.File;
import java.io.FileOutputStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;
import java.util.Locale;

/** Records crashes (with recent app events) so they can be copied and sent for fixing. */
public class App extends Application {
    private static App self;
    private static final LinkedList<String> EVENTS = new LinkedList<String>();
    private static final SimpleDateFormat TIME = new SimpleDateFormat("MM-dd HH:mm:ss", Locale.US);

    @Override public void onCreate() {
        super.onCreate();
        self = this;
        JsEngine.install(this);
        final Thread.UncaughtExceptionHandler prev = Thread.getDefaultUncaughtExceptionHandler();
        Thread.setDefaultUncaughtExceptionHandler(new Thread.UncaughtExceptionHandler() {
            @Override public void uncaughtException(Thread t, Throwable e) {
                try { writeCrash(t, e); } catch (Throwable ignored) {}
                if (prev != null) prev.uncaughtException(t, e);
                else System.exit(2);
            }
        });
        registerActivityLifecycleCallbacks(new ActivityLifecycleCallbacks() {
            @Override public void onActivityCreated(Activity a, Bundle b) { log("打开 " + a.getClass().getSimpleName()); }
            @Override public void onActivityStarted(Activity a) {}
            @Override public void onActivityResumed(Activity a) {}
            @Override public void onActivityPaused(Activity a) {}
            @Override public void onActivityStopped(Activity a) {}
            @Override public void onActivitySaveInstanceState(Activity a, Bundle b) {}
            @Override public void onActivityDestroyed(Activity a) { log("关闭 " + a.getClass().getSimpleName()); }
        });
    }

    public static void log(String s) {
        synchronized (EVENTS) {
            EVENTS.add(TIME.format(new Date()) + "  " + s);
            while (EVENTS.size() > 80) EVENTS.removeFirst();
        }
    }

    /** Non-fatal problem worth seeing in a report (stack trace kept short). */
    public static void warn(String where, Throwable e) {
        StringBuilder sb = new StringBuilder(where).append("：").append(e);
        StackTraceElement[] st = e.getStackTrace();
        for (int i = 0; i < Math.min(4, st.length); i++) sb.append("\n      at ").append(st[i]);
        log(sb.toString());
    }

    static File dir() {
        File d = new File(self.getFilesDir(), "crash");
        d.mkdirs();
        return d;
    }

    static String header() {
        String ver = "?";
        try {
            PackageInfo pi = self.getPackageManager().getPackageInfo(self.getPackageName(), 0);
            ver = pi.versionName + " (" + pi.versionCode + ")";
        } catch (Exception ignored) {}
        return "墨读 " + ver + "\nAndroid " + Build.VERSION.RELEASE + " (API " + Build.VERSION.SDK_INT + ")\n设备 "
                + Build.MANUFACTURER + " " + Build.MODEL + "\n";
    }

    private static void writeCrash(Thread t, Throwable e) throws Exception {
        StringWriter sw = new StringWriter();
        PrintWriter pw = new PrintWriter(sw);
        pw.println(header());
        pw.println("时间 " + new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(new Date()));
        pw.println("线程 " + t.getName());
        pw.println();
        e.printStackTrace(pw);
        pw.println();
        pw.println("—— 最近的操作 ——");
        synchronized (EVENTS) { for (String s : EVENTS) pw.println(s); }
        pw.flush();
        File f = new File(dir(), "crash-" + System.currentTimeMillis() + ".txt");
        FileOutputStream out = new FileOutputStream(f);
        out.write(sw.toString().getBytes("UTF-8"));
        out.close();
        Theme.prefs(self).edit().putBoolean("crashPending", true).commit();
        File[] all = crashes();
        for (int i = 10; i < all.length; i++) all[i].delete();
    }

    /** Crash reports, newest first. */
    static File[] crashes() {
        File[] fs = dir().listFiles();
        if (fs == null) return new File[0];
        Arrays.sort(fs, new Comparator<File>() {
            @Override public int compare(File a, File b) { return Long.compare(b.lastModified(), a.lastModified()); }
        });
        return fs;
    }

    /** Everything worth sending: the newest crash in full, older ones' first lines, and recent events. */
    static String report() {
        StringBuilder sb = new StringBuilder();
        File[] fs = crashes();
        try {
            if (fs.length > 0) {
                sb.append(new String(com.modu.reader.core.Util.readFile(fs[0]), "UTF-8"));
                List<String> older = new ArrayList<String>();
                for (int i = 1; i < fs.length; i++) {
                    String s = new String(com.modu.reader.core.Util.readFile(fs[i]), "UTF-8");
                    int at = s.indexOf("时间 ");
                    int ex = s.indexOf("\n\n", at < 0 ? 0 : at);
                    String first = ex > 0 && ex + 2 < s.length() ? s.substring(ex + 2, Math.min(s.length(), s.indexOf('\n', ex + 2) < 0 ? s.length() : s.indexOf('\n', ex + 2))) : "";
                    older.add((at >= 0 ? s.substring(at + 3, at + 22) : "") + "  " + first);
                }
                if (!older.isEmpty()) {
                    sb.append("\n—— 更早的崩溃 ——\n");
                    for (String o : older) sb.append(o).append('\n');
                }
            } else {
                sb.append(header()).append("\n没有崩溃记录。\n\n—— 最近的操作 ——\n");
                synchronized (EVENTS) { for (String s : EVENTS) sb.append(s).append('\n'); }
            }
        } catch (Exception e) {
            sb.append("读取日志失败：").append(e);
        }
        return sb.toString();
    }

    static void clear() {
        for (File f : crashes()) f.delete();
    }
}

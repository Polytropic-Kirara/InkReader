package com.modu.reader;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.media.AudioManager;
import android.media.MediaMetadata;
import android.media.session.MediaSession;
import android.media.session.PlaybackState;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.speech.tts.Voice;

import com.modu.reader.core.Block;
import com.modu.reader.core.Book;
import com.modu.reader.core.BookFactory;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/**
 * Reads a book aloud with the system text-to-speech engine. Runs as a foreground service with a
 * media notification so it keeps going with the screen off; the reader follows along by listening.
 */
public class TtsService extends Service implements TextToSpeech.OnInitListener {
    public interface Listener {
        void onSpeak(String bookId, int chapter, int block);
        void onState(boolean active, boolean playing);
        void onMessage(String msg);
    }

    static final String ACTION_START = "start", ACTION_TOGGLE = "toggle", ACTION_NEXT = "next", ACTION_STOP = "stop";
    private static final int NOTE_ID = 42;
    private static final String CHANNEL = "tts";

    static volatile TtsService instance;
    static Listener listener;

    private final Handler ui = new Handler(Looper.getMainLooper());
    private TextToSpeech tts;
    private boolean ready, playing, stopAtChapterEnd;
    private String bookId, bookTitle = "";
    private Book book;
    private int chapter, block;
    private final List<int[]> queue = new ArrayList<int[]>(); // {chapter, block, part, isLast}
    private MediaSession session;
    private AudioManager audio;
    private PowerManager.WakeLock wake;
    private long sleepAt;
    private final Runnable sleeper = new Runnable() {
        @Override public void run() {
            if (sleepAt > 0 && System.currentTimeMillis() >= sleepAt) { sleepAt = 0; pause(); message("定时结束，已暂停"); }
        }
    };

    // ---- static helpers for the reader -------------------------------------------------

    static boolean activeFor(String id) {
        TtsService s = instance;
        return s != null && id != null && id.equals(s.bookId);
    }

    static boolean isPlaying() { TtsService s = instance; return s != null && s.playing; }
    static int currentChapter() { TtsService s = instance; return s == null ? -1 : s.chapter; }
    static int currentBlock() { TtsService s = instance; return s == null ? -1 : s.block; }

    static void command(Context c, String action) {
        Intent i = new Intent(c, TtsService.class).setAction(action);
        c.startService(i);
    }

    static void start(Context c, String id, int chapter, int block) {
        Intent i = new Intent(c, TtsService.class).setAction(ACTION_START)
                .putExtra("id", id).putExtra("chapter", chapter).putExtra("block", block);
        if (Build.VERSION.SDK_INT >= 26) {
            try { Context.class.getMethod("startForegroundService", Intent.class).invoke(c, i); return; } catch (Throwable ignored) {}
        }
        c.startService(i);
    }

    static void setRate(Context c, float r) {
        Theme.prefs(c).edit().putFloat("ttsRate", r).apply();
        TtsService s = instance;
        if (s != null && s.tts != null) {
            s.tts.setSpeechRate(r);
            if (s.playing) s.speakFrom(s.chapter, s.block);
        }
    }

    static void setSleep(int minutes, boolean chapterEnd) {
        TtsService s = instance;
        if (s == null) return;
        s.ui.removeCallbacks(s.sleeper);
        s.stopAtChapterEnd = chapterEnd;
        s.sleepAt = minutes > 0 ? System.currentTimeMillis() + minutes * 60000L : 0;
        if (minutes > 0) s.ui.postDelayed(s.sleeper, minutes * 60000L + 500);
    }

    static long sleepRemaining() {
        TtsService s = instance;
        return s == null || s.sleepAt == 0 ? 0 : Math.max(0, s.sleepAt - System.currentTimeMillis());
    }

    static boolean sleepAtChapterEnd() { TtsService s = instance; return s != null && s.stopAtChapterEnd; }

    static List<Voice> voices() {
        TtsService s = instance;
        List<Voice> out = new ArrayList<Voice>();
        if (s == null || s.tts == null || !s.ready) return out;
        try {
            Set<Voice> vs = s.tts.getVoices();
            if (vs != null) for (Voice v : vs) {
                Locale l = v.getLocale();
                if (l != null && "zh".equals(l.getLanguage()) && !v.isNetworkConnectionRequired()) out.add(v);
            }
            if (out.isEmpty() && vs != null) for (Voice v : vs) if (v.getLocale() != null && "zh".equals(v.getLocale().getLanguage())) out.add(v);
        } catch (Throwable ignored) {}
        return out;
    }

    static void setVoice(Context c, Voice v) {
        Theme.prefs(c).edit().putString("ttsVoice", v.getName()).apply();
        TtsService s = instance;
        if (s != null && s.tts != null) {
            s.tts.setVoice(v);
            if (s.playing) s.speakFrom(s.chapter, s.block);
        }
    }

    // ---- lifecycle ---------------------------------------------------------------------

    @Override public IBinder onBind(Intent i) { return null; }

    @Override public void onCreate() {
        super.onCreate();
        instance = this;
        audio = (AudioManager) getSystemService(AUDIO_SERVICE);
        PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
        wake = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "modu:tts");
        wake.setReferenceCounted(false);
        session = new MediaSession(this, "modu-tts");
        session.setFlags(MediaSession.FLAG_HANDLES_MEDIA_BUTTONS | MediaSession.FLAG_HANDLES_TRANSPORT_CONTROLS);
        session.setCallback(new MediaSession.Callback() {
            @Override public void onPlay() { resume(); }
            @Override public void onPause() { pause(); }
            @Override public void onSkipToNext() { nextChapter(); }
            @Override public void onSkipToPrevious() { if (chapter > 0) speakFrom(chapter - 1, 0); }
            @Override public void onStop() { stopAll(); }
        });
        registerReceiver(noisy, new IntentFilter(AudioManager.ACTION_AUDIO_BECOMING_NOISY));
        tts = new TextToSpeech(getApplicationContext(), this);
        startForeground(NOTE_ID, notification());
    }

    @Override public void onInit(int status) {
        if (status != TextToSpeech.SUCCESS) {
            message("无法启动系统语音朗读，请在系统设置里安装或启用「文字转语音」引擎");
            stopAll();
            return;
        }
        int r = tts.setLanguage(Locale.SIMPLIFIED_CHINESE);
        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
            r = tts.setLanguage(Locale.CHINESE);
            if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED)
                message("当前语音引擎没有中文语音，可以在系统「文字转语音」设置里换一个引擎（例如讯飞、小爱或 Google）");
        }
        SharedPreferences sp = Theme.prefs(this);
        tts.setSpeechRate(sp.getFloat("ttsRate", 1.0f));
        String vname = sp.getString("ttsVoice", null);
        if (vname != null) {
            try { for (Voice v : tts.getVoices()) if (v.getName().equals(vname)) { tts.setVoice(v); break; } } catch (Throwable ignored) {}
        }
        tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
            @Override public void onStart(final String id) { ui.post(new Runnable() { @Override public void run() { started(id); } }); }
            @Override public void onDone(final String id) { ui.post(new Runnable() { @Override public void run() { done(id); } }); }
            @Override public void onError(final String id) { ui.post(new Runnable() { @Override public void run() { done(id); } }); }
        });
        ready = true;
        if (book != null) speakFrom(chapter, block);
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        String a = intent == null ? null : intent.getAction();
        if (ACTION_START.equals(a)) {
            startForeground(NOTE_ID, notification());
            final String id = intent.getStringExtra("id");
            final int ch = intent.getIntExtra("chapter", 0), bl = intent.getIntExtra("block", 0);
            open(id, ch, bl);
        } else if (ACTION_TOGGLE.equals(a)) {
            if (playing) pause(); else resume();
        } else if (ACTION_NEXT.equals(a)) {
            nextChapter();
        } else if (ACTION_STOP.equals(a)) {
            stopAll();
        }
        return START_NOT_STICKY;
    }

    @Override public void onDestroy() {
        instance = null;
        try { unregisterReceiver(noisy); } catch (Throwable ignored) {}
        if (tts != null) { tts.stop(); tts.shutdown(); }
        session.release();
        if (wake.isHeld()) wake.release();
        audio.abandonAudioFocus(focus);
        ui.removeCallbacks(sleeper);
        notifyState();
        super.onDestroy();
    }

    // ---- book --------------------------------------------------------------------------

    private void open(final String id, final int ch, final int bl) {
        if (id != null && id.equals(bookId) && book != null) { speakFrom(ch, bl); return; }
        final Library.Entry e = Library.get(this, id);
        if (e == null) { stopAll(); return; }
        new Thread() {
            @Override public void run() {
                try {
                    final Book b = BookFactory.open(new File(e.path), e.format, e.encoding, e.title);
                    ui.post(new Runnable() {
                        @Override public void run() {
                            if (book != null) book.close();
                            book = b;
                            bookId = id;
                            bookTitle = e.title;
                            chapter = ch;
                            block = bl;
                            if (ready) speakFrom(ch, bl);
                        }
                    });
                } catch (final Throwable t) {
                    ui.post(new Runnable() { @Override public void run() { message("打开书籍失败：" + t.getMessage()); stopAll(); } });
                }
            }
        }.start();
    }

    private List<Block> blocks(int ch) {
        try { return book.chapter(ch); } catch (Throwable t) { App.warn("朗读读取章节", t); return new ArrayList<Block>(); }
    }

    /** Splits a paragraph into pieces the engine accepts, at sentence ends where possible. */
    private List<String> pieces(String text) {
        List<String> out = new ArrayList<String>();
        int max = Math.min(400, TextToSpeech.getMaxSpeechInputLength() - 10);
        while (text.length() > max) {
            int cut = -1;
            for (int i = max; i > max / 2; i--) if ("。！？!?；;…".indexOf(text.charAt(i)) >= 0) { cut = i + 1; break; }
            if (cut < 0) for (int i = max; i > max / 2; i--) if ("，,、 ".indexOf(text.charAt(i)) >= 0) { cut = i + 1; break; }
            if (cut < 0) cut = max;
            out.add(text.substring(0, cut));
            text = text.substring(cut);
        }
        if (text.trim().length() > 0) out.add(text);
        return out;
    }

    void speakFrom(int ch, int bl) {
        if (book == null || !ready) { chapter = ch; block = bl; return; }
        if (ch >= book.chapterCount()) { message("全书读完了"); stopAll(); return; }
        chapter = ch;
        block = bl;
        tts.stop();
        queue.clear();
        List<Block> list = blocks(ch);
        boolean first = true;
        int lastIndex = -1;
        for (int i = Math.max(0, bl); i < list.size(); i++) if (list.get(i).type != Block.IMAGE) lastIndex = i;
        for (int i = Math.max(0, bl); i < list.size(); i++) {
            Block b = list.get(i);
            if (b.type == Block.IMAGE) continue;
            List<String> ps = pieces(b.text);
            for (int k = 0; k < ps.size(); k++) {
                Bundle params = new Bundle();
                params.putInt(TextToSpeech.Engine.KEY_PARAM_STREAM, AudioManager.STREAM_MUSIC);
                boolean last = i == lastIndex && k == ps.size() - 1;
                String uid = ch + ":" + i + ":" + k + (last ? ":end" : "");
                tts.speak(ps.get(k), first ? TextToSpeech.QUEUE_FLUSH : TextToSpeech.QUEUE_ADD, params, uid);
                first = false;
            }
            if (b.type == Block.HEADING) tts.playSilentUtterance(350, TextToSpeech.QUEUE_ADD, ch + ":" + i + ":pause");
        }
        if (first) { // empty chapter
            if (ch + 1 < book.chapterCount()) { speakFrom(ch + 1, 0); return; }
            message("全书读完了");
            stopAll();
            return;
        }
        if (!playing) {
            playing = true;
            audio.requestAudioFocus(focus, AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN);
            session.setActive(true);
            if (!wake.isHeld()) wake.acquire(6 * 60 * 60 * 1000L);
        }
        updateSession();
        notifyState();
    }

    private void started(String id) {
        String[] p = id.split(":");
        if (p.length < 2) return;
        try {
            int ch = Integer.parseInt(p[0]), bl = Integer.parseInt(p[1]);
            boolean newChapter = ch != chapter;
            chapter = ch;
            if (bl != block || newChapter) {
                block = bl;
                if (listener != null) listener.onSpeak(bookId, chapter, block);
                savePosition();
            }
            if (newChapter) updateSession();
        } catch (NumberFormatException ignored) {}
    }

    private void done(String id) {
        if (!playing || !id.endsWith(":end")) return;
        if (stopAtChapterEnd) { stopAtChapterEnd = false; pause(); message("本章读完，已按定时暂停"); return; }
        if (chapter + 1 < book.chapterCount()) speakFrom(chapter + 1, 0);
        else {
            // web books may still be downloading: reopen to pick up new chapters
            if ("web".equals(entryFormat())) { reloadAndContinue(); return; }
            message("全书读完了");
            stopAll();
        }
    }

    private String entryFormat() {
        Library.Entry e = Library.get(this, bookId);
        return e == null ? "" : e.format;
    }

    private void reloadAndContinue() {
        final int count = book.chapterCount();
        final Library.Entry e = Library.get(this, bookId);
        if (e == null) { stopAll(); return; }
        new Thread() {
            @Override public void run() {
                try {
                    final Book b = BookFactory.open(new File(e.path), e.format, e.encoding, e.title);
                    ui.post(new Runnable() {
                        @Override public void run() {
                            if (b.chapterCount() > count) { book.close(); book = b; speakFrom(count, 0); }
                            else { b.close(); message("后面的章节还没下载好，已暂停"); pause(); }
                        }
                    });
                } catch (Throwable t) {
                    ui.post(new Runnable() { @Override public void run() { pause(); } });
                }
            }
        }.start();
    }

    private void savePosition() {
        final int ch = chapter, bl = block;
        Library.update(this, bookId, new Library.Change() {
            @Override public void apply(Library.Entry e) {
                e.chapter = ch;
                e.block = bl;
                e.lastRead = System.currentTimeMillis();
                if (book != null && book.chapterCount() > 0) e.progress = Math.min(1f, (ch + 0.5f) / book.chapterCount());
                if (book != null) e.chapterTitle = book.displayTitle(ch);
            }
        });
    }

    // ---- controls ----------------------------------------------------------------------

    void pause() {
        if (!playing) return;
        playing = false;
        tts.stop();
        if (wake.isHeld()) wake.release();
        updateSession();
        notifyState();
    }

    void resume() {
        if (playing || book == null) return;
        speakFrom(chapter, block);
    }

    void nextChapter() {
        if (book != null && chapter + 1 < book.chapterCount()) speakFrom(chapter + 1, 0);
    }

    void stopAll() {
        playing = false;
        if (tts != null) tts.stop();
        savePositionSafe();
        stopForeground(true);
        stopSelf();
        instance = null;
        notifyState();
    }

    private void savePositionSafe() {
        try { if (bookId != null) savePosition(); } catch (Throwable ignored) {}
    }

    private final AudioManager.OnAudioFocusChangeListener focus = new AudioManager.OnAudioFocusChangeListener() {
        private boolean pausedByFocus;
        @Override public void onAudioFocusChange(int change) {
            if (change == AudioManager.AUDIOFOCUS_LOSS || change == AudioManager.AUDIOFOCUS_LOSS_TRANSIENT) {
                if (playing) { pausedByFocus = change == AudioManager.AUDIOFOCUS_LOSS_TRANSIENT; pause(); }
            } else if (change == AudioManager.AUDIOFOCUS_GAIN && pausedByFocus) {
                pausedByFocus = false;
                resume();
            }
        }
    };

    private final BroadcastReceiver noisy = new BroadcastReceiver() {
        @Override public void onReceive(Context c, Intent i) { pause(); } // headphones unplugged
    };

    private void message(final String m) {
        if (listener != null) listener.onMessage(m);
        else android.widget.Toast.makeText(this, m, android.widget.Toast.LENGTH_LONG).show();
    }

    private void notifyState() {
        if (listener != null) listener.onState(instance != null, playing);
        if (instance != null) {
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            nm.notify(NOTE_ID, notification());
        }
    }

    // ---- media session & notification --------------------------------------------------

    private void updateSession() {
        long actions = PlaybackState.ACTION_PLAY | PlaybackState.ACTION_PAUSE | PlaybackState.ACTION_PLAY_PAUSE
                | PlaybackState.ACTION_SKIP_TO_NEXT | PlaybackState.ACTION_SKIP_TO_PREVIOUS | PlaybackState.ACTION_STOP;
        session.setPlaybackState(new PlaybackState.Builder().setActions(actions)
                .setState(playing ? PlaybackState.STATE_PLAYING : PlaybackState.STATE_PAUSED, PlaybackState.PLAYBACK_POSITION_UNKNOWN, 1f).build());
        String chapterTitle = book == null ? "" : book.displayTitle(chapter);
        session.setMetadata(new MediaMetadata.Builder()
                .putString(MediaMetadata.METADATA_KEY_TITLE, chapterTitle)
                .putString(MediaMetadata.METADATA_KEY_ARTIST, bookTitle)
                .putString(MediaMetadata.METADATA_KEY_ALBUM, "墨读 · 听书").build());
    }

    private PendingIntent action(String a, int code) {
        Intent i = new Intent(this, TtsService.class).setAction(a);
        return PendingIntent.getService(this, code, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    @SuppressWarnings("deprecation")
    private Notification notification() {
        Notification.Builder b;
        if (Build.VERSION.SDK_INT >= 26) {
            try {
                NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
                Class<?> chCls = Class.forName("android.app.NotificationChannel");
                Object ch = chCls.getConstructor(String.class, CharSequence.class, int.class).newInstance(CHANNEL, "听书", 2 /* IMPORTANCE_LOW */);
                NotificationManager.class.getMethod("createNotificationChannel", chCls).invoke(nm, ch);
                b = Notification.Builder.class.getConstructor(Context.class, String.class).newInstance(this, CHANNEL);
            } catch (Throwable t) {
                b = new Notification.Builder(this);
            }
        } else {
            b = new Notification.Builder(this);
        }
        Intent open = new Intent(this, ReaderActivity.class).putExtra("id", bookId).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent content = PendingIntent.getActivity(this, 1, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        String chapterTitle = book == null ? "准备中…" : book.displayTitle(chapter);
        b.setSmallIcon(R.mipmap.ic_launcher_mono)
                .setContentTitle(chapterTitle)
                .setContentText(bookTitle + (playing ? "　朗读中" : "　已暂停"))
                .setContentIntent(content)
                .setOngoing(playing)
                .setShowWhen(false)
                .setVisibility(Notification.VISIBILITY_PUBLIC)
                .addAction(playing ? android.R.drawable.ic_media_pause : android.R.drawable.ic_media_play, playing ? "暂停" : "继续", action(ACTION_TOGGLE, 10))
                .addAction(android.R.drawable.ic_media_next, "下一章", action(ACTION_NEXT, 11))
                .addAction(android.R.drawable.ic_menu_close_clear_cancel, "退出", action(ACTION_STOP, 12))
                .setStyle(new Notification.MediaStyle().setMediaSession(session.getSessionToken()).setShowActionsInCompactView(0, 1, 2));
        return b.build();
    }
}

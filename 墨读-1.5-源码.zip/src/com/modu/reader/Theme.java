package com.modu.reader;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.Configuration;

/** App-wide palette. Day mode is warm paper (never pure white); night mode is black. */
public final class Theme {
    public static final String PREFS = "settings";

    public static final String[] ACCENT_NAMES = {"琥珀", "赭红", "竹青", "墨蓝", "黛紫", "青灰"};
    public static final int[] ACCENTS = {0xFFC8792F, 0xFFB5533C, 0xFF4E8A68, 0xFF3E6A8E, 0xFF7A5C91, 0xFF5E7D84};

    public static final String[] DAY_NAMES = {"暖黄", "羊皮纸", "护眼绿", "浅杏", "雾灰", "米白"};
    public static final int[] DAY_BG = {0xFFF5EDD6, 0xFFEADBB8, 0xFFD5E6D3, 0xFFF3E4D7, 0xFFE4E2DC, 0xFFF8F3E6};
    public static final String[] NIGHT_NAMES = {"纯黑", "炭灰", "夜蓝", "墨绿"};
    public static final int[] NIGHT_BG = {0xFF000000, 0xFF161616, 0xFF0D1421, 0xFF0E1712};

    public static final String[] MODE_NAMES = {"日间", "夜间", "跟随系统"};
    public static final String[] ANIM_NAMES = {"仿真", "覆盖", "平移", "无", "滚动"};

    public final boolean night;
    public final int accent, bg, surface, card, text, sub, divider, readBg, readFg, scrim;

    private Theme(boolean night, int accent, int readBg) {
        this.night = night;
        this.accent = accent;
        this.readBg = readBg;
        this.readFg = textFor(readBg, night);
        if (night) {
            bg = 0xFF0B0B0B; surface = 0xFF161616; card = 0xFF1E1E1E;
            text = 0xFFC4C4C4; sub = 0xFF767676; divider = 0xFF2A2A2A; scrim = 0x99000000;
        } else {
            bg = 0xFFF3EBD6; surface = 0xFFFAF4E3; card = 0xFFFFF9EC;
            text = 0xFF3B3226; sub = 0xFF8C7F69; divider = 0xFFE2D5B8; scrim = 0x66000000;
        }
    }

    public static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public static boolean isNight(Context c) {
        int mode = prefs(c).getInt("mode", 0);
        if (mode == 2) {
            int ui = c.getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK;
            return ui == Configuration.UI_MODE_NIGHT_YES;
        }
        return mode == 1;
    }

    public static Theme get(Context c) {
        SharedPreferences p = prefs(c);
        boolean night = isNight(c);
        int accent = ACCENTS[Math.max(0, Math.min(p.getInt("accent", 0), ACCENTS.length - 1))];
        int read;
        if (night) {
            int i = p.getInt("nightBg", 0);
            read = i < 0 ? p.getInt("nightBgCustom", 0xFF000000) : NIGHT_BG[Math.min(i, NIGHT_BG.length - 1)];
        } else {
            int i = p.getInt("dayBg", 0);
            read = i < 0 ? p.getInt("dayBgCustom", DAY_BG[0]) : DAY_BG[Math.min(i, DAY_BG.length - 1)];
        }
        return new Theme(night, accent, read);
    }

    /** Readable but soft text color for a page background. */
    public static int textFor(int bg, boolean night) {
        if (luminance(bg) > 0.45f) return mix(bg, 0xFF1A140C, 0.80f);
        return mix(bg, 0xFFFFFFFF, night ? 0.50f : 0.72f);
    }

    public static float luminance(int c) {
        return (((c >> 16) & 0xFF) * 0.299f + ((c >> 8) & 0xFF) * 0.587f + (c & 0xFF) * 0.114f) / 255f;
    }

    public static int mix(int a, int b, float t) {
        int r = (int) (((a >> 16) & 0xFF) * (1 - t) + ((b >> 16) & 0xFF) * t);
        int g = (int) (((a >> 8) & 0xFF) * (1 - t) + ((b >> 8) & 0xFF) * t);
        int bl = (int) ((a & 0xFF) * (1 - t) + (b & 0xFF) * t);
        return 0xFF000000 | (r << 16) | (g << 8) | bl;
    }

    public static int alpha(int c, float a) {
        return (c & 0x00FFFFFF) | (((int) (a * 255)) << 24);
    }
}

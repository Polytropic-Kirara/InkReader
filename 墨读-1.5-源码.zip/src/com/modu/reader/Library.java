package com.modu.reader;

import android.content.Context;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.pdf.PdfRenderer;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import android.provider.OpenableColumns;

import com.modu.reader.core.Book;
import com.modu.reader.core.BookFactory;
import com.modu.reader.core.Util;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.UUID;

/** Bookshelf storage. Imported books are copied into app storage so they always reopen. */
public final class Library {
    private Library() {}

    public static class Entry {
        public String id, title = "", author = "", format, path, cover, encoding, fileName = "", chapterTitle = "", dlState = "", dlError = "", source = "", srcUrl = "";
        public int dlCount, block = -1;
        public boolean browserOnly;
        public int chapter, offset, pdfPage;
        public float progress;
        public long size, added, lastRead;

        JSONObject toJson() throws Exception {
            JSONObject o = new JSONObject();
            o.put("id", id); o.put("title", title); o.put("author", author); o.put("format", format);
            o.put("path", path); o.put("cover", cover == null ? "" : cover); o.put("encoding", encoding == null ? "" : encoding);
            o.put("fileName", fileName); o.put("dlState", dlState == null ? "" : dlState); o.put("dlError", dlError == null ? "" : dlError); o.put("source", source == null ? "" : source); o.put("srcUrl", srcUrl == null ? "" : srcUrl); o.put("dlCount", dlCount); o.put("block", block); o.put("browserOnly", browserOnly); o.put("chapterTitle", chapterTitle == null ? "" : chapterTitle); o.put("chapter", chapter); o.put("offset", offset); o.put("pdfPage", pdfPage);
            o.put("progress", (double) progress); o.put("size", size); o.put("added", added); o.put("lastRead", lastRead);
            return o;
        }

        static Entry fromJson(JSONObject o) {
            Entry e = new Entry();
            e.id = o.optString("id"); e.title = o.optString("title"); e.author = o.optString("author");
            e.format = o.optString("format"); e.path = o.optString("path");
            e.cover = o.optString("cover"); if (e.cover.length() == 0) e.cover = null;
            e.encoding = o.optString("encoding"); if (e.encoding.length() == 0) e.encoding = null;
            e.fileName = o.optString("fileName"); e.dlState = o.optString("dlState"); e.dlError = o.optString("dlError"); e.source = o.optString("source"); e.srcUrl = o.optString("srcUrl"); e.dlCount = o.optInt("dlCount"); e.block = o.optInt("block", -1); e.browserOnly = o.optBoolean("browserOnly"); e.chapterTitle = o.optString("chapterTitle"); e.chapter = o.optInt("chapter"); e.offset = o.optInt("offset");
            e.pdfPage = o.optInt("pdfPage"); e.progress = (float) o.optDouble("progress", 0);
            e.size = o.optLong("size"); e.added = o.optLong("added"); e.lastRead = o.optLong("lastRead");
            return e;
        }
    }

    private static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences("library", Context.MODE_PRIVATE);
    }

    public static synchronized List<Entry> all(Context c) {
        List<Entry> out = new ArrayList<Entry>();
        try {
            JSONArray a = new JSONArray(prefs(c).getString("books", "[]"));
            for (int i = 0; i < a.length(); i++) out.add(Entry.fromJson(a.getJSONObject(i)));
        } catch (Exception ignored) {}
        Collections.sort(out, new Comparator<Entry>() {
            @Override public int compare(Entry x, Entry y) {
                long kx = Math.max(x.lastRead, x.added), ky = Math.max(y.lastRead, y.added);
                return kx == ky ? 0 : (kx > ky ? -1 : 1);
            }
        });
        return out;
    }

    public static synchronized Entry get(Context c, String id) {
        for (Entry e : all(c)) if (e.id.equals(id)) return e;
        return null;
    }

    private static void save(Context c, List<Entry> list) {
        JSONArray a = new JSONArray();
        try {
            for (Entry e : list) a.put(e.toJson());
        } catch (Exception ignored) {}
        prefs(c).edit().putString("books", a.toString()).apply();
    }

    public static synchronized void put(Context c, Entry e) {
        List<Entry> list = all(c);
        boolean found = false;
        for (int i = 0; i < list.size(); i++) {
            if (list.get(i).id.equals(e.id)) { list.set(i, e); found = true; break; }
        }
        if (!found) list.add(e);
        save(c, list);
    }

    public interface Change { void apply(Entry e); }

    /** Reads the latest copy of an entry, changes it and saves it in one step (downloads and the reader both write). */
    public static synchronized Entry update(Context c, String id, Change change) {
        List<Entry> list = all(c);
        for (int i = 0; i < list.size(); i++) {
            Entry e = list.get(i);
            if (e.id.equals(id)) {
                change.apply(e);
                save(c, list);
                return e;
            }
        }
        return null;
    }

    private static void deleteTree(File f) {
        File[] kids = f.listFiles();
        if (kids != null) for (File k : kids) deleteTree(k);
        f.delete();
    }

    public static synchronized void remove(Context c, Entry e) {
        List<Entry> list = all(c);
        for (int i = 0; i < list.size(); i++) if (list.get(i).id.equals(e.id)) { list.remove(i); break; }
        save(c, list);
        if (e.path != null) deleteTree(new File(e.path));
        if (e.cover != null) new File(e.cover).delete();
    }

    public static String displayName(Context c, Uri uri) {
        String name = null;
        try {
            Cursor cur = c.getContentResolver().query(uri, new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null);
            if (cur != null) {
                try { if (cur.moveToFirst()) name = cur.getString(0); } finally { cur.close(); }
            }
        } catch (Exception ignored) {}
        if (name == null) name = uri.getLastPathSegment();
        if (name == null) name = "未命名";
        int slash = name.lastIndexOf('/');
        if (slash >= 0) name = name.substring(slash + 1);
        return name;
    }

    /** Copies the document into app storage, detects its format and reads title/cover. Runs off the UI thread. */
    public static Entry importUri(Context c, Uri uri) throws Exception {
        return importUri(c, uri, null);
    }

    /** True if a file with this name and size is already on the shelf. */
    public static boolean onShelf(List<Entry> shelf, String name, long size) {
        for (Entry e : shelf) if (e.size == size && name.equals(e.fileName)) return true;
        return false;
    }

    public static Entry importUri(Context c, Uri uri, String knownName) throws Exception {
        String name = knownName != null ? knownName : displayName(c, uri);
        File dir = new File(c.getFilesDir(), "books");
        dir.mkdirs();
        String id = UUID.randomUUID().toString().replace("-", "");
        File tmp = new File(dir, id + ".tmp");
        long size = 0;
        InputStream in = c.getContentResolver().openInputStream(uri);
        if (in == null) throw new Exception("无法读取文件：" + name);
        OutputStream out = new FileOutputStream(tmp);
        try {
            byte[] buf = new byte[128 * 1024];
            int n;
            while ((n = in.read(buf)) > 0) { out.write(buf, 0, n); size += n; }
        } finally {
            in.close();
            out.close();
        }
        for (Entry e : all(c)) {
            if (e.size == size && name.equals(e.fileName) && new File(e.path).exists()) {
                tmp.delete();
                return e; // already on the shelf
            }
        }
        String fmt;
        try {
            fmt = BookFactory.detect(tmp, name);
        } catch (Exception ex) {
            fmt = null;
        }
        if (fmt == null) {
            tmp.delete();
            throw new Exception("不支持的文件格式：" + name);
        }
        File dest = new File(dir, id + "." + fmt);
        if (!tmp.renameTo(dest)) { tmp.delete(); throw new Exception("保存文件失败"); }

        Entry e = new Entry();
        e.id = id; e.format = fmt; e.path = dest.getAbsolutePath(); e.fileName = name; e.size = size;
        e.added = System.currentTimeMillis();
        e.title = Util.stripExt(name);
        Bitmap cover = null;
        try {
            if (BookFactory.PDF.equals(fmt)) {
                cover = pdfThumb(dest);
            } else {
                Book b = BookFactory.open(dest, fmt, null, e.title);
                try {
                    if (b.title != null && b.title.length() > 0 && !BookFactory.TXT.equals(fmt)) e.title = b.title;
                    if (b.author != null && !"Unknown".equalsIgnoreCase(b.author)) e.author = b.author;
                    if (BookFactory.TXT.equals(fmt) && b.chapterCount() == 0) throw new Exception("文件为空");
                    byte[] cb = b.cover();
                    if (cb != null) cover = decodeScaled(cb, 360);
                } finally {
                    b.close();
                }
            }
        } catch (Exception ex) {
            dest.delete();
            throw new Exception("无法打开《" + e.title + "》：" + ex.getMessage());
        }
        if (cover != null) {
            File cd = new File(c.getFilesDir(), "covers");
            cd.mkdirs();
            File cf = new File(cd, id + ".jpg");
            FileOutputStream fo = new FileOutputStream(cf);
            try { cover.compress(Bitmap.CompressFormat.JPEG, 85, fo); } finally { fo.close(); }
            cover.recycle();
            e.cover = cf.getAbsolutePath();
        }
        put(c, e);
        return e;
    }

    /** Saves a cover image for an entry; returns its path or null. */
    public static String saveCover(Context c, String id, byte[] data) {
        try {
            Bitmap b = decodeScaled(data, 360);
            if (b == null) return null;
            File cd = new File(c.getFilesDir(), "covers");
            cd.mkdirs();
            File cf = new File(cd, id + ".jpg");
            FileOutputStream fo = new FileOutputStream(cf);
            try { b.compress(Bitmap.CompressFormat.JPEG, 85, fo); } finally { fo.close(); }
            b.recycle();
            return cf.getAbsolutePath();
        } catch (Exception e) {
            return null;
        }
    }

    static Bitmap decodeScaled(byte[] data, int maxW) {
        BitmapFactory.Options o = new BitmapFactory.Options();
        o.inJustDecodeBounds = true;
        BitmapFactory.decodeByteArray(data, 0, data.length, o);
        if (o.outWidth <= 0) return null;
        int s = 1;
        while (o.outWidth / (s * 2) >= maxW) s *= 2;
        o = new BitmapFactory.Options();
        o.inSampleSize = s;
        return BitmapFactory.decodeByteArray(data, 0, data.length, o);
    }

    private static Bitmap pdfThumb(File f) throws Exception {
        ParcelFileDescriptor pfd = ParcelFileDescriptor.open(f, ParcelFileDescriptor.MODE_READ_ONLY);
        PdfRenderer r = new PdfRenderer(pfd);
        try {
            if (r.getPageCount() == 0) throw new Exception("PDF 没有页面");
            PdfRenderer.Page p = r.openPage(0);
            int w = 360, h = Math.max(1, (int) (360f * p.getHeight() / Math.max(1, p.getWidth())));
            Bitmap bm = Bitmap.createBitmap(w, Math.min(h, 1200), Bitmap.Config.ARGB_8888);
            bm.eraseColor(Color.WHITE);
            p.render(bm, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY);
            p.close();
            return bm;
        } finally {
            r.close();
            pfd.close();
        }
    }
}

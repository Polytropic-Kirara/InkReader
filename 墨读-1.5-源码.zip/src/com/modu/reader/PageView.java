package com.modu.reader;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ValueAnimator;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.GradientDrawable;
import android.os.BatteryManager;
import android.text.Layout;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.StaticLayout;
import android.text.TextPaint;
import android.text.TextUtils;
import android.text.style.AlignmentSpan;
import android.text.style.ImageSpan;
import android.text.style.RelativeSizeSpan;
import android.text.style.StyleSpan;
import android.util.TypedValue;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.animation.DecelerateInterpolator;

import com.modu.reader.core.Block;
import com.modu.reader.core.Book;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Paginated reader with animated page turns. Pages come from the current view size, so a resize
 * (split screen, freeform window, rotation) re-paginates while keeping the reading position.
 */
public class PageView extends View {
    public interface Host {
        void onCenterTap();
        void onPageShown();
        void onBoundary(boolean atEnd);
    }

    public static final int END = Integer.MAX_VALUE;
    public static final int ANIM_CURL = 0, ANIM_COVER = 1, ANIM_SLIDE = 2, ANIM_NONE = 3, ANIM_SCROLL = 4;
    private static final int SPAN = Spanned.SPAN_EXCLUSIVE_EXCLUSIVE;

    private static final class Chap {
        int index;
        StaticLayout layout;
        int[] pages;
        SpannableStringBuilder text;
        int[] blockStart, blockEnd; // char range of each block (-1 when not shown)
        int height;
    }

    private Host host;
    private Book book;
    private Chap cur;
    private final HashMap<Integer, Chap> cache = new HashMap<Integer, Chap>();
    private int page;
    private int pendingChapter = -1, pendingOffset;
    private String message = "";

    private final TextPaint paint = new TextPaint(Paint.ANTI_ALIAS_FLAG);
    private final TextPaint info = new TextPaint(Paint.ANTI_ALIAS_FLAG);
    private float textSizeSp = 19f, lineMult = 1.6f, paraGap = 0.4f;
    private int marginDp = 20;
    private int bg = 0xFFF5EDD6, fg = 0xFF3A3022;
    private int contentL, contentT, contentW, contentH;
    private boolean showInfo;
    private final HashMap<String, Bitmap> images = new HashMap<String, Bitmap>();

    // animation state
    private int animMode = ANIM_CURL;
    private Bitmap bmpA, bmpB;
    private int dir;              // 0 idle, +1 next, -1 prev
    private Chap tChap;
    private int tPage;
    private boolean decided, dragging, blocked;
    private int swipeDir;
    private float downX, downY, dragX, curlX, curlY;
    private VelocityTracker vt;
    private ValueAnimator anim;
    private boolean animComplete;
    private final Curl curl = new Curl();
    private final GradientDrawable coverShadow = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
            new int[]{0x50000000, 0x00000000});

    // scroll mode
    private float scrollY;            // top of the view, in px from the top of the current chapter
    private final android.widget.OverScroller scroller;
    private int scrollerLast;
    private boolean scrollDrag, boundaryShown;
    private float lastY;

    // read-aloud highlight
    private int hlChapter = -1, hlBlock = -1;
    private android.text.style.BackgroundColorSpan hlSpan;
    private int hlColor = 0x40C8792F;

    private final int slop;
    private String clock = "";
    private int battery = -1;
    private long infoTime;

    public PageView(Context c) {
        super(c);
        slop = ViewConfiguration.get(c).getScaledTouchSlop();
        scroller = new android.widget.OverScroller(c);
        info.setTextSize(TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, 11.5f, getResources().getDisplayMetrics()));
        applyPaint();
    }

    public void setHost(Host h) { host = h; }

    public void setMessage(String m) {
        message = m == null ? "" : m;
        invalidate();
    }

    public void setAnimMode(int m) {
        cancelAnim();
        boolean changed = (m == ANIM_SCROLL) != (animMode == ANIM_SCROLL);
        animMode = m;
        if (changed) relayoutKeep();
    }

    private boolean scrollMode() { return animMode == ANIM_SCROLL; }

    public void setHighlightColor(int c) { hlColor = c; }

    // ---- settings ----------------------------------------------------------------------

    public void setStyle(float sizeSp, float mult, float gap, int margin, Typeface tf) {
        textSizeSp = sizeSp;
        lineMult = mult;
        paraGap = gap;
        marginDp = margin;
        paint.setTypeface(tf);
        applyPaint();
        relayoutKeep();
    }

    public void setColors(int background, int foreground) {
        bg = background;
        fg = foreground;
        applyPaint();
        coverShadow.setColors(new int[]{Theme.luminance(bg) < 0.3f ? 0x90000000 : 0x50000000, 0x00000000});
        curl.setPaper(bg);
        invalidate();
    }

    private void applyPaint() {
        paint.setTextSize(TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, textSizeSp, getResources().getDisplayMetrics()));
        paint.setColor(fg);
        info.setColor(Theme.alpha(fg, 0.6f));
    }

    // ---- position ----------------------------------------------------------------------

    public void setBook(Book b, int ch, int offset) {
        cancelAnim();
        book = b;
        cur = null;
        cache.clear();
        clearImages();
        pendingChapter = Math.max(0, Math.min(ch, b.chapterCount() - 1));
        pendingOffset = offset;
        if (ensureLayout()) shown(); else invalidate();
    }

    public Book getBook() { return book; }
    public int getChapter() { return cur != null ? cur.index : Math.max(0, pendingChapter); }

    public int currentOffset() {
        if (cur == null) return pendingOffset;
        if (scrollMode()) {
            int line = cur.layout.getLineForVertical((int) Math.max(0, Math.min(scrollY, cur.height - 1)));
            return cur.layout.getLineStart(line);
        }
        return cur.layout.getLineStart(cur.pages[Math.min(page, cur.pages.length - 1)]);
    }

    public float progress() {
        if (cur == null) return 0f;
        if (scrollMode()) {
            if (book.chapterCount() == 0) return 0f;
            float inside = cur.height <= contentH ? 1f : Math.max(0f, Math.min(1f, (scrollY + contentH) / cur.height));
            return Math.min(1f, (cur.index + inside) / book.chapterCount());
        }
        return progressFor(cur, page);
    }

    /** Index of the block shown at the top of the screen (for starting read-aloud). */
    public int currentBlock() {
        if (cur == null) return 0;
        int off = currentOffset();
        for (int i = 0; i < cur.blockStart.length; i++) if (cur.blockStart[i] >= 0 && cur.blockEnd[i] > off) return i;
        return 0;
    }

    /** Highlights a block (read-aloud) and brings it into view, turning pages or chapters as needed. */
    public void highlight(int chapter, int block) {
        if (book == null || cur == null) return;
        if (chapter != cur.index) {
            cancelAnim();
            Chap c = chapAt(chapter);
            commit(c, 0);
            if (scrollMode()) scrollY = 0;
        }
        clearHighlightSpan();
        hlChapter = chapter;
        hlBlock = block;
        if (block < 0 || block >= cur.blockStart.length || cur.blockStart[block] < 0) { invalidate(); return; }
        int a = cur.blockStart[block], b = Math.max(a, cur.blockEnd[block] - 1);
        hlSpan = new android.text.style.BackgroundColorSpan(hlColor);
        cur.text.setSpan(hlSpan, a, b, SPAN);
        if (scrollMode()) {
            float top = cur.layout.getLineTop(cur.layout.getLineForOffset(a));
            float bottom = cur.layout.getLineBottom(cur.layout.getLineForOffset(b));
            if (top < scrollY || bottom > scrollY + contentH * 0.85f) {
                scroller.forceFinished(true);
                int target = (int) Math.max(0, top - contentH * 0.2f);
                scrollerLast = (int) scrollY;
                scroller.startScroll(0, (int) scrollY, 0, (int) (target - scrollY), 450);
                postInvalidateOnAnimation();
            }
        } else if (dir == 0) {
            int p = pageFor(cur, a);
            int end = p + 1 < cur.pages.length ? cur.layout.getLineStart(cur.pages[p + 1]) : cur.text.length();
            if (p != page) { page = p; shown(); }
            else if (b >= end && p + 1 < cur.pages.length) { page = p + 1; shown(); }
        }
        invalidate();
    }

    public void clearHighlight() {
        clearHighlightSpan();
        hlChapter = hlBlock = -1;
        invalidate();
    }

    private void clearHighlightSpan() {
        if (hlSpan != null) for (Chap c : cache.values()) c.text.removeSpan(hlSpan);
        if (hlSpan != null && cur != null) cur.text.removeSpan(hlSpan);
        hlSpan = null;
    }

    private float progressFor(Chap c, int p) {
        if (book == null || book.chapterCount() == 0) return 0f;
        return Math.min(1f, (c.index + (p + 1f) / c.pages.length) / book.chapterCount());
    }

    public void gotoChapter(int ch) {
        if (book == null || ch < 0 || ch >= book.chapterCount() || cur == null) return;
        cancelAnim();
        scroller.forceFinished(true);
        scrollY = 0;
        commit(chapAt(ch), 0);
    }

    public void next() { turn(1); }
    public void prev() { turn(-1); }

    private boolean ensureLayout() {
        if (book == null || getWidth() == 0 || getHeight() == 0) return false;
        if (cur == null && pendingChapter >= 0) {
            computeArea();
            cur = build(pendingChapter);
            cache.put(cur.index, cur);
            page = pageFor(cur, pendingOffset);
            if (scrollMode()) {
                int off = Math.min(pendingOffset, Math.max(0, cur.text.length() - 1));
                scrollY = pendingOffset == END ? Math.max(0, cur.height - contentH) : cur.layout.getLineTop(cur.layout.getLineForOffset(off));
            }
            pendingChapter = -1;
            if (hlChapter == cur.index && hlBlock >= 0) { int c = hlChapter, b = hlBlock; hlChapter = -1; highlight(c, b); }
        }
        return cur != null;
    }

    private void relayoutKeep() {
        cancelAnim();
        if (cur != null) {
            pendingChapter = cur.index;
            pendingOffset = currentOffset();
            clearHighlightSpan();
            cur = null;
            cache.clear();
        }
        scroller.forceFinished(true);
        if (ensureLayout()) shown(); else invalidate();
    }

    @Override protected void onSizeChanged(int w, int h, int ow, int oh) {
        super.onSizeChanged(w, h, ow, oh);
        curl.setSize(w, h);
        recycleBitmaps();
        relayoutKeep();
    }

    private void shown() {
        invalidate();
        if (host != null) host.onPageShown();
    }

    private Chap chapAt(int index) {
        if (cur != null && cur.index == index) return cur;
        Chap c = cache.get(index);
        if (c == null) {
            c = build(index);
            cache.put(index, c);
        }
        return c;
    }

    private boolean target(int d) {
        if (cur == null) return false;
        if (d > 0) {
            if (page < cur.pages.length - 1) { tChap = cur; tPage = page + 1; return true; }
            if (cur.index < book.chapterCount() - 1) { tChap = chapAt(cur.index + 1); tPage = 0; return true; }
        } else {
            if (page > 0) { tChap = cur; tPage = page - 1; return true; }
            if (cur.index > 0) { tChap = chapAt(cur.index - 1); tPage = tChap.pages.length - 1; return true; }
        }
        return false;
    }

    private void commit(Chap c, int p) {
        if (c != cur) {
            cur = c;
            cache.put(c.index, c);
            // keep nearby chapters only
            java.util.Iterator<Integer> it = cache.keySet().iterator();
            while (it.hasNext()) { int k = it.next(); if (k < c.index - 1 || k > c.index + 3) it.remove(); }
            trimImages();
        }
        page = Math.max(0, Math.min(p, c.pages.length - 1));
        shown();
    }

    // ---- layout ------------------------------------------------------------------------

    private void computeArea() {
        float d = getResources().getDisplayMetrics().density;
        int w = getWidth(), h = getHeight();
        int margin = (int) (marginDp * d);
        if (w < 340 * d) margin = Math.min(margin, (int) (12 * d));
        showInfo = h > 240 * d;
        int band = showInfo ? (int) (30 * d) : (int) (10 * d);
        contentL = margin;
        contentW = Math.max(40, w - 2 * margin);
        contentT = band;
        contentH = Math.max(40, h - 2 * band);
    }

    private Chap build(int index) {
        List<Block> blocks;
        try {
            blocks = book.chapter(index);
        } catch (Throwable t) {
            blocks = new ArrayList<Block>();
            blocks.add(new Block(Block.PARA, "本章加载失败：" + t.getMessage()));
        }
        Chap c = new Chap();
        c.blockStart = new int[blocks.size()];
        c.blockEnd = new int[blocks.size()];
        SpannableStringBuilder text = buildText(blocks, index, c);
        c.text = text;
        c.index = index;
        c.layout = StaticLayout.Builder.obtain(text, 0, text.length(), paint, contentW)
                .setLineSpacing(0f, lineMult)
                .setIncludePad(false)
                .setBreakStrategy(Layout.BREAK_STRATEGY_SIMPLE)
                .setHyphenationFrequency(Layout.HYPHENATION_FREQUENCY_NONE)
                .build();
        ArrayList<Integer> pages = new ArrayList<Integer>();
        int n = c.layout.getLineCount(), line = 0;
        while (line < n) {
            pages.add(line);
            int top = c.layout.getLineTop(line), l = line;
            while (l < n && c.layout.getLineBottom(l) - top <= contentH) l++;
            if (l == line) l++;
            line = l;
        }
        if (pages.isEmpty()) pages.add(0);
        c.height = c.layout.getHeight();
        c.pages = new int[pages.size()];
        for (int i = 0; i < c.pages.length; i++) c.pages[i] = pages.get(i);
        return c;
    }

    private int pageFor(Chap c, int offset) {
        if (offset == END) return c.pages.length - 1;
        int p = 0;
        for (int i = 0; i < c.pages.length; i++) {
            if (c.layout.getLineStart(c.pages[i]) <= offset) p = i;
            else break;
        }
        return p;
    }

    private SpannableStringBuilder buildText(List<Block> list, int chapter, Chap out) {
        SpannableStringBuilder sb = new SpannableStringBuilder();
        for (int bi = 0; bi < list.size(); bi++) {
            Block b = list.get(bi);
            out.blockStart[bi] = -1;
            out.blockEnd[bi] = -1;
            int s = sb.length();
            if (b.type == Block.HEADING) {
                if (s > 0) gap(sb, 0.7f);
                s = sb.length();
                sb.append(b.text).append('\n');
                out.blockStart[bi] = s;
                out.blockEnd[bi] = sb.length();
                sb.setSpan(new RelativeSizeSpan(1.3f), s, sb.length(), SPAN);
                sb.setSpan(new StyleSpan(Typeface.BOLD), s, sb.length(), SPAN);
                sb.setSpan(new AlignmentSpan.Standard(Layout.Alignment.ALIGN_CENTER), s, sb.length(), SPAN);
                gap(sb, 0.9f);
            } else if (b.type == Block.PARA) {
                sb.append("　　").append(b.text).append('\n');
                out.blockStart[bi] = s;
                out.blockEnd[bi] = sb.length();
                if (paraGap > 0.01f) gap(sb, paraGap);
            } else {
                BitmapDrawable d = image(chapter, b.text);
                if (d == null) continue;
                sb.append('￼');
                sb.setSpan(new ImageSpan(d, ImageSpan.ALIGN_BOTTOM), s, s + 1, SPAN);
                sb.append('\n');
                sb.setSpan(new AlignmentSpan.Standard(Layout.Alignment.ALIGN_CENTER), s, sb.length(), SPAN);
                if (paraGap > 0.01f) gap(sb, paraGap);
            }
        }
        if (sb.length() == 0) sb.append(" ");
        return sb;
    }

    private static void gap(SpannableStringBuilder sb, float size) {
        int s = sb.length();
        sb.append('\n');
        sb.setSpan(new RelativeSizeSpan(size), s, s + 1, SPAN);
    }

    private BitmapDrawable image(int chapter, String ref) {
        String key = chapter + "|" + ref;
        int maxW = contentW, maxH = (int) (contentH * 0.9f / lineMult);
        Bitmap bm = images.get(key);
        if (bm == null && !images.containsKey(key)) {
            byte[] data = null;
            try { data = book.image(chapter, ref); } catch (Throwable ignored) {}
            if (data != null) {
                try {
                    BitmapFactory.Options o = new BitmapFactory.Options();
                    o.inJustDecodeBounds = true;
                    BitmapFactory.decodeByteArray(data, 0, data.length, o);
                    int sample = 1;
                    while (o.outWidth / (sample * 2) >= maxW && o.outHeight / (sample * 2) >= maxH) sample *= 2;
                    while (o.outWidth / sample > 4096 || o.outHeight / sample > 4096) sample *= 2;
                    o = new BitmapFactory.Options();
                    o.inSampleSize = sample;
                    bm = BitmapFactory.decodeByteArray(data, 0, data.length, o);
                } catch (Throwable t) {
                    bm = null;
                }
            }
            images.put(key, bm);
        }
        if (bm == null) return null;
        float dens = getResources().getDisplayMetrics().density;
        float w = bm.getWidth() * dens / 1.5f, h = bm.getHeight() * dens / 1.5f;
        float scale = (w >= maxW * 0.4f) ? Math.min(maxW / w, maxH / h) : Math.min(1f, Math.min(maxW / w, maxH / h));
        BitmapDrawable d = new BitmapDrawable(getResources(), bm);
        d.setBounds(0, 0, Math.max(1, (int) (w * scale)), Math.max(1, (int) (h * scale)));
        return d;
    }

    private void trimImages() {
        Iterator<Map.Entry<String, Bitmap>> it = images.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<String, Bitmap> e = it.next();
            int ch = Integer.parseInt(e.getKey().substring(0, e.getKey().indexOf('|')));
            boolean keep = (cur != null && cur.index == ch) || cache.containsKey(ch);
            if (!keep) {
                if (e.getValue() != null) e.getValue().recycle();
                it.remove();
            }
        }
    }

    private void clearImages() {
        for (Bitmap b : images.values()) if (b != null) b.recycle();
        images.clear();
    }

    // ---- drawing -----------------------------------------------------------------------

    @Override protected void onDraw(Canvas c) {
        if (!ensureLayout()) {
            c.drawColor(bg);
            if (message.length() > 0) {
                float tw = info.measureText(message);
                c.drawText(message, (getWidth() - tw) / 2f, getHeight() / 2f, info);
            }
            return;
        }
        if (scrollMode()) {
            drawScroll(c);
            return;
        }
        if (dir == 0 || bmpA == null || bmpB == null) {
            drawPage(c, cur, page);
            return;
        }
        int w = getWidth();
        switch (animMode) {
            case ANIM_CURL:
                if (dir > 0) curl.draw(c, bmpA, bmpB); else curl.draw(c, bmpB, bmpA);
                break;
            case ANIM_COVER:
                if (dir > 0) {
                    c.drawBitmap(bmpB, 0, 0, null);
                    c.drawBitmap(bmpA, dragX, 0, null);
                    shadowAt(c, w + dragX);
                } else {
                    c.drawBitmap(bmpA, 0, 0, null);
                    c.drawBitmap(bmpB, dragX - w, 0, null);
                    shadowAt(c, dragX);
                }
                break;
            default: // slide
                if (dir > 0) {
                    c.drawBitmap(bmpA, dragX, 0, null);
                    c.drawBitmap(bmpB, w + dragX, 0, null);
                } else {
                    c.drawBitmap(bmpB, dragX - w, 0, null);
                    c.drawBitmap(bmpA, dragX, 0, null);
                }
        }
    }

    private void shadowAt(Canvas c, float x) {
        int sw = (int) (18 * getResources().getDisplayMetrics().density);
        coverShadow.setBounds((int) x, 0, (int) x + sw, getHeight());
        coverShadow.draw(c);
    }

    private void drawPage(Canvas c, Chap ch, int p) {
        c.drawColor(bg);
        StaticLayout layout = ch.layout;
        int start = ch.pages[p];
        int endLine = p + 1 < ch.pages.length ? ch.pages[p + 1] : layout.getLineCount();
        int top = layout.getLineTop(start);
        int height = Math.min(contentH, layout.getLineTop(endLine) - top);
        c.save();
        c.clipRect(contentL, contentT, contentL + contentW, contentT + height);
        c.translate(contentL, contentT - top);
        layout.draw(c);
        c.restore();

        if (!showInfo) return;
        updateInfo();
        Paint.FontMetrics fm = info.getFontMetrics();
        float textH = fm.descent - fm.ascent;
        float headY = (contentT - textH) / 2f - fm.ascent;
        float footY = getHeight() - contentT + (contentT - textH) / 2f - fm.ascent;
        String head = book.displayTitle(ch.index);
        c.drawText(TextUtils.ellipsize(head, info, contentW, TextUtils.TruncateAt.END).toString(), contentL, headY, info);
        String left = (p + 1) + " / " + ch.pages.length;
        String right = String.format(Locale.US, "%.1f%%", progressFor(ch, p) * 100f)
                + "   " + clock + (battery >= 0 ? "   " + battery + "%" : "");
        c.drawText(left, contentL, footY, info);
        float rw = info.measureText(right);
        if (rw + info.measureText(left) + 24 < contentW) c.drawText(right, contentL + contentW - rw, footY, info);
    }

    private void updateInfo() {
        long now = System.currentTimeMillis();
        if (now - infoTime < 20000 && clock.length() > 0) return;
        infoTime = now;
        clock = new SimpleDateFormat("HH:mm", Locale.getDefault()).format(new Date(now));
        try {
            Intent bat = getContext().registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
            if (bat != null) {
                int level = bat.getIntExtra(BatteryManager.EXTRA_LEVEL, -1), scale = bat.getIntExtra(BatteryManager.EXTRA_SCALE, 100);
                battery = level < 0 ? -1 : level * 100 / Math.max(1, scale);
            }
        } catch (Throwable ignored) {
            battery = -1;
        }
    }

    // ---- page turning ------------------------------------------------------------------

    private boolean ensureBitmaps() {
        int w = getWidth(), h = getHeight();
        try {
            if (bmpA == null || bmpA.getWidth() != w || bmpA.getHeight() != h) {
                recycleBitmaps();
                bmpA = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
                bmpB = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
            }
            return true;
        } catch (Throwable t) {
            recycleBitmaps();
            return false;
        }
    }

    private void recycleBitmaps() {
        if (bmpA != null) bmpA.recycle();
        if (bmpB != null) bmpB.recycle();
        bmpA = bmpB = null;
    }

    /** Renders both pages for an animated turn. Returns false at the book boundary. */
    private boolean prepare(int d) {
        if (!target(d)) {
            if (host != null) host.onBoundary(d > 0);
            return false;
        }
        if (animMode == ANIM_NONE || !ensureBitmaps()) return true;
        drawPage(new Canvas(bmpA), cur, page);
        drawPage(new Canvas(bmpB), tChap, tPage);
        dir = d;
        curl.setPaper(bg);
        return true;
    }

    private void turn(int d) {
        if (cur == null) return;
        if (scrollMode()) { scrollPage(d); return; }
        if (anim != null && anim.isRunning()) anim.end();
        if (!prepare(d)) return;
        if (dir == 0) { commit(tChap, tPage); tChap = null; return; } // no animation
        int w = getWidth(), h = getHeight();
        if (animMode == ANIM_CURL) {
            if (d > 0) {
                curl.setFlat(false);
                curl.setCorner(w, h);
                curlX = w - 1;
                curlY = h * 0.9f;
            } else {
                curl.setFlat(true);
                curl.setCorner(w, h);
                curlX = -w;
                curlY = h;
            }
            curl.setTouch(curlX, curlY);
        } else {
            dragX = 0;
        }
        finishTurn(true, 0);
    }

    private void setupDrag(int d) {
        int w = getWidth(), h = getHeight();
        if (animMode == ANIM_CURL) {
            boolean flat = d < 0 || (downY > h / 3f && downY < h * 2f / 3f);
            curl.setFlat(flat);
            curl.setCorner(w, flat || downY >= h / 2f ? h : 0);
        }
        dragTo(downX, downY);
    }

    private void dragTo(float x, float y) {
        int w = getWidth();
        float dx = x - downX;
        if (animMode == ANIM_CURL) {
            if (dir > 0) curlX = Math.max(-w, Math.min(w - 1, w + dx * 1.6f));
            else curlX = Math.max(-w, Math.min(w - 1, -w + dx * 2f));
            curlY = y;
            curl.setTouch(curlX, curlY);
        } else {
            dragX = dir > 0 ? Math.max(-w, Math.min(0, dx)) : Math.max(0, Math.min(w, dx));
        }
        invalidate();
    }

    private void finishTurn(boolean complete, float velocity) {
        final int w = getWidth(), h = getHeight();
        animComplete = complete;
        final float fromX, fromY, toX, toY;
        if (animMode == ANIM_CURL) {
            fromX = curlX;
            fromY = curlY;
            if (dir > 0) {
                toX = complete ? -w : w - 1;
                toY = curl.cornerY() == 0 ? 1 : h - 1;
            } else {
                toX = complete ? w - 1 : -w;
                toY = h;
            }
        } else {
            fromX = dragX;
            fromY = 0;
            toX = complete ? (dir > 0 ? -w : w) : 0;
            toY = 0;
        }
        float dist = Math.abs(toX - fromX) / (animMode == ANIM_CURL ? 2f * w : w);
        long dur = (long) (160 + 360 * Math.min(1f, dist));
        if (Math.abs(velocity) > 2500) dur = (long) (dur * 0.7f);
        anim = ValueAnimator.ofFloat(0f, 1f);
        anim.setDuration(dur);
        anim.setInterpolator(new DecelerateInterpolator(1.4f));
        anim.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override public void onAnimationUpdate(ValueAnimator a) {
                float t = (Float) a.getAnimatedValue();
                if (animMode == ANIM_CURL) {
                    curlX = fromX + (toX - fromX) * t;
                    curlY = fromY + (toY - fromY) * t;
                    curl.setTouch(curlX, curlY);
                } else {
                    dragX = fromX + (toX - fromX) * t;
                }
                invalidate();
            }
        });
        anim.addListener(new AnimatorListenerAdapter() {
            private boolean done;
            @Override public void onAnimationEnd(Animator a) {
                if (done) return;
                done = true;
                endTurn();
            }
        });
        anim.start();
    }

    private void endTurn() {
        boolean complete = animComplete && tChap != null;
        Chap t = tChap;
        int tp = tPage;
        dir = 0;
        dragging = false;
        tChap = null;
        anim = null;
        if (complete) commit(t, tp); else invalidate();
    }

    private void cancelAnim() {
        if (anim != null) {
            anim.removeAllListeners();
            anim.removeAllUpdateListeners();
            anim.cancel();
            anim = null;
        }
        dir = 0;
        dragging = false;
        tChap = null;
    }

    // ---- touch -------------------------------------------------------------------------

    @Override public boolean onTouchEvent(MotionEvent e) {
        if (cur == null) return true;
        if (scrollMode()) return scrollTouch(e);
        float x = e.getX(), y = e.getY();
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                if (anim != null && anim.isRunning()) anim.end();
                downX = x;
                downY = y;
                decided = dragging = blocked = false;
                swipeDir = 0;
                if (vt != null) vt.recycle();
                vt = VelocityTracker.obtain();
                vt.addMovement(e);
                return true;
            case MotionEvent.ACTION_MOVE:
                if (vt != null) vt.addMovement(e);
                if (!decided) {
                    float dx = x - downX, dy = y - downY;
                    if (Math.abs(dx) > slop && Math.abs(dx) > Math.abs(dy)) {
                        decided = true;
                        swipeDir = dx < 0 ? 1 : -1;
                        if (prepare(swipeDir)) {
                            if (dir != 0) {
                                dragging = true;
                                setupDrag(swipeDir);
                            } // else: no-animation mode, the turn is committed on finger up
                        } else {
                            blocked = true;
                        }
                    } else if (Math.abs(dy) > slop * 3) {
                        decided = true;
                        blocked = true;
                    }
                }
                if (dragging) dragTo(x, y);
                return true;
            case MotionEvent.ACTION_UP: {
                float vx = 0;
                if (vt != null) {
                    vt.addMovement(e);
                    vt.computeCurrentVelocity(1000);
                    vx = vt.getXVelocity();
                    vt.recycle();
                    vt = null;
                }
                int w = getWidth();
                float dx = x - downX;
                if (dragging) {
                    boolean complete = dir > 0
                            ? (vx < -600 || (vx < 300 && dx < -w * 0.12f))
                            : (vx > 600 || (vx > -300 && dx > w * 0.12f));
                    finishTurn(complete, vx);
                } else if (!decided) {
                    performClick();
                    if (x < w / 3f) turn(-1);
                    else if (x > w * 2f / 3f) turn(1);
                    else if (host != null) host.onCenterTap();
                } else if (!blocked && swipeDir != 0 && tChap != null) {
                    commit(tChap, tPage); // no-animation mode swipe
                    tChap = null;
                }
                return true;
            }
            case MotionEvent.ACTION_CANCEL:
                if (vt != null) { vt.recycle(); vt = null; }
                if (dragging) finishTurn(false, 0);
                return true;
        }
        return true;
    }

    // ---- scroll mode -------------------------------------------------------------------

    private float gapPx() {
        return paint.getFontSpacing() * lineMult * 2.2f;
    }

    /** Moves the reading position between chapters as the view scrolls past their ends. */
    private void normalize() {
        boolean changed = false;
        while (scrollY < 0 && cur.index > 0) {
            Chap p = chapAt(cur.index - 1);
            scrollY += p.height + gapPx();
            commitQuiet(p);
            changed = true;
        }
        while (scrollY >= cur.height + gapPx() && cur.index < book.chapterCount() - 1) {
            scrollY -= cur.height + gapPx();
            commitQuiet(chapAt(cur.index + 1));
            changed = true;
        }
        if (scrollY < 0) scrollY = 0;
        float max = maxScroll();
        if (scrollY > max) {
            scrollY = max;
            if (!boundaryShown && scrollDrag) { boundaryShown = true; if (host != null) host.onBoundary(true); }
            scroller.forceFinished(true);
        }
        if (changed && host != null) host.onPageShown();
    }

    private void commitQuiet(Chap c) {
        cur = c;
        cache.put(c.index, c);
        java.util.Iterator<Integer> it = cache.keySet().iterator();
        while (it.hasNext()) { int k = it.next(); if (k < c.index - 1 || k > c.index + 3) it.remove(); }
        trimImages();
    }

    /** Largest scrollY in the current chapter's coordinates (only limited when the book's end is in reach). */
    private float maxScroll() {
        float acc = cur.height;
        Chap c = cur;
        while (c.index < book.chapterCount() - 1 && acc - scrollY < contentH * 2) {
            c = chapAt(c.index + 1);
            acc += gapPx() + c.height;
        }
        if (c.index < book.chapterCount() - 1) return Float.MAX_VALUE;
        return Math.max(0, acc - contentH);
    }

    private void drawScroll(Canvas c) {
        c.drawColor(bg);
        c.save();
        c.clipRect(contentL, contentT, contentL + contentW, contentT + contentH);
        float y = contentT - scrollY;
        Chap ch = cur;
        if (y > contentT && ch.index > 0) { // previous chapter peeking in at the top
            Chap p = chapAt(ch.index - 1);
            c.save();
            c.translate(contentL, y - gapPx() - p.height);
            p.layout.draw(c);
            c.restore();
        }
        while (true) {
            c.save();
            c.translate(contentL, y);
            ch.layout.draw(c);
            c.restore();
            y += ch.height + gapPx();
            if (y >= contentT + contentH || ch.index >= book.chapterCount() - 1) break;
            ch = chapAt(ch.index + 1);
        }
        c.restore();
        if (!showInfo) return;
        updateInfo();
        Paint.FontMetrics fm = info.getFontMetrics();
        float textH = fm.descent - fm.ascent;
        float headY = (contentT - textH) / 2f - fm.ascent;
        float footY = getHeight() - contentT + (contentT - textH) / 2f - fm.ascent;
        c.drawText(TextUtils.ellipsize(book.displayTitle(cur.index), info, contentW, TextUtils.TruncateAt.END).toString(), contentL, headY, info);
        String left = (cur.index + 1) + " / " + book.chapterCount() + " 章";
        String right = String.format(Locale.US, "%.1f%%", progress() * 100f) + "   " + clock + (battery >= 0 ? "   " + battery + "%" : "");
        c.drawText(left, contentL, footY, info);
        float rw = info.measureText(right);
        if (rw + info.measureText(left) + 24 < contentW) c.drawText(right, contentL + contentW - rw, footY, info);
    }

    private void scrollPage(int d) {
        scroller.forceFinished(true);
        float dist = (contentH - paint.getFontSpacing() * lineMult) * d;
        if (d > 0 && scrollY >= maxScroll() - 1) { if (host != null) host.onBoundary(true); return; }
        if (d < 0 && scrollY <= 0 && cur.index == 0) { if (host != null) host.onBoundary(false); return; }
        scrollerLast = 0;
        scroller.startScroll(0, 0, 0, (int) dist, 380);
        scrollerLast = 0;
        boundaryShown = false;
        postInvalidateOnAnimation();
    }

    @Override public void computeScroll() {
        if (!scrollMode() || cur == null) return;
        if (scroller.computeScrollOffset()) {
            int y = scroller.getCurrY();
            scrollY += y - scrollerLast;
            scrollerLast = y;
            normalize();
            postInvalidateOnAnimation();
            if (scroller.isFinished() && host != null) host.onPageShown();
        }
    }

    private boolean scrollTouch(MotionEvent e) {
        float x = e.getX(), y = e.getY();
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                scroller.forceFinished(true);
                downX = x;
                downY = lastY = y;
                scrollDrag = false;
                boundaryShown = false;
                if (vt != null) vt.recycle();
                vt = VelocityTracker.obtain();
                vt.addMovement(e);
                return true;
            case MotionEvent.ACTION_MOVE:
                if (vt != null) vt.addMovement(e);
                if (!scrollDrag && Math.abs(y - downY) > slop) scrollDrag = true;
                if (scrollDrag) {
                    scrollY += lastY - y;
                    normalize();
                    invalidate();
                }
                lastY = y;
                return true;
            case MotionEvent.ACTION_UP: {
                float vy = 0;
                if (vt != null) {
                    vt.addMovement(e);
                    vt.computeCurrentVelocity(1000);
                    vy = vt.getYVelocity();
                    vt.recycle();
                    vt = null;
                }
                if (scrollDrag) {
                    if (Math.abs(vy) > ViewConfiguration.get(getContext()).getScaledMinimumFlingVelocity()) {
                        scrollerLast = 0;
                        scroller.fling(0, 0, 0, (int) -vy, 0, 0, -10000000, 10000000);
                        postInvalidateOnAnimation();
                    } else if (host != null) host.onPageShown();
                } else if (Math.abs(x - downX) < slop && Math.abs(y - downY) < slop) {
                    performClick();
                    float h = getHeight();
                    if (y < h / 3f) scrollPage(-1);
                    else if (y > h * 2f / 3f) scrollPage(1);
                    else if (host != null) host.onCenterTap();
                }
                scrollDrag = false;
                return true;
            }
            case MotionEvent.ACTION_CANCEL:
                scrollDrag = false;
                if (vt != null) { vt.recycle(); vt = null; }
                return true;
        }
        return true;
    }

    @Override public boolean performClick() {
        return super.performClick();
    }
}

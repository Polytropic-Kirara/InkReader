package com.modu.reader;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PointF;
import android.graphics.Region;
import android.graphics.drawable.GradientDrawable;

/**
 * Page-curl ("仿真翻页") geometry and drawing. The front page is peeled from a corner towards
 * the touch point; inside the peeled area we see the back of the page (mirrored, faded) and
 * the page underneath. Only INTERSECT / DIFFERENCE clip ops are used (others throw on API 28+).
 */
final class Curl {
    private float w, h;
    private float cornerX, cornerY;
    private final PointF touch = new PointF();
    private final PointF c1 = new PointF(), c2 = new PointF();   // bezier controls
    private final PointF s1 = new PointF(), s2 = new PointF();   // bezier starts (on page edges)
    private final PointF e1 = new PointF(), e2 = new PointF();   // bezier ends (on fold edges)
    private final PointF v1 = new PointF(), v2 = new PointF();   // bezier vertices
    private float mx, my, degrees, touchToCorner, maxLength;
    private boolean rtlb; // corner is top-right or bottom-left
    private boolean flat; // vertical fold (drag from the middle, or turning back)
    private final GradientDrawable shadeLR = gd(GradientDrawable.Orientation.LEFT_RIGHT, new int[]{0x77111111, 0x00111111});
    private final GradientDrawable shadeRL = gd(GradientDrawable.Orientation.RIGHT_LEFT, new int[]{0x55222222, 0x00222222});
    private final GradientDrawable edgeLR = gd(GradientDrawable.Orientation.LEFT_RIGHT, new int[]{0x30222222, 0x00222222});
    private final GradientDrawable castRL = gd(GradientDrawable.Orientation.RIGHT_LEFT, new int[]{0x55111111, 0x00111111});

    private final Path path0 = new Path(), path1 = new Path();
    private final Matrix matrix = new Matrix();
    private final float[] m9 = {0, 0, 0, 0, 0, 0, 0, 0, 1f};
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
    private ColorMatrixColorFilter backFilter;
    private int backColor;

    private final GradientDrawable folderLR, folderRL, backLR, backRL, frontVLR, frontVRL, frontHTB, frontHBT;

    Curl() {
        int[] folder = {0x00333333, 0xB0333333};
        folderRL = gd(GradientDrawable.Orientation.RIGHT_LEFT, folder);
        folderLR = gd(GradientDrawable.Orientation.LEFT_RIGHT, folder);
        int[] back = {0xFF111111, 0x00111111};
        backRL = gd(GradientDrawable.Orientation.RIGHT_LEFT, back);
        backLR = gd(GradientDrawable.Orientation.LEFT_RIGHT, back);
        int[] front = {0x80111111, 0x00111111};
        frontVLR = gd(GradientDrawable.Orientation.LEFT_RIGHT, front);
        frontVRL = gd(GradientDrawable.Orientation.RIGHT_LEFT, front);
        frontHTB = gd(GradientDrawable.Orientation.TOP_BOTTOM, front);
        frontHBT = gd(GradientDrawable.Orientation.BOTTOM_TOP, front);
    }

    private static GradientDrawable gd(GradientDrawable.Orientation o, int[] colors) {
        GradientDrawable g = new GradientDrawable(o, colors);
        g.setGradientType(GradientDrawable.LINEAR_GRADIENT);
        return g;
    }

    void setSize(int width, int height) {
        w = width;
        h = height;
        maxLength = (float) Math.hypot(w, h);
    }

    /** Back of the page: a washed-out mirror image tinted towards the paper color. */
    void setPaper(int color) {
        if (backFilter != null && color == backColor) return;
        backColor = color;
        float r = (color >> 16) & 0xFF, g = (color >> 8) & 0xFF, b = color & 0xFF;
        float k = 0.35f; // how much of the mirrored text shows through
        backFilter = new ColorMatrixColorFilter(new ColorMatrix(new float[]{
                k, 0, 0, 0, r * (1 - k),
                0, k, 0, 0, g * (1 - k),
                0, 0, k, 0, b * (1 - k),
                0, 0, 0, 1, 0}));
    }

    void setFlat(boolean f) { flat = f; }

    void setCorner(float x, float y) {
        cornerX = x;
        cornerY = y;
        rtlb = (x == 0 && y == h) || (x == w && y == 0);
    }

    float cornerY() { return cornerY; }

    void setTouch(float x, float y) {
        if (flat) { touch.set(x, h); return; }
        // keep away from degenerate positions (division by zero in the bezier maths)
        if (Math.abs(y - cornerY) < 1f) y = cornerY == 0 ? 1f : cornerY - 1f;
        if (y < 0.5f) y = 0.5f;
        if (y > h - 0.5f) y = h - 0.5f;
        if (Math.abs(x - cornerX) < 1f) x = cornerX - 1f;
        touch.set(x, y);
        calc();
    }

    private void calc() {
        controls();
        if (touch.x > 0 && touch.x < w && (s1.x < 0 || s1.x > w)) {
            // fold would leave the page: pull the touch point back so the fold stays on the edge
            if (s1.x < 0) s1.x = w - s1.x;
            float f1 = Math.abs(cornerX - touch.x);
            float f2 = w * f1 / s1.x;
            touch.x = Math.abs(cornerX - f2);
            float f3 = Math.abs(cornerX - touch.x) * Math.abs(cornerY - touch.y) / f1;
            touch.y = Math.abs(cornerY - f3);
            if (Math.abs(touch.y - cornerY) < 1f) touch.y = cornerY == 0 ? 1f : cornerY - 1f;
            if (Math.abs(touch.x - cornerX) < 1f) touch.x = cornerX - 1f;
            controls();
        }
        s2.set(cornerX, c2.y - (cornerY - c2.y) / 2f);
        touchToCorner = (float) Math.hypot(touch.x - cornerX, touch.y - cornerY);
        cross(touch, c1, s1, s2, e1);
        cross(touch, c2, s1, s2, e2);
        v1.set((s1.x + 2 * c1.x + e1.x) / 4f, (2 * c1.y + s1.y + e1.y) / 4f);
        v2.set((s2.x + 2 * c2.x + e2.x) / 4f, (2 * c2.y + s2.y + e2.y) / 4f);
        degrees = (float) Math.toDegrees(Math.atan2(c1.x - cornerX, c2.y - cornerY));
    }

    private void controls() {
        mx = (touch.x + cornerX) / 2f;
        my = (touch.y + cornerY) / 2f;
        float dx = cornerX - mx, dy = cornerY - my;
        if (Math.abs(dx) < 0.01f) dx = dx < 0 ? -0.01f : 0.01f;
        if (Math.abs(dy) < 0.01f) dy = dy < 0 ? -0.01f : 0.01f;
        c1.set(mx - dy * dy / dx, cornerY);
        c2.set(cornerX, my - dx * dx / dy);
        s1.set(c1.x - (cornerX - c1.x) / 2f, cornerY);
    }

    /** Intersection of line p1-p2 with line p3-p4. */
    private static void cross(PointF p1, PointF p2, PointF p3, PointF p4, PointF out) {
        float a1 = (p2.y - p1.y) / nz(p2.x - p1.x), b1 = (p1.x * p2.y - p2.x * p1.y) / nz(p1.x - p2.x);
        float a2 = (p4.y - p3.y) / nz(p4.x - p3.x), b2 = (p3.x * p4.y - p4.x * p3.y) / nz(p3.x - p4.x);
        float x = (b2 - b1) / nz(a1 - a2);
        out.set(x, a1 * x + b1);
    }

    private static float nz(float v) {
        return Math.abs(v) < 1e-4f ? (v < 0 ? -1e-4f : 1e-4f) : v;
    }

    void draw(Canvas c, Bitmap front, Bitmap under) {
        if (flat) { drawFlat(c, front, under); return; }
        path0.reset();
        path0.moveTo(s1.x, s1.y);
        path0.quadTo(c1.x, c1.y, e1.x, e1.y);
        path0.lineTo(touch.x, touch.y);
        path0.lineTo(e2.x, e2.y);
        path0.quadTo(c2.x, c2.y, s2.x, s2.y);
        path0.lineTo(cornerX, cornerY);
        path0.close();

        // 1. flat part of the front page
        c.save();
        c.clipPath(path0, Region.Op.DIFFERENCE);
        c.drawBitmap(front, 0, 0, null);
        c.restore();

        // 2. page underneath, with a shadow along the fold
        path1.reset();
        path1.moveTo(s1.x, s1.y);
        path1.lineTo(v1.x, v1.y);
        path1.lineTo(v2.x, v2.y);
        path1.lineTo(s2.x, s2.y);
        path1.lineTo(cornerX, cornerY);
        path1.close();
        c.save();
        c.clipPath(path0);
        c.clipPath(path1, Region.Op.INTERSECT);
        c.drawBitmap(under, 0, 0, null);
        GradientDrawable back;
        int left, right;
        if (rtlb) { left = (int) s1.x; right = (int) (s1.x + touchToCorner / 4); back = backLR; }
        else { left = (int) (s1.x - touchToCorner / 4); right = (int) s1.x; back = backRL; }
        back.setAlpha(110);
        c.rotate(degrees, s1.x, s1.y);
        back.setBounds(left, (int) (s1.y - maxLength), right, (int) (s1.y + maxLength));
        back.draw(c);
        c.restore();

        // 3. shadow cast by the curled page onto the flat front page
        frontShadow(c);

        // 4. back side of the curled part
        int i = (int) (s1.x + c1.x) / 2;
        float f1 = Math.abs(i - c1.x);
        int i1 = (int) (s2.y + c2.y) / 2;
        float f2 = Math.abs(i1 - c2.y);
        float f3 = Math.min(f1, f2);
        path1.reset();
        path1.moveTo(v2.x, v2.y);
        path1.lineTo(v1.x, v1.y);
        path1.lineTo(e1.x, e1.y);
        path1.lineTo(touch.x, touch.y);
        path1.lineTo(e2.x, e2.y);
        path1.close();
        c.save();
        c.clipPath(path0);
        c.clipPath(path1, Region.Op.INTERSECT);
        c.drawColor(backColor);
        float dis = (float) Math.hypot(cornerX - c1.x, c2.y - cornerY);
        if (dis > 0.01f) {
            float f8 = (cornerX - c1.x) / dis, f9 = (c2.y - cornerY) / dis;
            m9[0] = 1 - 2 * f9 * f9;
            m9[1] = 2 * f8 * f9;
            m9[3] = m9[1];
            m9[4] = 1 - 2 * f8 * f8;
            matrix.reset();
            matrix.setValues(m9);
            matrix.preTranslate(-c1.x, -c1.y);
            matrix.postTranslate(c1.x, c1.y);
            paint.setColorFilter(backFilter);
            c.drawBitmap(front, matrix, paint);
            paint.setColorFilter(null);
        }
        GradientDrawable folder;
        int l2, r2;
        if (rtlb) { l2 = (int) (s1.x - 1); r2 = (int) (s1.x + f3 + 1); folder = folderLR; }
        else { l2 = (int) (s1.x - f3 - 1); r2 = (int) (s1.x + 1); folder = folderRL; }
        c.rotate(degrees, s1.x, s1.y);
        folder.setBounds(l2, (int) (s1.y - maxLength), r2, (int) (s1.y + maxLength));
        folder.draw(c);
        c.restore();
    }

    /** Vertical fold: front | mirrored back | page underneath. */
    private void drawFlat(Canvas c, Bitmap front, Bitmap under) {
        float tx = touch.x, f = (tx + w) / 2f, backW = f - tx;
        if (tx > 0) {
            c.save();
            c.clipRect(0, 0, tx, h);
            c.drawBitmap(front, 0, 0, null);
            castRL.setBounds((int) (tx - w * 0.05f), 0, (int) tx, (int) h);
            castRL.draw(c);
            c.restore();
        }
        c.save();
        c.clipRect(f, 0, w, h);
        c.drawBitmap(under, 0, 0, null);
        float sw = Math.min(backW * 0.6f, w * 0.09f);
        shadeLR.setBounds((int) f, 0, (int) (f + sw), (int) h);
        shadeLR.draw(c);
        c.restore();
        c.save();
        c.clipRect(Math.max(0, tx), 0, f, h);
        c.drawColor(backColor);
        matrix.reset();
        matrix.setScale(-1f, 1f);
        matrix.postTranslate(2 * f, 0);
        paint.setColorFilter(backFilter);
        c.drawBitmap(front, matrix, paint);
        paint.setColorFilter(null);
        float fw = Math.min(backW * 0.5f, w * 0.07f);
        shadeRL.setBounds((int) (f - fw), 0, (int) f, (int) h);
        shadeRL.draw(c);
        edgeLR.setBounds((int) tx, 0, (int) (tx + Math.min(backW * 0.3f, w * 0.04f)), (int) h);
        edgeLR.draw(c);
        c.restore();
    }

    private void frontShadow(Canvas c) {
        double degree = rtlb
                ? Math.PI / 4 - Math.atan2(c1.y - touch.y, touch.x - c1.x)
                : Math.PI / 4 - Math.atan2(touch.y - c1.y, touch.x - c1.x);
        float size = 25f;
        double d1 = size * 1.414 * Math.cos(degree), d2 = size * 1.414 * Math.sin(degree);
        float x = (float) (touch.x + d1);
        float y = rtlb ? (float) (touch.y + d2) : (float) (touch.y - d2);

        path1.reset();
        path1.moveTo(x, y);
        path1.lineTo(touch.x, touch.y);
        path1.lineTo(c1.x, c1.y);
        path1.lineTo(s1.x, s1.y);
        path1.close();
        c.save();
        c.clipPath(path0, Region.Op.DIFFERENCE);
        c.clipPath(path1, Region.Op.INTERSECT);
        GradientDrawable g;
        int left, right;
        if (rtlb) { left = (int) c1.x; right = (int) (c1.x + size); g = frontVLR; }
        else { left = (int) (c1.x - size); right = (int) (c1.x + 1); g = frontVRL; }
        c.rotate((float) Math.toDegrees(Math.atan2(touch.x - c1.x, c1.y - touch.y)), c1.x, c1.y);
        g.setBounds(left, (int) (c1.y - maxLength), right, (int) c1.y);
        g.draw(c);
        c.restore();

        path1.reset();
        path1.moveTo(x, y);
        path1.lineTo(touch.x, touch.y);
        path1.lineTo(c2.x, c2.y);
        path1.lineTo(s2.x, s2.y);
        path1.close();
        c.save();
        c.clipPath(path0, Region.Op.DIFFERENCE);
        c.clipPath(path1, Region.Op.INTERSECT);
        int top, bottom;
        if (rtlb) { top = (int) c2.y; bottom = (int) (c2.y + size); g = frontHTB; }
        else { top = (int) (c2.y - size); bottom = (int) (c2.y + 1); g = frontHBT; }
        float rot = (float) Math.toDegrees(Math.atan2(c2.y - touch.y, c2.x - touch.x));
        c.rotate(rot, c2.x, c2.y);
        float temp = c2.y < 0 ? c2.y - h : c2.y;
        int hmg = (int) Math.hypot(c2.x, temp);
        if (hmg > maxLength) g.setBounds((int) (c2.x - size) - hmg, top, (int) (c2.x + maxLength) - hmg, bottom);
        else g.setBounds((int) (c2.x - maxLength), top, (int) c2.x, bottom);
        g.draw(c);
        c.restore();
    }
}

package com.modu.reader;

import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Bitmap;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.modu.reader.web.SourceEngine;
import com.modu.reader.web.WebStore;

import java.io.File;
import java.util.List;
import java.util.UUID;

/** Book details from a book source: intro, contents size, choice of source, add to shelf. */
public class DetailActivity extends Activity {
    private Theme th;
    private final Handler ui = new Handler();
    private SearchActivity.Group group;
    private SourceEngine.Result current;
    private SourceEngine.Info info;
    private List<String[]> toc;
    private int gen;

    private MainActivity.CoverView cover;
    private TextView name, meta, latest, intro, sourceChip, tocInfo, addBtn;

    @Override protected void onCreate(Bundle saved) {
        super.onCreate(saved);
        group = SearchActivity.pending;
        if (group == null || group.items.isEmpty()) { finish(); return; }
        th = Theme.get(this);
        getWindow().getDecorView().setBackgroundColor(th.bg);
        Ui.bars(this, th.bg, th.surface);
        build();
        select(group.best());
    }

    @Override public void finish() {
        super.finish();
        overridePendingTransition(R.anim.slide_in_left_parallax, R.anim.slide_out_right);
    }

    private void build() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(th.bg);
        root.setFitsSystemWindows(true);
        LinearLayout bar = new LinearLayout(this);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(Ui.dp(this, 4), 0, Ui.dp(this, 8), 0);
        bar.addView(Ui.icon(this, Icons.BACK, th.text, new View.OnClickListener() {
            @Override public void onClick(View v) { finish(); }
        }));
        root.addView(bar, new LinearLayout.LayoutParams(-1, Ui.dp(this, 52)));

        ScrollView sv = new ScrollView(this);
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        int p = Ui.dp(this, 22);
        col.setPadding(p, Ui.dp(this, 4), p, p);

        LinearLayout head = new LinearLayout(this);
        cover = new MainActivity.CoverView(this);
        head.addView(cover, new LinearLayout.LayoutParams(Ui.dp(this, 96), Ui.dp(this, 128)));
        LinearLayout hc = new LinearLayout(this);
        hc.setOrientation(LinearLayout.VERTICAL);
        hc.setPadding(Ui.dp(this, 18), Ui.dp(this, 4), 0, 0);
        name = Ui.text(this, group.name, 21, th.text);
        name.setTypeface(Typeface.create(Typeface.SERIF, Typeface.BOLD));
        hc.addView(name);
        meta = Ui.text(this, "", 13.5f, th.sub);
        meta.setPadding(0, Ui.dp(this, 6), 0, 0);
        hc.addView(meta);
        latest = Ui.text(this, "", 13, th.sub);
        latest.setPadding(0, Ui.dp(this, 4), 0, 0);
        latest.setMaxLines(2);
        hc.addView(latest);
        sourceChip = Ui.chip(this, th, "", true, new View.OnClickListener() {
            @Override public void onClick(View v) { chooseSource(); }
        });
        LinearLayout.LayoutParams sl = new LinearLayout.LayoutParams(-2, -2);
        sl.topMargin = Ui.dp(this, 10);
        hc.addView(sourceChip, sl);
        head.addView(hc, new LinearLayout.LayoutParams(0, -2, 1f));
        col.addView(head);

        tocInfo = Ui.text(this, "", 13, th.sub);
        tocInfo.setPadding(0, Ui.dp(this, 20), 0, Ui.dp(this, 6));
        col.addView(tocInfo);
        TextView ih = Ui.text(this, "简介", 14, th.text);
        ih.setTypeface(Typeface.DEFAULT_BOLD);
        ih.setPadding(0, Ui.dp(this, 8), 0, Ui.dp(this, 6));
        col.addView(ih);
        intro = Ui.text(this, "", 14.5f, th.text);
        intro.setLineSpacing(0, 1.5f);
        col.addView(intro);
        sv.addView(col);
        root.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1f));

        LinearLayout bottom = new LinearLayout(this);
        bottom.setGravity(Gravity.CENTER_VERTICAL);
        bottom.setBackgroundColor(th.surface);
        bottom.setElevation(Ui.dp(this, 8));
        bottom.setPadding(Ui.dp(this, 16), Ui.dp(this, 10), Ui.dp(this, 16), Ui.dp(this, 10));
        addBtn = Ui.pill(this, th, "加入书架并下载", true, new View.OnClickListener() {
            @Override public void onClick(View v) { add(); }
        });
        bottom.addView(addBtn, new LinearLayout.LayoutParams(-1, -2));
        root.addView(bottom);
        setContentView(root);
    }

    private void chooseSource() {
        String[] names = new String[group.items.size()];
        for (int i = 0; i < names.length; i++) {
            SourceEngine.Result r = group.items.get(i);
            names[i] = r.source.name + (r.lastChapter.length() > 0 ? "　最新：" + r.lastChapter : "");
        }
        Ui.show(Ui.dialog(this, th).setTitle("选择书源（" + names.length + "）").setItems(names, new DialogInterface.OnClickListener() {
            @Override public void onClick(DialogInterface d, int which) { select(group.items.get(which)); }
        }), th);
    }

    private void select(final SourceEngine.Result r) {
        current = r;
        info = null;
        toc = null;
        final int my = ++gen;
        sourceChip.setText("来源：" + r.source.name + (group.items.size() > 1 ? "  ▾" : ""));
        meta.setText((r.author.length() > 0 ? r.author : "佚名") + (r.kind.length() > 0 ? "　·　" + r.kind : ""));
        latest.setText(r.lastChapter.length() > 0 ? "最新：" + r.lastChapter : "");
        intro.setText(r.intro.length() > 0 ? r.intro : "正在加载简介…");
        tocInfo.setText("正在读取目录…");
        addBtn.setAlpha(0.5f);
        showCover(r.cover);
        final Context app = getApplicationContext();
        new Thread() {
            @Override public void run() {
                SourceEngine.Info in = null;
                List<String[]> t = null;
                String err = null;
                try {
                    SourceEngine e = new SourceEngine(DownloadCenter.fetcher(app));
                    in = e.info(r.source, r);
                    t = e.toc(r.source, in.tocUrl);
                } catch (Throwable ex) {
                    err = ex.getMessage();
                }
                final SourceEngine.Info fi = in;
                final List<String[]> ft = t;
                final String fe = err;
                ui.post(new Runnable() {
                    @Override public void run() {
                        if (my != gen || isFinishing()) return;
                        info = fi;
                        toc = ft;
                        if (fi != null) {
                            if (fi.intro.length() > 0) intro.setText(fi.intro);
                            else if (r.intro.length() == 0) intro.setText("暂无简介");
                            if (fi.author.length() > 0) meta.setText(fi.author + (fi.kind.length() > 0 ? "　·　" + fi.kind : r.kind.length() > 0 ? "　·　" + r.kind : ""));
                            if (fi.lastChapter.length() > 0) latest.setText("最新：" + fi.lastChapter);
                            if (fi.cover.length() > 0 && !fi.cover.equals(r.cover)) showCover(fi.cover);
                        }
                        if (ft == null || ft.isEmpty()) {
                            tocInfo.setText(fe != null ? "这个书源读取失败：" + fe + "\n可以点上面的「来源」换一个试试。" : "这个书源没有读到目录，换一个书源试试。");
                            addBtn.setAlpha(0.5f);
                        } else {
                            tocInfo.setText("共 " + ft.size() + " 章　·　" + ft.get(0)[0] + " … " + ft.get(ft.size() - 1)[0]);
                            addBtn.setAlpha(1f);
                        }
                    }
                });
            }
        }.start();
    }

    private void showCover(final String url) {
        cover.setTag(url);
        cover.bind(group.name, Images.cached(url));
        Images.load(url, new Images.Target() {
            @Override public void set(String u, Bitmap b) { if (u.equals(cover.getTag())) cover.bind(group.name, b); }
        });
    }

    private void add() {
        if (toc == null || toc.isEmpty() || info == null) {
            Toast.makeText(this, toc == null ? "目录还在读取，请稍等" : "这个书源没有目录，换一个书源试试", Toast.LENGTH_SHORT).show();
            return;
        }
        for (Library.Entry e : Library.all(this)) {
            if ("web".equals(e.format) && e.title.equals(group.name) && current.source.url.equals(e.srcUrl)) {
                Toast.makeText(this, "这本书已经在书架上了", Toast.LENGTH_SHORT).show();
                return;
            }
        }
        final String id = UUID.randomUUID().toString().replace("-", "");
        File dir = new File(new File(getFilesDir(), "web"), id);
        final String title = info.name.length() > 0 ? info.name : group.name;
        final String author = info.author.length() > 0 ? info.author : group.author;
        try {
            WebStore s = WebStore.create(dir, title, author, current.bookUrl, toc);
            s.set("toc", info.tocUrl);
            s.set("source", current.source.url);
            s.saveMeta();
        } catch (Exception ex) {
            Toast.makeText(this, "创建失败：" + ex.getMessage(), Toast.LENGTH_LONG).show();
            return;
        }
        Library.Entry e = new Library.Entry();
        e.id = id;
        e.title = title;
        e.author = author == null ? "" : author;
        e.format = "web";
        e.path = dir.getAbsolutePath();
        String host = Uri.parse(current.bookUrl).getHost();
        e.fileName = "书源：" + current.source.name + (host != null ? "（" + host + "）" : "");
        e.source = current.bookUrl;
        e.srcUrl = current.source.url;
        e.added = System.currentTimeMillis();
        e.dlState = "downloading";
        Library.put(this, e);
        final String coverUrl = info.cover.length() > 0 ? info.cover : current.cover;
        final Context app = getApplicationContext();
        if (coverUrl.length() > 0) {
            new Thread() {
                @Override public void run() {
                    byte[] b = Images.bytes(coverUrl);
                    final String path = b == null ? null : Library.saveCover(app, id, b);
                    if (path != null) Library.update(app, id, new Library.Change() {
                        @Override public void apply(Library.Entry x) { x.cover = path; }
                    });
                }
            }.start();
        }
        DownloadCenter.start(app);
        Toast.makeText(this, "《" + title + "》已加入书架，正在后台下载", Toast.LENGTH_LONG).show();
        finish();
    }
}

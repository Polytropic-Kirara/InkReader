package com.modu.reader;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.pdf.PdfRenderer;
import android.os.Bundle;
import android.os.Handler;
import android.os.ParcelFileDescriptor;
import android.view.GestureDetector;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import com.modu.reader.core.NightFilter;

import java.io.File;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** PDF viewer on the system PdfRenderer. Re-renders the page whenever the window size changes. */
public class PdfActivity extends Activity {
    private Library.Entry entry;
    private SharedPreferences sp;
    private final Handler ui = new Handler();
    private final ExecutorService exec = Executors.newSingleThreadExecutor();
    private volatile PdfRenderer renderer;
    private ParcelFileDescriptor pfd;
    private int page, count;
    private volatile int gen;
    private int lastW, lastH;
    private boolean fitWidth, night;

    private ScrollView scroll;
    private ImageView image;
    private Bitmap shown;
    private View bars;
    private TextView pageLabel, fitButton, nightButton;
    private SeekBar seek;

    @Override protected void onCreate(Bundle saved) {
        super.onCreate(saved);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN | WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        sp = getSharedPreferences("settings", MODE_PRIVATE);
        entry = Library.get(this, getIntent().getStringExtra("id"));
        if (entry == null) { finish(); return; }
        fitWidth = sp.getBoolean("pdfFitWidth", true);
        night = Theme.isNight(this);
        page = entry.pdfPage;

        FrameLayout root = new FrameLayout(this);
        scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        image = new ImageView(this);
        image.setScaleType(ImageView.ScaleType.FIT_CENTER);
        scroll.addView(image);
        root.addView(scroll, new FrameLayout.LayoutParams(-1, -1));

        final GestureDetector gd = new GestureDetector(this, new GestureDetector.SimpleOnGestureListener() {
            @Override public boolean onSingleTapConfirmed(MotionEvent e) {
                float x = e.getX(), w = scroll.getWidth();
                if (x < w / 3f) go(page - 1);
                else if (x > w * 2f / 3f) go(page + 1);
                else bars.setVisibility(bars.getVisibility() == View.VISIBLE ? View.GONE : View.VISIBLE);
                return true;
            }
            @Override public boolean onFling(MotionEvent a, MotionEvent b, float vx, float vy) {
                if (a == null || b == null) return false;
                float dx = b.getX() - a.getX(), dy = b.getY() - a.getY();
                if (Math.abs(dx) > Ui.dp(PdfActivity.this, 60) && Math.abs(dx) > Math.abs(dy) * 1.5f) {
                    go(dx < 0 ? page + 1 : page - 1);
                    return true;
                }
                return false;
            }
        });
        scroll.setOnTouchListener(new View.OnTouchListener() {
            @Override public boolean onTouch(View v, MotionEvent e) {
                gd.onTouchEvent(e);
                return false;
            }
        });
        scroll.addOnLayoutChangeListener(new View.OnLayoutChangeListener() {
            @Override public void onLayoutChange(View v, int l, int t, int r, int b, int ol, int ot, int or, int ob) {
                if (r - l != lastW || b - t != lastH) {
                    lastW = r - l;
                    lastH = b - t;
                    if (renderer != null) render(false);
                }
            }
        });

        bars = buildBars(root);
        setContentView(root);
        applyNight();
        open();
    }

    private View buildBars(FrameLayout root) {
        Theme th = Theme.get(this);
        FrameLayout layer = new FrameLayout(this);
        layer.setVisibility(View.GONE);
        int pad = Ui.dp(this, 10);
        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setBackgroundColor(th.surface);
        top.setElevation(Ui.dp(this, 4));
        top.setPadding(Ui.dp(this, 4), Ui.dp(this, 6), pad, Ui.dp(this, 6));
        top.setClickable(true);
        top.addView(Ui.icon(this, Icons.BACK, th.text, new View.OnClickListener() {
            @Override public void onClick(View v) { finish(); }
        }));
        TextView title = Ui.text(this, entry.title, 16, th.text);
        title.setSingleLine(true);
        title.setEllipsize(android.text.TextUtils.TruncateAt.END);
        top.addView(title, new LinearLayout.LayoutParams(0, -2, 1f));
        layer.addView(top, new FrameLayout.LayoutParams(-1, -2, Gravity.TOP));

        LinearLayout bottom = new LinearLayout(this);
        bottom.setOrientation(LinearLayout.VERTICAL);
        android.graphics.drawable.GradientDrawable pbg = new android.graphics.drawable.GradientDrawable();
        pbg.setColor(th.surface);
        float r = Ui.dp(this, 20);
        pbg.setCornerRadii(new float[]{r, r, r, r, 0, 0, 0, 0});
        bottom.setBackground(pbg);
        bottom.setElevation(Ui.dp(this, 10));
        bottom.setPadding(Ui.dp(this, 16), pad, Ui.dp(this, 16), Ui.dp(this, 14));
        bottom.setClickable(true);
        pageLabel = Ui.text(this, "", 13, th.sub);
        pageLabel.setGravity(Gravity.CENTER);
        bottom.addView(pageLabel, new LinearLayout.LayoutParams(-1, -2));
        seek = new SeekBar(this);
        Ui.tint(seek, th);
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int p, boolean user) {
                if (user) pageLabel.setText((p + 1) + " / " + count);
            }
            @Override public void onStartTrackingTouch(SeekBar s) {}
            @Override public void onStopTrackingTouch(SeekBar s) { go(s.getProgress()); }
        });
        LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(-1, -2);
        slp.topMargin = Ui.dp(this, 6);
        bottom.addView(seek, slp);
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER);
        row.setPadding(0, Ui.dp(this, 10), 0, 0);
        fitButton = Ui.pill(this, th, fitWidth ? "显示：适应宽度" : "显示：整页", false, new View.OnClickListener() {
            @Override public void onClick(View v) {
                fitWidth = !fitWidth;
                sp.edit().putBoolean("pdfFitWidth", fitWidth).apply();
                updateButtons();
                render(true);
            }
        });
        nightButton = Ui.pill(this, th, "", false, new View.OnClickListener() {
            @Override public void onClick(View v) {
                sp.edit().putInt("mode", Theme.isNight(PdfActivity.this) ? 0 : 1).apply();
                night = Theme.isNight(PdfActivity.this);
                rebuildBars();
                render(false);
            }
        });
        row.addView(fitButton);
        View g = new View(this);
        row.addView(g, new LinearLayout.LayoutParams(Ui.dp(this, 10), 1));
        row.addView(nightButton);
        if (night) {
            final String[] names = {"夜间效果：智能", "夜间效果：全部反色", "夜间效果：仅调暗"};
            TextView nm = Ui.pill(this, th, names[sp.getInt("pdfNightMode", NightFilter.SMART) % 3], false, new View.OnClickListener() {
                @Override public void onClick(View v) {
                    int m = (sp.getInt("pdfNightMode", NightFilter.SMART) + 1) % 3;
                    sp.edit().putInt("pdfNightMode", m).apply();
                    ((TextView) v).setText(names[m]);
                    render(false);
                }
            });
            View g2 = new View(this);
            row.addView(g2, new LinearLayout.LayoutParams(Ui.dp(this, 10), 1));
            row.addView(nm);
        }
        android.widget.HorizontalScrollView hs = new android.widget.HorizontalScrollView(this);
        hs.setFillViewport(true);
        hs.setHorizontalScrollBarEnabled(false);
        hs.addView(row);
        bottom.addView(hs, new LinearLayout.LayoutParams(-1, -2));
        layer.addView(bottom, new FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM));
        root.addView(layer, new FrameLayout.LayoutParams(-1, -1));
        updateButtons();
        return layer;
    }

    private void rebuildBars() {
        FrameLayout root = (FrameLayout) bars.getParent();
        boolean vis = bars.getVisibility() == View.VISIBLE;
        root.removeView(bars);
        bars = buildBars(root);
        bars.setVisibility(vis ? View.VISIBLE : View.GONE);
        applyNight();
        if (count > 0) { seek.setMax(Math.max(0, count - 1)); seek.setProgress(page); pageLabel.setText((page + 1) + " / " + count); }
    }

    private void updateButtons() {
        fitButton.setText(fitWidth ? "显示：适应宽度" : "显示：整页");
        nightButton.setText(night ? "日间模式" : "夜间模式");
    }

    private void applyNight() {
        Theme th = Theme.get(this);
        int bg = night ? 0xFF000000 : Theme.mix(th.bg, 0xFF000000, 0.12f);
        scroll.setBackgroundColor(bg);
        getWindow().getDecorView().setBackgroundColor(bg);
        Ui.bars(this, bg, bg);
        if (night) {
            image.clearColorFilter(); // night colors are baked into the rendered page (NightFilter)
        } else {
            // warm the paper slightly so white PDFs are not glaring
            ColorMatrix m = new ColorMatrix(new float[]{0.98f, 0, 0, 0, 0, 0, 0.95f, 0, 0, 0, 0, 0, 0.86f, 0, 0, 0, 0, 0, 1, 0});
            image.setColorFilter(new ColorMatrixColorFilter(m));
        }
        updateButtons();
    }

    private void open() {
        exec.submit(new Runnable() {
            @Override public void run() {
                try {
                    pfd = ParcelFileDescriptor.open(new File(entry.path), ParcelFileDescriptor.MODE_READ_ONLY);
                    renderer = new PdfRenderer(pfd);
                    final int n = renderer.getPageCount();
                    ui.post(new Runnable() {
                        @Override public void run() {
                            count = n;
                            page = Math.max(0, Math.min(page, n - 1));
                            seek.setMax(Math.max(0, n - 1));
                            render(true);
                        }
                    });
                } catch (final Throwable t) {
                    ui.post(new Runnable() {
                        @Override public void run() {
                            if (isFinishing()) return;
                            String msg = t instanceof SecurityException ? "这个 PDF 有密码保护，无法打开。" : String.valueOf(t.getMessage());
                            new AlertDialog.Builder(PdfActivity.this).setTitle("无法打开").setMessage(msg)
                                    .setPositiveButton("确定", null)
                                    .setOnDismissListener(new DialogInterface.OnDismissListener() {
                                        @Override public void onDismiss(DialogInterface d) { finish(); }
                                    }).show();
                        }
                    });
                }
            }
        });
    }

    private void go(int p) {
        if (count == 0) return;
        if (p < 0 || p >= count) {
            Toast.makeText(this, p < 0 ? "已经是第一页了" : "已经是最后一页了", Toast.LENGTH_SHORT).show();
            return;
        }
        page = p;
        render(true);
    }

    private void render(final boolean toTop) {
        final int w = scroll.getWidth(), h = scroll.getHeight();
        if (w == 0 || h == 0 || renderer == null || count == 0) return;
        final int my = ++gen, p = page;
        final boolean fw = fitWidth, nightNow = night;
        final int nightMode = sp.getInt("pdfNightMode", NightFilter.SMART);
        pageLabel.setText((p + 1) + " / " + count);
        seek.setProgress(p);
        exec.submit(new Runnable() {
            @Override public void run() {
                if (my != gen || renderer == null) return;
                Bitmap bm;
                try {
                    PdfRenderer.Page pg = renderer.openPage(p);
                    float pw = Math.max(1, pg.getWidth()), ph = Math.max(1, pg.getHeight());
                    float scale = fw ? w / pw : Math.min(w / pw, h / ph);
                    float q = Math.min(2f, 4096f / Math.max(pw * scale, ph * scale)); // supersample for sharp text
                    q = Math.max(1f, Math.min(q, 1.6f));
                    int bw = Math.max(1, (int) (pw * scale * q)), bh = Math.max(1, (int) (ph * scale * q));
                    bm = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888);
                    bm.eraseColor(Color.WHITE);
                    pg.render(bm, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY);
                    pg.close();
                    if (nightNow) {
                        int[] px = new int[bw * bh];
                        bm.getPixels(px, 0, bw, 0, 0, bw, bh);
                        NightFilter.apply(px, bw, bh, nightMode);
                        bm.setPixels(px, 0, bw, 0, 0, bw, bh);
                    }
                } catch (Throwable t) {
                    bm = null;
                }
                final Bitmap res = bm;
                ui.post(new Runnable() {
                    @Override public void run() {
                        if (my != gen || isFinishing()) { if (res != null) res.recycle(); return; }
                        if (res == null) { Toast.makeText(PdfActivity.this, "这一页渲染失败", Toast.LENGTH_SHORT).show(); return; }
                        FrameLayout.LayoutParams lp = fw
                                ? new FrameLayout.LayoutParams(-1, (int) ((float) w * res.getHeight() / res.getWidth()))
                                : new FrameLayout.LayoutParams(-1, h);
                        image.setLayoutParams(lp);
                        image.setImageBitmap(res);
                        if (shown != null) shown.recycle();
                        shown = res;
                        if (toTop) scroll.scrollTo(0, 0);
                    }
                });
            }
        });
    }

    @Override public boolean onKeyDown(int code, KeyEvent e) {
        if (bars.getVisibility() != View.VISIBLE) {
            boolean vol = sp.getBoolean("volume", true);
            if ((vol && code == KeyEvent.KEYCODE_VOLUME_DOWN) || code == KeyEvent.KEYCODE_PAGE_DOWN || code == KeyEvent.KEYCODE_DPAD_RIGHT) { go(page + 1); return true; }
            if ((vol && code == KeyEvent.KEYCODE_VOLUME_UP) || code == KeyEvent.KEYCODE_PAGE_UP || code == KeyEvent.KEYCODE_DPAD_LEFT) { go(page - 1); return true; }
        }
        return super.onKeyDown(code, e);
    }

    @Override public boolean onKeyUp(int code, KeyEvent e) {
        if (bars.getVisibility() != View.VISIBLE && sp.getBoolean("volume", true)
                && (code == KeyEvent.KEYCODE_VOLUME_DOWN || code == KeyEvent.KEYCODE_VOLUME_UP)) return true;
        return super.onKeyUp(code, e);
    }

    @Override public void onBackPressed() {
        if (bars.getVisibility() == View.VISIBLE) bars.setVisibility(View.GONE);
        else super.onBackPressed();
    }

    @Override protected void onPause() {
        super.onPause();
        if (count == 0) return;
        Library.Entry latest = Library.get(this, entry.id);
        if (latest == null) return;
        latest.pdfPage = page;
        latest.progress = (page + 1f) / count;
        latest.lastRead = System.currentTimeMillis();
        Library.put(this, latest);
    }

    @Override public void finish() {
        super.finish();
        overridePendingTransition(R.anim.hold, R.anim.zoom_out);
    }

    @Override protected void onDestroy() {
        super.onDestroy();
        gen++;
        exec.submit(new Runnable() {
            @Override public void run() {
                try { if (renderer != null) renderer.close(); } catch (Throwable ignored) {}
                try { if (pfd != null) pfd.close(); } catch (Throwable ignored) {}
                renderer = null;
            }
        });
        exec.shutdown();
    }
}

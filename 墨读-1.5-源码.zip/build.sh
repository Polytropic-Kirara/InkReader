#!/bin/bash
# Builds a signed APK with aapt + javac + dx + apksigner (no Gradle / Android Studio needed).
set -e
cd "$(dirname "$0")"
export JAVA_TOOL_OPTIONS=
J=/usr/lib/android-sdk/platforms/android-23/android.jar
rm -rf build && mkdir -p build/gen build/classes
aapt package -f -m -J build/gen -M AndroidManifest.xml -S res -I "$J" -F build/unsigned.apk -0 arsc
if ! javac -nowarn -Xlint:none -encoding UTF-8 -source 8 -target 8 -bootclasspath "$J" -d build/classes \
  $(find src build/gen -name '*.java') > build/javac.log 2>&1; then
  grep -v -E "JAVA_TOOL|bootstrap|^warning|^[0-9]+ warning" build/javac.log; echo "BUILD FAILED"; exit 1
fi
test -f build/classes/com/modu/reader/MainActivity.class
dalvik-exchange --dex --min-sdk-version=23 --output=build/classes.dex build/classes
(cd build && aapt add unsigned.apk classes.dex >/dev/null)
zipalign -f -p 4 build/unsigned.apk build/aligned.apk
[ -f modu.jks ] || keytool -genkeypair -keystore modu.jks -storepass modu123456 -keypass modu123456 \
  -alias modu -keyalg RSA -keysize 2048 -validity 36500 -dname "CN=Modu Reader" >/dev/null 2>&1
apksigner sign --ks modu.jks --ks-pass pass:modu123456 --key-pass pass:modu123456 --out build/modu-reader.apk build/aligned.apk
apksigner verify build/modu-reader.apk && echo "BUILD OK: build/modu-reader.apk"

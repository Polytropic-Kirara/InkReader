import com.modu.reader.web.*;
import java.io.File;
import java.util.*;
public class X {
  static void rm(File f) { if (f.isDirectory()) for (File c : f.listFiles()) rm(c); f.delete(); }
  public static void main(String[] a) throws Exception {
    System.out.println("numbers: " + Chapters.parseNumber("十二") + " " + Chapters.parseNumber("一百零五") + " " + Chapters.parseNumber("两千三百四十五") + " " + Chapters.parseNumber("1024") + " " + Chapters.number("第三十章 风起") + " " + Chapters.number("123. 夜雨"));
    List<BookSource> src = BookSource.parseAll(new String(java.nio.file.Files.readAllBytes(java.nio.file.Paths.get("/home/claude/fakesrc/sources.json")), "UTF-8"));
    final SourceEngine e = new SourceEngine(new Fetcher());
    final BookSource c = src.get(0), d = src.get(1);
    SourceEngine.Result r = e.search(c, "剑来", 1).get(0);
    SourceEngine.Info in = e.info(c, r);
    List<String[]> toc = e.toc(c, in.tocUrl);
    File dir = new File("/tmp/wb_src"); rm(dir);
    WebStore s = WebStore.create(dir, in.name, in.author, r.bookUrl, toc.subList(0, 5));
    s.set("toc", in.tocUrl); s.set("source", c.url); s.saveMeta();
    int res = Downloader.run(s, null, null, 0, null, new Downloader.ChapterReader() {
      public List<String> read(String url, String next) throws Exception { return e.content(c, url, next, null); }
    });
    System.out.println("download via source C: result=" + res + " chapters=" + s.chapters.size() + " ch3 lines=" + s.chapterLines(2).size());
    // update check: source toc has 12 chapters, store had 5
    int found = Downloader.checkUpdate(s, null, null, new Downloader.TocReader() { public List<String[]> toc(String u) throws Exception { return e.toc(c, u); } });
    System.out.println("update found " + found + " new chapters");
    // change source to D, keep downloaded 5, continue from 6
    s = WebStore.load(dir);
    while (s.chapters.size() > 5) break;
    SourceEngine.Result rd = e.search(d, "剑来", 1).get(0);
    List<String[]> tocD = e.toc(d, e.info(d, rd).tocUrl);
    int m = Chapters.switchToc(s, tocD, rd.bookUrl);
    s.set("source", d.url); s.saveMeta();
    res = Downloader.run(s, null, null, 0, null, new Downloader.ChapterReader() {
      public List<String> read(String url, String next) throws Exception { return e.content(d, url, next, null); }
    });
    System.out.println("switched to D: matched index=" + m + " (" + tocD.get(m)[0] + ") result=" + res + " chapters=" + s.chapters.size() + " ch6 url=" + s.chapters.get(5)[1]);
    List<String[]> alt = new ArrayList<String[]>();
    alt.add(new String[]{"第1章 序", "u1"}); alt.add(new String[]{"第五章：剑来之5", "u5"}); alt.add(new String[]{"第6章 剑来之6", "u6"});
    System.out.println("fuzzy match '第5章 剑来之5' -> " + Chapters.find(alt, "第5章 剑来之5", 4));
  }
}

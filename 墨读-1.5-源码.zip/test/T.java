import com.modu.reader.core.*;
import java.io.File;
import java.util.List;
public class T {
  public static void main(String[] a) throws Exception {
    for (String p : a) {
      File f = new File(p);
      String fmt = BookFactory.detect(f, f.getName());
      System.out.println("=== " + f.getName() + " -> " + fmt);
      if (fmt == null || fmt.equals("pdf")) continue;
      long t0 = System.currentTimeMillis();
      Book b = BookFactory.open(f, fmt, null, Util.stripExt(f.getName()));
      System.out.println("title=" + b.title + " author=" + b.author + " chapters=" + b.chapterCount()
        + (b instanceof TxtBook ? " cs=" + ((TxtBook) b).charset : "") + " cover=" + (b.cover() == null ? "none" : b.cover().length + "B") + " ms=" + (System.currentTimeMillis()-t0));
      int n = b.chapterCount();
      for (int i = 0; i < n; i++) {
        List<Block> bl = b.chapter(i);
        if (i < 3 || i == n - 1) {
          System.out.println(" [" + i + "] '" + b.chapterTitles.get(i) + "' blocks=" + bl.size());
          for (int k = 0; k < Math.min(3, bl.size()); k++) {
            Block x = bl.get(k); String s = x.toString();
            System.out.println("     " + (s.length() > 60 ? s.substring(0, 60) + "…" : s));
            if (x.type == Block.IMAGE) { byte[] img = b.image(i, x.text); System.out.println("     image bytes=" + (img == null ? "NULL" : img.length)); }
          }
        }
      }
      b.close();
    }
  }
}

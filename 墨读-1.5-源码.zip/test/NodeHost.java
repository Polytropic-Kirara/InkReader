import com.modu.reader.web.*;
import java.io.*;
import java.nio.file.*;
import java.util.*;

/** Test-only JS host: runs the same prelude + wrapper as the app, in Node, with a stub bridge. */
public class NodeHost implements Js.Host {
  static final String STUB =
    "const cp=require('child_process'),crypto=require('crypto'),fs=require('fs');global.window=global;" +
    "const store='/tmp/js_store.json';function ld(){try{return JSON.parse(fs.readFileSync(store,'utf8'))}catch(e){return {}}}" +
    "global.__java={ajax:function(u){u=u.split(',{')[0];return cp.execFileSync('curl',['-s',u]).toString()}," +
    "get:function(k){return ld()[k]||''},put:function(k,v){var s=ld();s[k]=v;fs.writeFileSync(store,JSON.stringify(s))}," +
    "getString:function(){return ''},getStringList:function(){return '[]'},setContent:function(){}," +
    "base64Decode:function(s){return Buffer.from(s,'base64').toString('utf8')},base64Encode:function(s){return Buffer.from(s,'utf8').toString('base64')}," +
    "md5:function(s){return crypto.createHash('md5').update(s,'utf8').digest('hex')},encode:function(s){return encodeURIComponent(s)}," +
    "timeFormat:function(t){return new Date(Number(t)).toISOString().replace('T',' ').substring(0,19)},htmlFormat:function(s){return s.replace(/<br\\s*\\/?>/g,'\\n').replace(/<[^>]+>/g,'')}," +
    "log:function(s){},uuid:function(){return crypto.randomUUID()},cookie:function(){return ''}," +
    "aes:function(d,k,t,iv,dec){var m=t.toUpperCase().indexOf('CBC')>=0?'aes-'+(k.length*8)+'-cbc':'aes-'+(k.length*8)+'-ecb';" +
    "if(dec){var c=crypto.createDecipheriv(m,Buffer.from(k),m.endsWith('ecb')?null:Buffer.from(iv));return c.update(d,'base64','utf8')+c.final('utf8')}" +
    "var e=crypto.createCipheriv(m,Buffer.from(k),m.endsWith('ecb')?null:Buffer.from(iv));return e.update(d,'utf8','base64')+e.final('base64')}};";
  public int calls;
  public Object eval(String code, Map<String, Object> vars) throws Exception {
    calls++;
    String script = STUB + Js.PRELUDE + "process.stdout.write(" + Js.wrap(code, vars) + ");";
    Path f = Files.createTempFile("js", ".js");
    Files.write(f, script.getBytes("UTF-8"));
    Process p = new ProcessBuilder("node", f.toString()).redirectErrorStream(true).start();
    String out = new String(p.getInputStream().readAllBytes(), "UTF-8");
    p.waitFor();
    Files.delete(f);
    return Js.unwrap(out.trim());
  }
}

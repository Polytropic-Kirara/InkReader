import com.modu.reader.web.*;
import java.io.File;
public class U {
  public static void main(String[] a) throws Exception {
    Fetcher f = new Fetcher();
    String A = "http://127.0.0.1:8761/book/123/";
    if (a[0].equals("prep")) {
      File d = new File("/tmp/wb_tocA");
      Extractor.Toc t = Downloader.fetchToc(f, A);
      WebStore s = WebStore.create(d, t.bookName, t.author, A, t.links); s.set("toc", A); s.saveMeta();
      System.out.println("tocA initial: " + Downloader.run(s, f, null, 0, null) + " chapters=" + s.chapters.size());
      return;
    }
    for (String dir : new String[]{"/tmp/wb_chain", "/tmp/wb_tocA"}) {
      WebStore s = WebStore.load(new File(dir));
      int n = Downloader.checkUpdate(s, f, null);
      int r = Downloader.run(s, f, null, 0, null);
      System.out.println(dir + ": update found=" + n + " run=" + r + " chapters=" + s.chapters.size() + " last=" + s.chapters.get(s.chapters.size() - 1)[0] + " state=" + s.get("state"));
    }
  }
}

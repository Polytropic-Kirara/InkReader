import com.modu.reader.web.*;
import java.util.*;
public class S {
  public static void main(String[] a) throws Exception {
    String text = new String(java.nio.file.Files.readAllBytes(java.nio.file.Paths.get("/home/claude/fakesrc/sources.json")), "UTF-8");
    List<BookSource> list = BookSource.parseAll(text);
    System.out.println("sources=" + list.size());
    for (BookSource s : list) {
      System.out.println("== " + s.name + " usesJs=" + s.usesJs + " canSearch=" + s.canSearch());
      if (!s.canSearch()) continue;
      SourceEngine e = new SourceEngine(new Fetcher());
      List<SourceEngine.Result> rs = e.search(s, "剑来", 1);
      for (SourceEngine.Result r : rs) System.out.println("  result: " + r.name + " / " + r.author + " / " + r.kind + " / " + r.lastChapter + " / " + r.bookUrl + " cover=" + r.cover);
      SourceEngine.Info in = e.info(s, rs.get(0));
      System.out.println("  info: " + in.name + " / " + in.author + " / intro=" + in.intro + " / cover=" + in.cover + " / toc=" + in.tocUrl);
      List<String[]> toc = e.toc(s, in.tocUrl);
      System.out.println("  toc: " + toc.size() + " first=" + toc.get(0)[0] + " " + toc.get(0)[1] + " last=" + toc.get(toc.size()-1)[0]);
      List<String> c = e.content(s, toc.get(0)[1], toc.get(1)[1], null);
      System.out.println("  content ch1: " + c.size() + " paras; last=" + c.get(c.size()-1).substring(0, 10) + (String.join("", c).contains("记住") || String.join("", c).contains("首发") ? "  !!AD LEFT" : "  (ads removed)"));
    }
  }
}

import com.modu.reader.web.*;
import java.util.*;
public class J {
  public static void main(String[] a) throws Exception {
    NodeHost h = new NodeHost();
    // 1) prelude helpers
    Js.host = h;
    Map<String,Object> v = new HashMap<String,Object>();
    System.out.println("helpers: " + h.eval("[java.md5Encode('abc'), java.base64Decode(java.base64Encode('中文ok')), java.hexDecodeToString(java.hexEncodeToString('测试')), java.aesDecodeToString(java.aesEncodeToBase64String('秘密','1234567890abcdef','AES/CBC/PKCS5Padding','abcdef1234567890'),'1234567890abcdef','AES/CBC/PKCS5Padding','abcdef1234567890'), (java.put('k','v'), java.get('k')), java.connect('http://127.0.0.1:8764/api/book?id=3').body().length>10].join(' | ')", v));
    System.out.println("last-expression value: " + h.eval("var x = 1; x + 41", v) + ", undefined -> " + h.eval("var y;", v));
    // 2) JS-heavy sources end to end
    List<BookSource> list = BookSource.parseAll(new String(java.nio.file.Files.readAllBytes(java.nio.file.Paths.get("/home/claude/fakesrc/js_sources.json")), "UTF-8"));
    for (BookSource s : list) {
      SourceEngine e = new SourceEngine(new Fetcher());
      System.out.println("== " + s.name + " usesJs=" + s.usesJs + " canSearch=" + s.canSearch());
      List<SourceEngine.Result> rs = e.search(s, "剑来", 1);
      for (SourceEngine.Result r : rs) System.out.println("  result: " + r.name + " / " + r.author + " / " + r.intro + " / " + r.lastChapter + " / " + r.bookUrl);
      SourceEngine.Info in = e.info(s, rs.get(0));
      System.out.println("  info: " + in.name + " / " + in.author + " / " + in.intro);
      List<String[]> toc = e.toc(s, in.tocUrl);
      System.out.println("  toc: " + toc.size() + " first=" + toc.get(0)[0] + " -> " + toc.get(0)[1]);
      List<String> c = e.content(s, toc.get(0)[1], toc.get(1)[1], null);
      String all = String.join("", c);
      System.out.println("  content: " + c.size() + " paras" + (all.contains("记住") || all.contains("首发") || all.contains("<") ? "  !!LEFTOVER" : "  (clean)"));
    }
    System.out.println("node evaluations: " + h.calls);
    // 3) without a JS host the same sources are reported as unsupported
    Js.host = null;
    System.out.println("no host: canSearch C=" + list.get(0).canSearch());
  }
}

import com.modu.reader.web.*;
import java.util.*;
public class R {
  static int pass = 0, fail = 0;
  static void eq(String name, Object got, Object want) {
    if (String.valueOf(got).equals(String.valueOf(want))) pass++; else { fail++; System.out.println("FAIL " + name + "\n  got:  " + got + "\n  want: " + want); }
  }
  public static void main(String[] a) {
    String html = "<html><head><meta property=\"og:novel:book_name\" content=\"剑来\"><title>t</title></head><body>"
      + "<div class=\"result-list\"><div class=\"result-item\"><a class=\"title-link\" href=\"/b/1/\">剑来</a><p>作者：<span>A</span><span>烽火</span></p><p>最新：<a href=\"/b/1/9.html\">第九章</a></p><img src=\"/c/1.jpg\"></div>"
      + "<div class=\"result-item\"><a class=\"title-link\" href=\"/b/2/\">雪中</a><p>作者：<span>A</span><span>烽火二</span></p><p>最新：<a href=\"/b/2/5.html\">第五章</a></p></div></div>"
      + "<div id=\"list\"><dl><dd><a href=\"1.html\">第一章</a></dd><dd><a href=\"2.html\">第二章</a></dd><dd><a href=\"3.html\">第三章</a></dd></dl></div>"
      + "<div id=\"content\">第一段<br>第二段 www.ad.com<br>第三段</div><ul><li>x</li><li class=\"on\">y</li><li>z</li></ul></body></html>";
    Dom.Node d = Dom.parse(html);
    String base = "http://s.com/search?q=1";
    List<Object> items = Rules.elements(d, "class.result-list@class.result-item");
    eq("bookList count", items.size(), 2);
    eq("name", Rules.string(items.get(0), "class.title-link@text", base, false), "剑来");
    eq("bookUrl", Rules.string(items.get(1), "class.title-link@href", base, true), "http://s.com/b/2/");
    eq("author tag idx", Rules.string(items.get(0), "tag.p.0@tag.span.1@text", base, false), "烽火");
    eq("author neg idx", Rules.string(items.get(1), "tag.p.0@tag.span.-1@text", base, false), "烽火二");
    eq("last p", Rules.string(items.get(0), "tag.p.-1@tag.a@text", base, false), "第九章");
    eq("cover", Rules.string(items.get(0), "tag.img@src", base, true), "http://s.com/c/1.jpg");
    eq("css attr", Rules.string(d, "[property=og:novel:book_name]@content", base, false), "剑来");
    eq("@css", Rules.string(d, "@css:.result-item > a.title-link@text", base, false), "剑来\n雪中");
    eq("css list", Rules.elements(d, "@css:#list dd a").size(), 3);
    eq("id+bare css", Rules.elements(d, "id.list@dd@a").size(), 3);
    eq("chapterName text", Rules.string(Rules.elements(d, "id.list@dd@a").get(1), "text", base, false), "第二章");
    eq("chapterUrl href", Rules.string(Rules.elements(d, "id.list@dd@a").get(2), "href", "http://s.com/b/1/", true), "http://s.com/b/1/3.html");
    eq("exclude idx", Rules.elements(d, "tag.li!0").size(), 2);
    eq("bracket idx", Rules.string(d, "tag.li[1,2]@text", base, false), "y\nz");
    eq("textNodes", Rules.string(d, "id.content@textNodes", base, false), "第一段\n第二段 www.ad.com\n第三段");
    eq("purify", Rules.string(d, "id.content@textNodes##\\s*www\\.\\w+\\.com", base, false), "第一段\n第二段\n第三段");
    eq("replace", Rules.string(d, "class.title-link.0@text##剑##刀", base, false), "刀来");
    eq("||", Rules.string(d, "class.none@text||id.list@tag.a.0@text", base, false), "第一章");
    eq("&&", Rules.string(d, "id.list@tag.a.0@text&&id.list@tag.a.1@text", base, false), "第一章\n第二章");
    eq("xpath text", Rules.string(d, "//div[@id='list']//a/text()", base, false), "第一章\n第二章\n第三章");
    eq("xpath attr", Rules.string(d, "//div[@class='result-item'][2]/a/@href", base, true), "http://s.com/b/2/");
    eq("css pseudo", Rules.string(d, "@css:li.on@text", base, false), "y");
    eq("css nth", Rules.string(d, "@css:li:nth-child(3)@text", base, false), "z");
    eq("template", Rules.string(items.get(0), "作者{{tag.p.0@tag.span.1@text}}的书", base, false), "作者烽火的书");
    String json = "{\"code\":0,\"data\":{\"list\":[{\"id\":11,\"title\":\"剑来\",\"author\":\"烽火\",\"tags\":[\"仙侠\",\"连载\"]},{\"id\":12,\"title\":\"雪中\",\"author\":\"烽火\"}]}}";
    Object j = Rules.parseBody(json);
    List<Object> jl = Rules.elements(j, "$.data.list[*]");
    eq("json list", jl.size(), 2);
    eq("json key", Rules.string(jl.get(1), "$.title", base, false), "雪中");
    eq("json bare key", Rules.string(jl.get(0), "author", base, false), "烽火");
    eq("json template url", Rules.string(jl.get(0), "/book/{{$.id}}/", base, true), "http://s.com/book/11/");
    eq("json array join", Rules.string(jl.get(0), "$.tags", base, false), "仙侠\n连载");
    eq("json deep", Rules.strings(j, "$..title", base, false), "[剑来, 雪中]");
    eq("json filter", Rules.string(j, "$.data.list[?(@.id==12)].title", base, false), "雪中");
    eq("js ignored", Rules.string(d, "<js>result+1</js>", base, false), "");
    System.out.println("rules: " + pass + " passed, " + fail + " failed");
  }
}

import com.modu.reader.web.*;
import com.modu.reader.core.*;
import java.io.File;
import java.util.*;
public class W {
  static void rm(File f) { if (f.isDirectory()) for (File c : f.listFiles()) rm(c); f.delete(); }
  public static void main(String[] a) throws Exception {
    Fetcher f = new Fetcher();
    String A = "http://127.0.0.1:8761/book/123/", B = "http://127.0.0.1:8762/novel/7/";
    System.out.println("== single chapter A/1");
    Source.Page p = f.get(A + "1.html", null);
    Extractor.Chapter c = Extractor.chapter(Dom.parse(p.html), p.url, null);
    System.out.println("title=" + c.title + " book=" + c.bookName + " next=" + c.nextUrl + " page=" + c.nextIsPage + " toc=" + c.tocUrl + " paras=" + c.paras.size());
    for (int i = 0; i < 2; i++) System.out.println("  P: " + c.paras.get(i).substring(0, 20));
    System.out.println("  last: " + c.paras.get(c.paras.size() - 1));
    System.out.println("== chapter A/3 (two pages)");
    p = f.get(A + "3.html", null);
    c = Extractor.chapter(Dom.parse(p.html), p.url, null);
    System.out.println("title=" + c.title + " raw=" + c.rawTitle + " next=" + c.nextUrl + " page=" + c.nextIsPage);
    System.out.println("== toc A");
    p = f.get(A, null);
    Extractor.Toc t = Extractor.toc(Dom.parse(p.html), p.url);
    System.out.println("book=" + t.bookName + " author=" + t.author + " links=" + t.links.size() + " first=" + t.links.get(0)[0] + " last=" + t.links.get(t.links.size() - 1)[0]);
    System.out.println("== toc B");
    p = f.get(B, null);
    t = Extractor.toc(Dom.parse(p.html), p.url);
    System.out.println("book=" + t.bookName + " links=" + t.links.size());
    p = f.get(B + "2.html", null);
    c = Extractor.chapter(Dom.parse(p.html), p.url, null);
    System.out.println("B/2 title=" + c.title + " book=" + c.bookName + " next=" + c.nextUrl + " paras=" + c.paras.size() + " last=" + c.paras.get(c.paras.size()-1).substring(0,10));

    // chain download of A
    File d1 = new File("/tmp/wb_chain"); rm(d1);
    WebStore s = WebStore.create(d1, "剑来测试", "", A + "1.html", null);
    long t0 = System.currentTimeMillis();
    int r = Downloader.run(s, f, null, 0, null);
    System.out.println("== chain A result=" + r + " chapters=" + s.chapters.size() + " state=" + s.get("state") + " err=" + s.get("error") + " ms=" + (System.currentTimeMillis() - t0));
    List<String> exp = WebStoreTest.lines("/home/claude/fakesite/expected_a.txt");
    int ok = 0;
    for (int i = 0; i < Math.min(s.chapters.size(), exp.size()); i++) {
      List<String> lines = s.chapterLines(i);
      String[] e = exp.get(i).split("\t");
      int n = lines.size() - 1;
      boolean good = n == Integer.parseInt(e[1]) && lines.get(1).startsWith(e[2]) && lines.get(lines.size()-1).endsWith(e[3]);
      if (good) ok++; else System.out.println("  MISMATCH ch" + (i+1) + " got " + n + " lines, want " + e[1] + " first=" + lines.get(1).substring(0, 12) + " title=" + lines.get(0));
    }
    System.out.println("  exact-match chapters: " + ok + "/" + exp.size() + "  titles: " + s.chapters.get(0)[0] + " … " + s.chapters.get(2)[0] + " … " + s.chapters.get(s.chapters.size()-1)[0]);
    // toc-mode download of B
    File d2 = new File("/tmp/wb_toc"); rm(d2);
    Extractor.Toc tb = Downloader.fetchToc(f, B);
    WebStore s2 = WebStore.create(d2, tb.bookName, "", B, tb.links);
    s2.set("toc", B); s2.saveMeta();
    r = Downloader.run(s2, f, null, 0, null);
    System.out.println("== toc B result=" + r + " chapters=" + s2.chapters.size() + " ch1 lines=" + s2.chapterLines(0).size());
    Book wb = BookFactory.open(d2, "web", null, "x");
    System.out.println("  WebBook: " + wb.title + " chapters=" + wb.chapterCount() + " firstBlock=" + wb.chapter(0).get(0));
  }
}
class WebStoreTest { static List<String> lines(String p) throws Exception { return java.nio.file.Files.readAllLines(java.nio.file.Paths.get(p)); } }

import com.modu.reader.core.NightFilter;
import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.File;
public class N {
  public static void main(String[] a) throws Exception {
    BufferedImage im = ImageIO.read(new File(a[0]));
    int w = im.getWidth(), h = im.getHeight();
    int[] px = im.getRGB(0, 0, w, h, null, 0, w);
    long t = System.nanoTime();
    NightFilter.apply(px, w, h, 0xFF111111, 0xFFB4B0A8, 0.82f);
    System.out.println("ms=" + (System.nanoTime() - t) / 1000000);
    BufferedImage out = new BufferedImage(w, h, BufferedImage.TYPE_INT_RGB);
    out.setRGB(0, 0, w, h, px, 0, w);
    ImageIO.write(out, "png", new File(a[1]));
  }
}
